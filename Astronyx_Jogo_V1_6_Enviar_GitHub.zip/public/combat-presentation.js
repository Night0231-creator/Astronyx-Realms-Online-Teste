/* Astronyx V1.3 • Camada de apresentação audiovisual.
   Não determina dano, loot, turnos ou estado do jogo: somente interpreta eventos da API.
   SFX gerados com Web Audio, sem arquivos externos e somente após opt-in explícito. */
(function(root){
'use strict';
const CLASS_STYLES=Object.freeze({
 guardian:{label:'Bastião',rune:'⬡',color:'#f3d18a',tone:180},
 arcanist:{label:'Arcano',rune:'✶',color:'#bba2ff',tone:330},
 healer:{label:'Aurora',rune:'✚',color:'#92ffd4',tone:260},
 ranger:{label:'Selvagem',rune:'➶',color:'#a1dba0',tone:250},
 enemy:{label:'Sombrio',rune:'☠',color:'#ff8498',tone:120}
});
const THEMES=Object.freeze({adaptive:'Classe atual',celestial:'Dourado celestial',arcane:'Violeta arcano',wild:'Verde selvagem',infernal:'Vermelho infernal'});
const MODES=['cinematic','balanced','performance'];
const clamp=(n,lo,hi)=>Math.min(hi,Math.max(lo,Number.isFinite(Number(n))?Number(n):lo));
function preferences(value={}){
 return {
  enabled:value.enabled===true,
  volume:Math.round(clamp(value.volume??55,0,100)),
  mode:MODES.includes(value.mode)?value.mode:'cinematic',
  theme:Object.hasOwn(THEMES,value.theme)?value.theme:'adaptive'
 };
}
function themeForEvent(event={},selected='adaptive'){
 if(selected!=='adaptive'&&Object.hasOwn(THEMES,selected))return selected;
 if(event.kind==='enemy_attack'||event.kind==='defeat')return 'infernal';
 if(event.kind==='phase'||(event.kind==='intro'&&event.boss))return 'infernal';
 return {guardian:'celestial',arcanist:'arcane',healer:'wild',ranger:'wild'}[event.classId]||'celestial';
}
function bannerForEvent(event={}){
 const kind=event.kind;
 if(kind==='victory')return {rune:'✦',eyebrow:'MISSÃO CONCLUÍDA',title:'VITÓRIA',subtitle:`+${Math.max(0,Number(event.xp)||0)} XP  ·  +${Math.max(0,Number(event.gold)||0)} OURO`,type:'victory'};
 if(kind==='defeat')return {rune:'☠',eyebrow:'A COMPANHIA CAIU',title:'DERROTA',subtitle:'Aventureiros, reagrupem-se e tentem novamente.',type:'defeat'};
 if(kind==='phase')return {rune:'⚡',eyebrow:'CHEFE DESPERTANDO',title:`FASE ${Math.min(3,Math.max(1,Number(event.phase)||1))}`,subtitle:event.name||'A criatura desperta um novo poder',type:'boss'};
 if(kind==='intro'&&event.boss)return {rune:'☠',eyebrow:'UMA AMEAÇA LENDÁRIA',title:'CHEFE APARECEU',subtitle:event.name||'Preparem a companhia',type:'boss'};
 if(kind==='ultimate')return {rune:CLASS_STYLES[event.classId]?.rune||'✧',eyebrow:'HABILIDADE SUPREMA',title:event.skill||'GOLPE SUPREMO',subtitle:event.name||'O poder da companhia desperta',type:'ultimate'};
 return null;
}
function eventLabel(event={}){
 if(event.kind==='ultimate')return `✧ ${event.skill||'Suprema'}`;
 if(event.kind==='victory')return '✦ Vitória';
 if(event.kind==='defeat')return '☠ Derrota';
 if(event.kind==='phase')return `⚡ Fase ${event.phase||1}`;
 if(event.kind==='intro')return event.boss?'☠ Chefe':'⚔ Encontro';
 if(event.kind==='enemy_attack')return `☠ Ataque inimigo${event.damage?' · '+event.damage:''}`;
 if(event.kind==='heal'||event.kind==='potion')return `✚ Cura${event.healed?' +'+event.healed:''}`;
 if(event.kind==='guard')return '⬡ Defesa';
 return `${event.kind==='skill'?'✧':'⚔'} ${String(event.name||event.skill||'Ataque').slice(0,22)}${event.damage?' · '+event.damage:''}`;
}
function audioNotes(event={}){
 const tone=CLASS_STYLES[event.classId]?.tone||210;
 switch(event.kind){
  case 'attack':return [{f:tone*1.4,d:.12,w:'sawtooth'},{f:tone*.7,d:.12,at:.075,w:'triangle'}];
  case 'skill':return [{f:tone,d:.15,w:'triangle'},{f:tone*1.4,d:.18,at:.07,w:'sine'},{f:tone*2,d:.22,at:.13,w:'sine'}];
  case 'ultimate':return [{f:tone*.8,d:.30,w:'triangle'},{f:tone*1.2,d:.33,at:.15,w:'sine'},{f:tone*1.6,d:.40,at:.3,w:'sine'},{f:tone*2.1,d:.6,at:.48,w:'sine'}];
  case 'enemy_attack':return [{f:130,d:.18,w:'sawtooth'},{f:75,d:.24,at:.07,w:'triangle'}];
  case 'guard':return [{f:195,d:.19,w:'triangle'},{f:290,d:.19,at:.1,w:'sine'}];
  case 'heal':case 'potion':return [{f:390,d:.23,w:'sine'},{f:520,d:.25,at:.13,w:'sine'},{f:655,d:.3,at:.28,w:'sine'}];
  case 'phase':case 'intro':return [{f:115,d:.45,w:'sawtooth'},{f:165,d:.42,at:.12,w:'triangle'}];
  case 'victory':return [0,1,2,3].map((n)=>({f:[392,494,587,784][n],d:.34,at:n*.15,w:'sine'}));
  case 'defeat':return [0,1,2].map(n=>({f:[220,164,110][n],d:.4,at:n*.22,w:'triangle'}));
  default:return [];
 }
}
class SynthAudio{
 constructor(contextCtor=null){this.contextCtor=contextCtor||root.AudioContext||root.webkitAudioContext;this.context=null;this.enabled=false;this.volume=55;this.lastAt=0;}
 setOptions({enabled=false,volume=55}={}){this.enabled=!!enabled;this.volume=Math.round(clamp(volume,0,100));if(!this.enabled&&this.context?.state==='running')this.context.suspend?.().catch?.(()=>{});}
 async unlock(){
  if(!this.enabled||!this.contextCtor)return false;
  try{if(!this.context)this.context=new this.contextCtor();if(this.context.state==='suspended')await this.context.resume();return this.context.state==='running';}catch{return false;}
 }
 play(event={}){
  if(!this.enabled||!this.context||this.context.state!=='running'||this.volume<=0||root.document?.hidden)return false;
  const ctx=this.context,notes=audioNotes(event).slice(0,5);if(!notes.length)return false;
  const now=ctx.currentTime,master=(this.volume/100)*.14;
  try{
   notes.forEach(({f,d,w='sine',at=0})=>{
    const osc=ctx.createOscillator(),env=ctx.createGain(),start=now+at;
    osc.type=w;osc.frequency.setValueAtTime(f,start);
    if(event.kind==='enemy_attack'||event.kind==='attack')osc.frequency.exponentialRampToValueAtTime(Math.max(40,f*.68),start+d);
    env.gain.setValueAtTime(.0001,start);
    env.gain.exponentialRampToValueAtTime(Math.max(.00011,master),start+.025);
    env.gain.exponentialRampToValueAtTime(.0001,start+d);
    osc.connect(env);env.connect(ctx.destination);osc.start(start);osc.stop(start+d+.02);
    osc.onended=()=>{osc.disconnect();env.disconnect();};
   });return true;
  }catch{return false;}
 }
 close(){if(!this.context)return;this.context.close?.().catch?.(()=>{});this.context=null;}
}
class CombatPresentation{
 constructor({arena=null,overlay=null,audioCtor=null}={}){this.arena=arena;this.overlay=overlay;this.sound=new SynthAudio(audioCtor);this.prefs=preferences();this.lastEvent=null;}
 setPrefs(raw){this.prefs=preferences(raw);this.sound.setOptions(this.prefs);if(this.arena){this.arena.dataset.presentation=this.prefs.mode;this.arena.dataset.theme=this.prefs.theme;}if(!this.prefs.enabled)this.sound.setOptions(this.prefs);return this.prefs;}
 unlock(){return this.sound.unlock();}
 present(event={}){
  this.lastEvent=event;
  this.sound.play(event);
  if(this.arena)this.arena.dataset.theme=themeForEvent(event,this.prefs.theme);
  if(!this.overlay)return null;
  const banner=bannerForEvent(event);
  const significant=['victory','defeat','boss'].includes(banner?.type);
  const show=banner&&(this.prefs.mode==='cinematic'||significant);
  if(!show){this.clear();return null;}
  this.overlay.dataset.kind=banner.type;
  this.overlay.dataset.theme=themeForEvent(event,this.prefs.theme);
  const rune=this.overlay.querySelector('[data-banner-rune]');if(rune)rune.textContent=banner.rune;
  const eyebrow=this.overlay.querySelector('[data-banner-eyebrow]');if(eyebrow)eyebrow.textContent=banner.eyebrow;
  const title=this.overlay.querySelector('[data-banner-title]');if(title)title.textContent=banner.title;
  const subtitle=this.overlay.querySelector('[data-banner-subtitle]');if(subtitle)subtitle.textContent=banner.subtitle;
  this.overlay.classList.remove('active');void this.overlay.offsetWidth;this.overlay.classList.add('active');
  return banner;
 }
 clear(){if(this.overlay)this.overlay.classList.remove('active');}
 destroy(){this.clear();this.sound.close();}
}
const exports={CLASS_STYLES,THEMES,MODES,preferences,themeForEvent,bannerForEvent,eventLabel,audioNotes,SynthAudio,CombatPresentation};
root.AstronyxPresentation=exports;
if(typeof module!=='undefined'&&module.exports)module.exports=exports;
})(typeof window!=='undefined'?window:globalThis);
