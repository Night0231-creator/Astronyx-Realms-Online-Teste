
(()=>{const qs=s=>document.querySelector(s);const names={forest:'Bosque de Eldrath',crystal:'Galerias de Cristal',ember:'Fortaleza Ígnea'};const state={room:{id:'preview',scene:'forest'},auto:{stage:1,enemy:{name:'Slime Musgoso',hp:100,boss:false,phase:1}},members:[{id:'hero',name:'Aventureiro',classId:'guardian',hp:100}]};let stage;const status=t=>qs('#status').textContent=t;
try{stage=new AstronyxCombat3D.CombatStage(qs('#view3d'),{onFailure:m=>status('Erro WebGL: '+m)});stage.sync(state);status('Arena pronta. Gire a câmera e experimente um golpe.');}catch(e){status('Não foi possível carregar o WebGL: '+e.message);return;}
const sync=()=>{qs('#hud-title').textContent=names[state.room.scene];stage.sync(state);};
const presentation=new AstronyxPresentation.CombatPresentation({arena:qs('.arena'),overlay:qs('#demo-cinematic')});
const audio=qs('#audio'),volume=qs('#volume'),quality=qs('#presentation');
const syncPrefs=()=>presentation.setPrefs({enabled:audio.checked,volume:Number(volume.value),mode:quality.value});
syncPrefs();
audio.addEventListener('change',async()=>{syncPrefs();if(audio.checked&&!(await presentation.unlock())){audio.checked=false;syncPrefs();status('Som indisponível neste navegador.');}});
volume.addEventListener('input',syncPrefs);quality.addEventListener('change',syncPrefs);
const showDemo=(event,duration=1200)=>{presentation.present(event);stage.play(event,duration);setTimeout(()=>presentation.clear(),duration);};

qs('#scene').onchange=e=>{state.room.scene=e.target.value;sync();};qs('#class').onchange=e=>{state.members[0].classId=e.target.value;sync();};qs('#camera').onchange=e=>stage.setCamera(e.target.value);qs('#focus').onclick=()=>stage.focus();
for(const kind of ['attack','skill','ultimate'])qs('#'+kind).onclick=()=>{const duration=kind==='ultimate'?1600:950;showDemo({kind,actorId:'hero',classId:state.members[0].classId,name:'Aventureiro',skill:kind==='ultimate'?'Poder Supremo':'Técnica especial'},duration);status('Demonstração: '+({attack:'Ataque básico',skill:'Habilidade de classe',ultimate:'Suprema cinematográfica'}[kind]));};
qs('#win').onclick=()=>{showDemo({kind:'victory',xp:120,gold:85},1700);status('Demonstração: vitória e recompensas fictícias.');};
qs('#lose').onclick=()=>{showDemo({kind:'defeat'},1700);status('Demonstração: derrota, sem perda de progresso.');};
qs('#smooth').addEventListener('change',e=>{stage.smoothTransitions=e.target.checked;status(e.target.checked?'Transições suaves ligadas':'Transições instantâneas');});
qs('#trails').addEventListener('change',e=>{stage.weaponFxEnabled=e.target.checked;status(e.target.checked?'Trilhas 3D ligadas':'Trilhas 3D desligadas');});
qs('#preview-clip').addEventListener('change',e=>{stage.previewClip=e.target.value==='auto'?null:e.target.value;status(stage.previewClip?'Prévia do clipe: '+stage.previewClip:'Animações sincronizadas automaticamente com as ações.');});
qs('#preview-glb').addEventListener('change',async e=>{
 const file=e.target.files?.[0];if(!file)return;
 try{const buffer=await file.arrayBuffer(),parsed=AstronyxGLB.parseGLB(buffer),images=await AstronyxGLB.embeddedImages(parsed),id='f'.repeat(24);
  if(stage.viewer.models.has(id)){const old=stage.viewer.models.get(id);const gl=stage.viewer.gl;old.primitives.forEach(p=>p.buffers.forEach(b=>gl.deleteBuffer(b)));old.textures.forEach(t=>t&&gl.deleteTexture(t));stage.viewer.models.delete(id);}
  stage.viewer.loadModel(id,parsed,images);state.modelLibrary={slots:{[state.members[0].classId]:id}};sync();
  const model=stage.viewer.models.get(id),clipSelect=qs('#preview-clip');clipSelect.innerHTML='<option value="auto">Automático</option>';stage.previewClip=null;for(const clip of model.animator?.clips||[]){const opt=document.createElement('option');opt.value=clip.name;opt.textContent=clip.name+' ('+clip.duration.toFixed(1)+' s)';clipSelect.appendChild(opt);}
  status(`Modelo ${file.name}: ${parsed.triangles} triângulos • ${model.animator?.clips.length||0} clipes compatíveis. ${model.animator?.reason||'Prévia animada ativa.'} Nenhum arquivo foi enviado.`);
 }catch(error){status('Não foi possível abrir o GLB: '+error.message);}
});
qs('#class').addEventListener('change',()=>{const id='f'.repeat(24);if(stage.viewer.models.has(id)){state.modelLibrary={slots:{[state.members[0].classId]:id}};sync();}});
qs('#boss').onclick=()=>{state.auto.enemy.boss=!state.auto.enemy.boss;state.auto.stage++;state.auto.enemy.name=state.auto.enemy.boss?'Chefe das Profundezas':'Slime Musgoso';sync();showDemo({kind:'intro',boss:state.auto.enemy.boss,name:state.auto.enemy.name},1400);status(state.auto.enemy.boss?'Chefe convocado':'Criatura comum convocada');};
})();
