// Preencha a URL publica HTTPS do backend quando publicar na Netlify.
// Deixe vazio para jogar localmente na mesma origem do servidor Node.js.
window.ASTRONYX_API_BASE = '';
