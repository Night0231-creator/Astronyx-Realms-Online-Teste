/* Astronyx V1.0: leitor GLB 2.0 sem CDN. Geometria estática, PBR base-color
   com textura PNG/JPEG embutida, hierarquia de nodes e transforms. */
(function(root){
'use strict';
const finite=v=>Number.isFinite(v)?v:0;
const multiply=(a,b)=>{const out=new Array(16).fill(0);for(let col=0;col<4;col++)for(let row=0;row<4;row++)for(let k=0;k<4;k++)out[col*4+row]+=a[k*4+row]*b[col*4+k];return out;};
const ID=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1];
function nodeMatrix(node){if(node.matrix)return node.matrix;const [x,y,z,w]=node.rotation||[0,0,0,1],s=node.scale||[1,1,1],t=node.translation||[0,0,0];return [(1-2*(y*y+z*z))*s[0],(2*(x*y+z*w))*s[0],(2*(x*z-y*w))*s[0],0,(2*(x*y-z*w))*s[1],(1-2*(x*x+z*z))*s[1],(2*(y*z+x*w))*s[1],0,(2*(x*z+y*w))*s[2],(2*(y*z-x*w))*s[2],(1-2*(x*x+y*y))*s[2],0,...t,1];}
function transformed(m,p){return [m[0]*p[0]+m[4]*p[1]+m[8]*p[2]+m[12],m[1]*p[0]+m[5]*p[1]+m[9]*p[2]+m[13],m[2]*p[0]+m[6]*p[1]+m[10]*p[2]+m[14]];}
function transformNormal(m,n){const a=transformed(m,n),t=transformed(m,[0,0,0]),d=a.map((v,i)=>v-t[i]),l=Math.hypot(...d)||1;return d.map(v=>v/l);}
function parseGLB(input){
 const bytes=input instanceof Uint8Array?new Uint8Array(input.buffer,input.byteOffset,input.byteLength):new Uint8Array(input);
 if(bytes.byteLength<20||bytes.byteLength>12*1024*1024)throw Error('GLB inválido ou maior que 12 MB.');
 const dv=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);
 if(dv.getUint32(0,true)!==0x46546c67||dv.getUint32(4,true)!==2||dv.getUint32(8,true)!==bytes.byteLength)throw Error('Arquivo deve ser GLB 2.0.');
 let p=12,json=null,bin=null;
 while(p<bytes.byteLength){if(p+8>bytes.length)throw Error('Chunk GLB inválido.');const len=dv.getUint32(p,true),type=dv.getUint32(p+4,true);p+=8;if(p+len>bytes.length)throw Error('Chunk GLB fora dos limites.');const body=bytes.subarray(p,p+len);if(type===0x4e4f534a){if(json)throw Error('GLB contém múltiplos JSON.');json=JSON.parse(new TextDecoder().decode(body));}if(type===0x004e4942){if(bin)throw Error('GLB contém múltiplos binários.');bin=body;}p+=len;}
 if(!json||!bin||json.asset?.version!=='2.0')throw Error('GLB não contém JSON/BIN 2.0.');
 if((json.buffers||[]).some(b=>b.uri))throw Error('Exporte GLB com texturas embutidas, sem arquivos externos.');
 if((json.extensionsRequired||[]).length)throw Error('Remova compressão Draco/extensões obrigatórias antes de exportar.');
 if((json.meshes||[]).length>48||(json.nodes||[]).length>160)throw Error('Modelo complexo demais.');
 const accessors=json.accessors||[],views=json.bufferViews||[];
 function accessor(index){const a=accessors[index];if(!a||a.sparse||!Number.isInteger(a.bufferView))throw Error('Accessor GLB incompatível.');const v=views[a.bufferView];if(!v||v.buffer!==0)throw Error('BufferView GLB inválida.');const sizes={5120:1,5121:1,5122:2,5123:2,5125:4,5126:4},countType={SCALAR:1,VEC2:2,VEC3:3,VEC4:4};const size=sizes[a.componentType],n=countType[a.type];if(!size||!n||a.count<0||a.count>170000)throw Error('Atributo GLB inválido.');const stride=v.byteStride||n*size,off=(v.byteOffset||0)+(a.byteOffset||0);if(stride<n*size||stride>512||off+Math.max(0,a.count-1)*stride+n*size>(v.byteOffset||0)+v.byteLength||off<0||off>=bin.length)throw Error('Accessor fora do arquivo.');const vd=new DataView(bin.buffer,bin.byteOffset,bin.byteLength),array=[];for(let i=0;i<a.count;i++){const row=[];for(let k=0;k<n;k++){const at=off+i*stride+k*size;let val;switch(a.componentType){case 5120:val=vd.getInt8(at);break;case 5121:val=vd.getUint8(at);break;case 5122:val=vd.getInt16(at,true);break;case 5123:val=vd.getUint16(at,true);break;case 5125:val=vd.getUint32(at,true);break;case 5126:val=vd.getFloat32(at,true);break;}if(a.normalized&&a.componentType!==5126)val=a.componentType===5120?Math.max(-1,val/127):a.componentType===5122?Math.max(-1,val/32767):a.componentType===5121?val/255:a.componentType===5123?val/65535:val/4294967295;row.push(finite(val));}array.push(row);}return array;}
 const primitives=[],nodes=json.nodes||[],meshes=json.meshes||[];
 const scene=json.scenes?.[json.scene||0],roots=scene?.nodes||(nodes.length?nodes.map((_,i)=>i).filter(i=>!nodes.some(n=>(n.children||[]).includes(i))):[]);
 let triangles=0;const seen=new Set();
 function walk(index,parent,depth){if(depth>24||seen.has(index))throw Error('Hierarquia de modelo inválida.');const node=nodes[index];if(!node)throw Error('Node GLB inválido.');seen.add(index);const matrix=multiply(parent,nodeMatrix(node));if(Number.isInteger(node.mesh)){const mesh=meshes[node.mesh];if(!mesh)throw Error('Mesh ausente.');for(const primitive of mesh.primitives||[]){if((primitive.mode??4)!==4)continue;if(primitive.attributes?.POSITION===undefined)continue;
  const pos=accessor(primitive.attributes.POSITION),norm=primitive.attributes.NORMAL!==undefined?accessor(primitive.attributes.NORMAL):null,uv=primitive.attributes.TEXCOORD_0!==undefined?accessor(primitive.attributes.TEXCOORD_0):null,col=primitive.attributes.COLOR_0!==undefined?accessor(primitive.attributes.COLOR_0):null;
  let joints=null,weights=null;
  // Atributos de skinning incompatíveis não impedem a leitura estática do GLB.
  try{joints=primitive.attributes.JOINTS_0!==undefined?accessor(primitive.attributes.JOINTS_0):null;weights=primitive.attributes.WEIGHTS_0!==undefined?accessor(primitive.attributes.WEIGHTS_0):null;}catch{joints=null;weights=null;}
  const indices=primitive.indices!==undefined?accessor(primitive.indices).map(r=>r[0]):pos.map((_,i)=>i),mat=json.materials?.[primitive.material]||{},pbr=mat.pbrMetallicRoughness||{},factor=pbr.baseColorFactor||[1,1,1,1];
  if(indices.length%3!==0)throw Error('Índices inválidos.');triangles+=indices.length/3;if(triangles>55000)throw Error('Limite de 55 mil triângulos por modelo.');
  const result={p:[],n:[],uv:[],c:[],textureIndex:pbr.baseColorTexture?.index};
  if((json.animations||[]).length){result.rig={nodeIndex:index,skinIndex:Number.isInteger(node.skin)?node.skin:null,localP:[],localN:[],joints:[],weights:[]};}
  for(let i=0;i<indices.length;i+=3){const ii=indices.slice(i,i+3);if(ii.some(j=>!Number.isInteger(j)||j<0||j>=pos.length))throw Error('Índice de vértice inválido.');const v=ii.map(j=>transformed(matrix,pos[j]));const ab=v[1].map((x,k)=>x-v[0][k]),ac=v[2].map((x,k)=>x-v[0][k]);const cross=[ab[1]*ac[2]-ab[2]*ac[1],ab[2]*ac[0]-ab[0]*ac[2],ab[0]*ac[1]-ab[1]*ac[0]],length=Math.hypot(...cross)||1;const face=cross.map(x=>x/length);
   ii.forEach((j,k)=>{result.p.push(...v[k]);result.n.push(...(norm?.[j]?transformNormal(matrix,norm[j]):face));result.uv.push(uv?.[j]?.[0]||0,1-(uv?.[j]?.[1]||0));const cc=col?.[j]||[1,1,1];result.c.push((cc[0]??1)*factor[0],(cc[1]??1)*factor[1],(cc[2]??1)*factor[2]);
    if(result.rig){result.rig.localP.push(...pos[j]);result.rig.localN.push(...(norm?.[j]||face));if(joints&&weights&&node.skin!==undefined){result.rig.joints.push(...joints[j]);result.rig.weights.push(...weights[j]);}}});
  }
  primitives.push(result);
 }}
 for(const child of node.children||[])walk(child,matrix,depth+1);seen.delete(index);}
 for(const node of roots)walk(node,ID,0);
 if(!primitives.length||!triangles)throw Error('Nenhuma geometria triangular encontrada.');
 const bounds={min:[Infinity,Infinity,Infinity],max:[-Infinity,-Infinity,-Infinity]};for(const primitive of primitives)for(let i=0;i<primitive.p.length;i+=3)for(let k=0;k<3;k++){const v=primitive.p[i+k];bounds.min[k]=Math.min(bounds.min[k],v);bounds.max[k]=Math.max(bounds.max[k],v);}
 if(!bounds.min.every(Number.isFinite)||Math.max(...bounds.max.map((v,k)=>v-bounds.min[k]))<=0)throw Error('Geometria GLB degenerada.');
 return {json,bin,primitives,triangles,bounds};
}
async function embeddedImages(parsed){const out=[];const json=parsed.json,views=json.bufferViews||[];
 for(const texture of json.textures||[]){const image=json.images?.[texture.source];if(!image||!Number.isInteger(image.bufferView)||!['image/png','image/jpeg'].includes(image.mimeType)){out.push(null);continue;}
  const view=views[image.bufferView],start=view?.byteOffset||0,end=start+(view?.byteLength||0);if(!view||end>parsed.bin.length){out.push(null);continue;}
  if(!root.createImageBitmap){out.push(null);continue;}
  const blob=new Blob([parsed.bin.subarray(start,end)],{type:image.mimeType});
  try{out.push(await root.createImageBitmap(blob));}catch{out.push(null);}
 }
 return out;
}
root.AstronyxGLB={parseGLB,embeddedImages,nodeMatrix,multiply};
if(typeof module!=='undefined'&&module.exports)module.exports={parseGLB,nodeMatrix,multiply,transformed};
})(typeof window!=='undefined'?window:globalThis);
