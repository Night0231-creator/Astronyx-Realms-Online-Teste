(function(){'use strict';
const $=id=>document.getElementById(id),board={width:14,height:10,cells:{},fog:[],lighting:'day',showGrid:true};
const put=(x,y,data)=>{board.cells[x+','+y]={floor:'grass',height:0,walls:{},...data};};
for(let y=0;y<10;y++)for(let x=0;x<14;x++){
 let cell={floor:(x>=3&&x<=10&&y>=2&&y<=7)?'stone':'grass',height:0,walls:{}};
 if(x===3||x===10){if(y>=2&&y<=7)cell.walls[x===3?'w':'e']='stone';}
 if(y===2||y===7){if(x>=3&&x<=10)cell.walls[y===2?'n':'s']='stone';}
 if(x===7&&y===7)cell.walls.s='door';
 if([4,9].includes(x)&&[3,6].includes(y)){cell.prop='pillar';cell.height=1;}
 if(x===6&&y===4){cell.prop='altar';cell.light=2;}
 if(y===8&&x%3===0)cell.prop='tree';
 if(y===1&&x%3===1)cell.prop='tree';
 if(x===2&&y===5){cell.prop='fountain';}
 if(x===11&&y===6)cell.prop='well';
 if(x>=5&&x<=8&&y>=3&&y<=6){cell.stories={'1':{floor:'wood',walls:{},prop:(x===5&&y===4)?'banner':null,light:0}};}
 if(x>=6&&x<=7&&y>=4&&y<=5){cell.stories['2']={floor:'marble',walls:{},prop:x===6&&y===4?'spire':null,light:0};}
 if(x===5&&y===3)cell.stories['1'].walls.n='window';
 if(x===8&&y===3)cell.stories['1'].walls.n='window';
 if(x===6&&y===6)cell.stories['1'].walls.s='door';
 put(x,y,cell);
}
let viewer;
try{viewer=new Astronyx3D.Viewer($('viewport'));viewer.update(board,[{x:7,y:8,kind:'hero',label:'Guardião'}],null,0,2);viewer.reset();$('status').textContent='✓ Cena pronta · câmera livre';}
catch(e){$('status').textContent='WebGL indisponível: '+e.message;return;}
const sync=()=>{$('yaw').value=Math.round(viewer.yaw);$('pitch').value=Math.round(viewer.pitch);$('yawLabel').textContent=Math.round(viewer.yaw)+'°';$('pitchLabel').textContent=Math.round(viewer.pitch)+'°';};
$('yaw').addEventListener('input',e=>{viewer.yaw=+e.target.value;viewer.render();sync();});$('pitch').addEventListener('input',e=>{viewer.pitch=+e.target.value;viewer.render();sync();});
$('projection').addEventListener('change',e=>viewer.setProjection(e.target.value));$('lighting').addEventListener('change',e=>{board.lighting=e.target.value;viewer.update(board,viewer.tokens,null,0,viewer.hideAbove);});
$('stories').addEventListener('change',e=>viewer.update(board,viewer.tokens,null,0,+e.target.value));
$('zoomIn').addEventListener('click',()=>viewer.zoom(-135));$('zoomOut').addEventListener('click',()=>viewer.zoom(135));$('reset').addEventListener('click',()=>{viewer.reset();sync();});$('focus').addEventListener('click',()=>viewer.focus(7,8));
const cv=$('viewport');let drag=null,pointers=new Map(),pinch=0;
cv.addEventListener('contextmenu',e=>e.preventDefault());cv.addEventListener('wheel',e=>{e.preventDefault();viewer.zoom(e.deltaY);},{passive:false});
cv.addEventListener('pointerdown',e=>{cv.setPointerCapture(e.pointerId);pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});drag={x:e.clientX,y:e.clientY,mode:e.shiftKey?'pan':'rotate'};if(pointers.size>=2){const ps=[...pointers.values()];pinch=Math.hypot(ps[0].x-ps[1].x,ps[0].y-ps[1].y);}});
cv.addEventListener('pointermove',e=>{if(!drag||!pointers.has(e.pointerId))return;const old=pointers.get(e.pointerId);pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});if(pointers.size>=2){const ps=[...pointers.values()],dist=Math.hypot(ps[0].x-ps[1].x,ps[0].y-ps[1].y);if(pinch)viewer.zoom((pinch-dist)*2);pinch=dist;}else if(drag.mode==='pan')viewer.pan(e.clientX-drag.x,e.clientY-drag.y);else viewer.orbit(e.clientX-drag.x,e.clientY-drag.y);drag={...drag,x:e.clientX,y:e.clientY};sync();});
for(const type of ['pointerup','pointercancel'])cv.addEventListener(type,e=>{pointers.delete(e.pointerId);if(!pointers.size)drag=null;});
window.addEventListener('resize',()=>viewer.render());window.addEventListener('keydown',e=>{if(/INPUT|TEXTAREA|SELECT/.test(document.activeElement?.tagName||''))return;const k=e.key.toLowerCase();if(k==='q'||k==='e'){viewer.orbit(k==='q'?-25:25,0);sync();}if(k==='r'||k==='f'){viewer.orbit(0,k==='r'?-25:25);sync();}});
})();
