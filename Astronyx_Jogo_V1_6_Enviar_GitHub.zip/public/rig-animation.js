/* Astronyx V1.1: GLB animation sampler, node hierarchy and CPU skinning.
   glTF 2.0 embedded LINEAR/STEP translation/rotation/scale channels.
   Unsupported morphs, compressed and cubic-spline channels gracefully fall back. */
(function(root){
'use strict';
const mul=(a,b)=>{const o=new Array(16).fill(0);for(let c=0;c<4;c++)for(let r=0;r<4;r++)for(let k=0;k<4;k++)o[c*4+r]+=a[k*4+r]*b[c*4+k];return o;};
const identity=()=>[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1];
const transform=(m,v,w)=>[m[0]*v[0]+m[4]*v[1]+m[8]*v[2]+m[12]*w,m[1]*v[0]+m[5]*v[1]+m[9]*v[2]+m[13]*w,m[2]*v[0]+m[6]*v[1]+m[10]*v[2]+m[14]*w];
const clamp=(x,a,b)=>Math.min(b,Math.max(a,x));
function quatBlend(a,b,t){let dot=a.reduce((v,n,i)=>v+n*b[i],0);if(dot<0){b=b.map(v=>-v);dot=-dot;}if(dot>.9995){const q=a.map((n,i)=>n+(b[i]-n)*t),d=Math.hypot(...q)||1;return q.map(v=>v/d);}dot=clamp(dot,-1,1);const theta=Math.acos(dot),s=Math.sin(theta),u=Math.sin((1-t)*theta)/s,v=Math.sin(t*theta)/s;return a.map((n,i)=>n*u+b[i]*v);}
function readAccessor(parsed,index){
 const j=parsed.json,a=j.accessors?.[index],view=j.bufferViews?.[a?.bufferView];
 if(!a||!view||view.buffer!==0||a.sparse)throw Error('Amostra de animação GLB inválida.');
 const count={SCALAR:1,VEC2:2,VEC3:3,VEC4:4,MAT4:16}[a.type],size={5121:1,5123:2,5125:4,5126:4}[a.componentType];
 if(!count||!size||a.count>40000||a.count<0)throw Error('Amostras de animação GLB excessivas.');
 const stride=view.byteStride||count*size,offset=(view.byteOffset||0)+(a.byteOffset||0),limit=(view.byteOffset||0)+view.byteLength;
 if(stride<count*size||stride>512||offset<0||offset+(Math.max(0,a.count-1))*stride+count*size>limit||limit>parsed.bin.byteLength)throw Error('Animação fora dos limites do GLB.');
 const dv=new DataView(parsed.bin.buffer,parsed.bin.byteOffset,parsed.bin.byteLength),r=[];
 for(let i=0;i<a.count;i++){const v=[];for(let k=0;k<count;k++){const at=offset+i*stride+k*size;let n=a.componentType===5126?dv.getFloat32(at,true):a.componentType===5125?dv.getUint32(at,true):a.componentType===5123?dv.getUint16(at,true):dv.getUint8(at);if(!Number.isFinite(n))throw Error('Valor de animação inválido.');if(a.normalized&&a.componentType!==5126)n/=a.componentType===5121?255:a.componentType===5123?65535:4294967295;v.push(n);}r.push(v);}
 return r;
}
function detectAction(name){const s=String(name||'').toLowerCase();if(/idle|breath|stand|rest|loop/.test(s))return 'idle';if(/ultimate|special|finisher|super/.test(s))return 'ultimate';if(/skill|cast|spell|magic|ability|heal/.test(s))return 'skill';if(/attack|slash|strike|swing|punch|shoot|fire|hit_/.test(s))return 'attack';if(/hurt|damage|impact|hit|stagger/.test(s))return 'hit';if(/death|die|dead|fall|collapse/.test(s))return 'death';if(/walk|run|move/.test(s))return 'walk';if(/block|guard|defend|shield/.test(s))return 'guard';return null;}
function build(parsed){
 const json=parsed.json||{},raw=json.animations||[],nodes=json.nodes||[],skins=json.skins||[],totalVertices=parsed.primitives.reduce((n,p)=>n+(p.rig?.localP.length||0)/3,0);
 if(!raw.length)return {clips:[],actions:{},animated:false,reason:'Modelo sem clipes internos'};
 if(totalVertices>18000)return {clips:[],actions:{},animated:false,reason:'Modelo acima do limite de 18 mil vértices animados'};
 const clips=[];
 for(const animation of raw.slice(0,36)){
  const channels=[];let duration=0;
  for(const channel of (animation.channels||[]).slice(0,200)){
   const node=channel.target?.node,path=channel.target?.path,sampler=animation.samplers?.[channel.sampler];
   if(!Number.isInteger(node)||!nodes[node]||!['translation','rotation','scale'].includes(path)||!sampler||!['STEP','LINEAR'].includes(sampler.interpolation||'LINEAR'))continue;
   try{const times=readAccessor(parsed,sampler.input).map(v=>v[0]),values=readAccessor(parsed,sampler.output),width=path==='rotation'?4:3;if(times.length!==values.length||!times.length||values.some(x=>x.length!==width)||times.some((v,i)=>v<0||(i&&v<times[i-1])))continue;duration=Math.max(duration,times.at(-1));channels.push({node,path,interpolation:sampler.interpolation||'LINEAR',times,values});}catch{/* invalid channel: other valid tracks stay available */}
  }
  if(channels.length)clips.push({name:String(animation.name||`Clip ${clips.length+1}`).slice(0,90),duration:Math.max(.001,duration),channels});
 }
 if(!clips.length)return {clips:[],actions:{},animated:false,reason:'Clipes sem canais LINEAR/STEP suportados'};
 const actions={};for(const clip of clips){const action=detectAction(clip.name);if(action&&!actions[action])actions[action]=clip.name;}
 // Sem clipe idle nomeado, mantemos a pose inicial do modelo, sem repetir um ataque em loop.
 const rest=nodes.map(node=>({translation:node.translation||[0,0,0],rotation:node.rotation||[0,0,0,1],scale:node.scale||[1,1,1],matrix:node.matrix||null,children:node.children||[]}));
 const bind=skins.map(s=>{if(!Array.isArray(s.joints)||s.joints.length>96)return null;let inverse;try{inverse=Number.isInteger(s.inverseBindMatrices)?readAccessor(parsed,s.inverseBindMatrices):s.joints.map(()=>identity());}catch{return null;}if(inverse.length!==s.joints.length||inverse.some(x=>x.length!==16))return null;return {joints:s.joints,inverse};});
 const roots=json.scenes?.[json.scene||0]?.nodes||nodes.map((_,i)=>i).filter(i=>!nodes.some(n=>n.children?.includes(i)));
 function pose(clip,time){
  const overrides=new Map(),when=clamp(time,0,clip.duration);
  for(const ch of clip.channels){const {times,values}=ch;let i=0;while(i<times.length-2&&times[i+1]<when)i++;const next=Math.min(i+1,times.length-1),a=times[i],b=times[next],t=ch.interpolation==='STEP'||a===b?0:clamp((when-a)/(b-a),0,1),v=ch.path==='rotation'?quatBlend(values[i],values[next],t):values[i].map((n,k)=>n+(values[next][k]-n)*t);if(!overrides.has(ch.node))overrides.set(ch.node,{});overrides.get(ch.node)[ch.path]=v;}
  const world=new Array(nodes.length),walk=(index,parent,depth)=>{if(depth>32||world[index])return;const n=rest[index],p=overrides.get(index)||{};const local=n.matrix&&!Object.keys(p).length?n.matrix:root.AstronyxGLB.nodeMatrix({...n,...p,matrix:undefined});world[index]=mul(parent,local);for(const child of n.children)walk(child,world[index],depth+1);};
  for(const r of roots)if(nodes[r])walk(r,identity(),0);for(let i=0;i<nodes.length;i++)if(!world[i])walk(i,identity(),0);
  return {world};
 }
 function deform(primitive,clipName,seconds){
  const rig=primitive.rig,clip=clips.find(c=>c.name===clipName);if(!rig||!clip)return null;
  const {world}=pose(clip,seconds),points=rig.localP,normals=rig.localN,resultP=new Float32Array(points.length),resultN=new Float32Array(normals.length);
  const skin=Number.isInteger(rig.skinIndex)?bind[rig.skinIndex]:null,mats=skin?skin.joints.map((node,i)=>world[node]?mul(world[node],skin.inverse[i]):identity()):null;
  const defaultMatrix=world[rig.nodeIndex]||identity();
  for(let i=0;i<points.length;i+=3){const v=points.slice(i,i+3),n=normals.slice(i,i+3),idx=i/3;let vp=[0,0,0],vn=[0,0,0],total=0;
   if(mats&&rig.joints.length>=idx*4+4){for(let k=0;k<4;k++){const weight=rig.weights[idx*4+k]||0,joint=rig.joints[idx*4+k];if(weight<=0||!Number.isInteger(joint)||!mats[joint])continue;const a=transform(mats[joint],v,1),b=transform(mats[joint],n,0);for(let d=0;d<3;d++){vp[d]+=weight*a[d];vn[d]+=weight*b[d];}total+=weight;}}
   if(total<=.0001){vp=transform(defaultMatrix,v,1);vn=transform(defaultMatrix,n,0);}else if(Math.abs(total-1)>.0001){vp=vp.map(x=>x/total);vn=vn.map(x=>x/total);}
   for(let d=0;d<3;d++)resultP[i+d]=vp[d];const len=Math.hypot(...vn)||1;for(let d=0;d<3;d++)resultN[i+d]=vn[d]/len;
  }
  return {positions:resultP,normals:resultN};
 }
 // Crossfade leve para GLB compatíveis, sem alterar o estado da batalha.
 // Blending é feito em coordenadas de malha: não exige retargeting entre rigs.
 function deformBlend(primitive,fromName,fromSeconds,toName,toSeconds,alpha){
  const k=clamp(Number(alpha)||0,0,1);
  if(!fromName||k>=1)return deform(primitive,toName,toSeconds);
  if(!toName||k<=0)return deform(primitive,fromName,fromSeconds);
  const from=deform(primitive,fromName,fromSeconds),to=deform(primitive,toName,toSeconds);
  if(!from)return to;if(!to)return from;
  if(from.positions.length!==to.positions.length)return to;
  const positions=new Float32Array(to.positions.length),normals=new Float32Array(to.normals.length);
  for(let i=0;i<positions.length;i++)positions[i]=from.positions[i]*(1-k)+to.positions[i]*k;
  for(let i=0;i<normals.length;i+=3){
   const x=from.normals[i]*(1-k)+to.normals[i]*k,y=from.normals[i+1]*(1-k)+to.normals[i+1]*k,z=from.normals[i+2]*(1-k)+to.normals[i+2]*k,len=Math.hypot(x,y,z)||1;
   normals[i]=x/len;normals[i+1]=y/len;normals[i+2]=z/len;
  }
  return {positions,normals};
 }
 return {clips:clips.map(({name,duration})=>({name,duration})),actions,animated:true,deform,deformBlend,reason:null};
}
root.AstronyxRig={build,detectAction,quatBlend};
if(typeof module!=='undefined'&&module.exports)module.exports={build,detectAction,quatBlend,readAccessor};
})(typeof window!=='undefined'?window:globalThis);
