(() => {
'use strict';
const API_BASE=String(window.ASTRONYX_API_BASE||'').trim().replace(/\/$/,'');
const $ = sel => document.querySelector(sel);
const $$ = sel => [...document.querySelectorAll(sel)];
const CLASSES = { guardian:{label:'Guardião',image:'guardian.png'}, arcanist:{label:'Arcanista',image:'arcanist.png'}, healer:{label:'Clérigo',image:'healer.png'}, ranger:{label:'Patrulheiro',image:'ranger.png'} };
const ABILITIES={str:'Força',dex:'Destreza',con:'Constituição',int:'Inteligência',wis:'Sabedoria',cha:'Carisma'};
const TACTICAL_STATES={burn:['🔥','Queimadura','negative'],bleed:['🩸','Sangramento','negative'],poison:['☠','Veneno','negative'],exposed:['🎯','Exposto','negative'],weakened:['⬇','Fraqueza','negative'],regen:['✚','Regeneração','positive'],barrier:['⬡','Barreira','positive'],empowered:['✦','Poder ampliado','positive']};
function statusMarkup(effects){
  const safe=Array.isArray(effects)?effects:[];
  if(!safe.length)return '<span class="coop-no-effects">Nenhum efeito ativo</span>';
  return safe.map(s=>{
    const [icon,name,tone]=TACTICAL_STATES[s.id]||['✧','Efeito','neutral'];
    return `<span class="coop-effect-chip ${tone}" title="${enc(name)} • ${Math.max(1,Math.round(s.turns||1))} rodadas"><b>${icon}</b> ${enc(name)}${s.stacks>1?' ×'+Math.min(3,s.stacks):''}<small>${Math.max(1,Math.round(s.turns||1))}r</small></span>`;
  }).join('');
}

const SCENES = {forest:'Bosque de Eldrath',crystal:'Galerias de Cristal',ember:'Fortaleza Ígnea'};
const enc = s=>String(s??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
const img = name=>'/assets/'+encodeURIComponent(name||'guardian.png');
const percent = (n,max)=>Math.max(0,Math.min(100,Math.round(100*(Number(n)||0)/Math.max(1,max||1))));
const moodForScene=scene=>({forest:'Névoa do Bosque',crystal:'Ecos Cristalinos',ember:'Brasas de Guerra'})[scene]||'Expedição Arcana';
const specialReadyLabel=member=>!member ? '' : (member.specialReady===false?'Habilidade recarregando':'Habilidade pronta');
function latestBattleEvent(auto){return (auto?.fx||[]).filter(e=>e.kind!=='intro').at(-1)||null;}
function battleActionSummary(auto,members){
  const e=latestBattleEvent(auto);
  if(!e)return {title:'Companhia pronta',detail:'Forme o grupo e inicie o encontro para abrir a arena.',left:moodForScene(state?.room?.scene),right:'Sem ações recentes'};
  const actor=e.actorId?members.find(x=>x.id===e.actorId):null;
  const actorName=actor?.name||e.name||'A companhia';
  if(e.kind==='loot_drop')return {title:`${e.name||'Aventureiro'} encontrou um tesouro`,detail:`${e.itemName||'Equipamento'} (${RPG_RARITIES[e.rarity]||'Raro'}). Confira o Arsenal!`,left:'Tesouro',right:'Inventário atualizado'};
  if(e.kind==='status_tick')return {title:`${e.name||'Combatente'} sofreu um efeito`,detail:e.damage?`Dano contínuo: ${e.damage} HP.`:`Regeneração: +${e.healed||0} HP.`,left:'Efeito tático',right:e.damage?'Dano ao longo do tempo':'Recuperação'};
  if(e.kind==='status')return {title:'Estado aplicado',detail:`Novo efeito: ${TACTICAL_STATES[e.status]?.[1]||'Status'}.`,left:'Tática',right:'Status ativo'};
  if(e.kind==='victory')return {title:'Vitória da companhia',detail:`Recompensas entregues: +${e.xp||0} XP e +${e.gold||0} ouro.`,left:'Tesouros garantidos',right:e.boss?'Chefe derrotado':'Inimigo abatido'};
  if(e.kind==='defeat')return {title:'Derrota na expedição',detail:'Reorganize a formação e tente novamente com outra estratégia.',left:'Companhia caída',right:'Recuar e reagrupar'};
  if(e.kind==='phase')return {title:`${e.name||'Chefe'} mudou de fase`,detail:`A arena ficou mais perigosa. Intensifique buffs, cura e defesa.`,left:`Fase ${e.phase||1}/3`,right:'Perigo elevado'};
  if(e.kind==='enemy_attack')return {title:`${e.name||'Inimigo'} contra-atacou`,detail:`Pressão total sobre a linha de frente. Ajuste a defesa e o sustain.`,left:e.damage?`Dano ${e.damage}`:moodForScene(state?.room?.scene),right:'Turno do inimigo'};
  if(e.kind==='heal')return {title:`${actorName} restaurou a equipe`,detail:e.healed?`Recuperação de ${e.healed} HP e manutenção do ritmo da party.`:'A energia vital da companhia foi restaurada.',left:e.healed?`+${e.healed} HP`:specialReadyLabel(actor),right:'Suporte ativo'};
  if(e.kind==='guard')return {title:`${actorName} ergueu a guarda`,detail:'Postura defensiva ativada. O próximo impacto será bastante reduzido.',left:'Mitigação pronta',right:'Linha segura'};
  if(e.kind==='ultimate')return {title:`${actorName} liberou ${e.skill||'uma Suprema'}`,detail:e.healed?`Uma onda de poder curou ${e.healed} HP no grupo e causou ${e.damage||0} de dano.`:`Impacto devastador de ${e.damage||0} de dano no inimigo!`,left:'ULTIMATE',right:CLASSES[e.classId]?.label||'Especial'};
  if(e.kind==='skill')return {title:`${actorName} usou ${e.skill||'uma habilidade'}`,detail:e.damage?`Explosão de poder causando ${e.damage} de dano${e.crit?' crítico':''}.`:'Técnica especial executada.',left:e.combo?`Combo x${e.combo}`:specialReadyLabel(actor),right:CLASSES[e.classId]?.label||'Técnica'};
  return {title:`${actorName} atacou`,detail:e.damage?`Golpe direto causando ${e.damage} de dano${e.crit?' crítico':''}.`:'A ofensiva da party continua.',left:e.combo?`Combo x${e.combo}`:moodForScene(state?.room?.scene),right:e.crit?'Crítico':'Ataque básico'};
}
function createSparkBurst(layer,count=7,side='enemy',duration=850){
  for(let i=0;i<count;i++){
    const spark=document.createElement('div');
    spark.className='combat-vfx hit-spark';
    spark.textContent=Math.random()>.5?'✦':'✧';
    spark.style.setProperty('--fx-speed',duration+'ms');
    spark.style.left=(side==='hero'?28:68)+(Math.random()*12-6)+'%';
    spark.style.top=(side==='hero'?46:38)+(Math.random()*18-9)+'%';
    spark.style.color=side==='hero'?'#9dffc4':'#ffd08f';
    layer.append(spark);
    setTimeout(()=>spark.remove(),duration+80);
  }
}
const saved=()=>{try{return JSON.parse(localStorage.getItem('astronyx_sessions')||'{}');}catch{return {};}};
let sheetTargetId=null;
let accountToken=localStorage.getItem('astronyx_account_session')||'';
let account=null,authConfig=null,accountRooms=[];

let fxSeen=0,fxRoom=null,fxQueue=[],fxBusy=false;
let combatStage=null,combatStageRoom=null,combat3dPreference='3d',combatPresenter=null;
function destroyCombatStage(){if(combatStage){combatStage.destroy();combatStage=null;}combatStageRoom=null;}
function fallbackCombat3D(message){
  destroyCombatStage();combat3dPreference='2d';
  localStorage.setItem('astronyx_coop_view','2d');
  const switcher=$('#coop-view');if(switcher)switcher.value='2d';
  $('#encounter-arena')?.classList.remove('three-d-enabled');
  toast('Visão 3D indisponível: '+message+'. Usando arena 2D.');
}
async function fetchRoomGLB(id){
  if(!roomId||!session)throw Error('Entre na campanha antes de carregar modelos.');
  const headers={Authorization:'Bearer '+session};
  if(accountToken)headers['X-Astronyx-Account']=accountToken;
  const response=await fetch(API_BASE+'/api/models/file/'+encodeURIComponent(id)+'?room='+encodeURIComponent(roomId),{headers});
  if(!response.ok)throw Error('Modelo não encontrado ou acesso negado.');
  return response.arrayBuffer();
}
const MODEL_SLOT_LABELS={guardian:'Guardião',arcanist:'Arcanista',healer:'Clérigo',ranger:'Patrulheiro',enemy:'Inimigo comum',boss:'Chefe'};
function renderModelWorkshop(){
 const panel=$('#model-workshop');if(!panel||!state)return;
 panel.hidden=state.room.mode!=='auto'||state.me.role!=='gm';
 if(panel.hidden)return;
 const library=state.modelLibrary||{models:[],slots:{}};
 const models=library.models||[],slots=library.slots||{},slot=$('#model-slot').value;
 const choice=$('#model-choice');
 choice.innerHTML='<option value="">Miniatura padrão</option>'+models.map(model=>`<option value="${enc(model.id)}">${enc(model.name)} (${enc(MODEL_SLOT_LABELS[model.slot]||model.slot)})</option>`).join('');
 choice.value=slots[slot]||'';
 $('#model-library-list').innerHTML=models.length?models.map(model=>`<div class="model-library-item"><span><strong>${enc(model.name)}</strong><small>${enc(MODEL_SLOT_LABELS[model.slot]||model.slot)} · ${(model.size/1048576).toFixed(2)} MB ${slots[model.slot]===model.id?'· ATIVO':''}</small></span><button class="button-outline" type="button" data-delete-model="${enc(model.id)}">Excluir</button></div>`).join(''):'<div class="model-library-item">Nenhum modelo importado. Os personagens usarão miniaturas padrão.</div>';
}
function setupModelWorkshop(){
 $('#model-slot').addEventListener('change',renderModelWorkshop);
 $('#model-upload').addEventListener('click',async()=>{
  const file=$('#model-file').files?.[0],btn=$('#model-upload');if(!file)return toast('Selecione um arquivo .glb.');
  if(!/\.glb$/i.test(file.name))return toast('O arquivo precisa ter extensão .glb.');
  if(file.size>8*1024*1024)return toast('Limite de 8 MB por modelo.');
  btn.disabled=true;btn.textContent='Enviando GLB...';
  try{const headers={'Content-Type':'model/gltf-binary','X-Model-Name':file.name.replace(/\.glb$/i,''),'Authorization':'Bearer '+session};if(accountToken)headers['X-Astronyx-Account']=accountToken;
   const response=await fetch(API_BASE+'/api/models/upload?room='+encodeURIComponent(roomId)+'&slot='+encodeURIComponent($('#model-slot').value),{method:'POST',headers,body:await file.arrayBuffer()});
   const result=await response.json();if(!response.ok)throw Error(result.error||'Falha ao enviar modelo.');
   $('#model-file').value='';toast('Modelo importado para a campanha!','success');await loadState();
  }catch(err){toast(err.message);}finally{btn.disabled=false;btn.textContent='↑ Importar modelo';}
 });
 $('#model-apply').addEventListener('click',async()=>{const result=await api('POST','/api/models/select?room='+encodeURIComponent(roomId),{slot:$('#model-slot').value,id:$('#model-choice').value||null});if(result){toast('Aparência aplicada para todos na sala.','success');await loadState();}});
 $('#model-library-list').addEventListener('click',async e=>{const btn=e.target.closest('[data-delete-model]');if(!btn)return;if(!confirm('Excluir este modelo da biblioteca e do servidor?'))return;const result=await api('POST','/api/models/remove?room='+encodeURIComponent(roomId),{id:btn.dataset.deleteModel});if(result){toast('Modelo excluído.','success');await loadState();}});
}
function syncCombatStage(){
  if(!state||state.room.mode!=='auto'||combat3dPreference!=='3d'){
    destroyCombatStage();$('#encounter-arena')?.classList.remove('three-d-enabled');return;
  }
  if(!combatStage||combatStageRoom!==state.room.id){
    destroyCombatStage();
    try{
      combatStage=new window.AstronyxCombat3D.CombatStage($('#coop-3d-canvas'),{onFailure:fallbackCombat3D,fetchModel:fetchRoomGLB});
      combatStageRoom=state.room.id;
      combatStage.setCamera($('#coop-camera')?.value||'cinematic');
      combatStage.smoothTransitions=$('#coop-smooth')?.checked!==false;
      combatStage.weaponFxEnabled=$('#coop-weapon-fx')?.checked!==false;
    }catch(err){fallbackCombat3D(err.message);return;}
  }
  $('#encounter-arena').classList.add('three-d-enabled');
  try{combatStage.sync(state);}catch(err){fallbackCombat3D(err.message);}
}

let state=null,session=null,roomId=null,selected=null,entryTab='create',entryMode='tabletop',feedTab='log',stopStream=null,connecting=false,lastRevision=0;
function toast(message,type='error'){
  const el=document.createElement('div');el.className='toast '+type;el.textContent=message;$('#toast-stack').append(el);
  setTimeout(()=>el.remove(),4800);
}
async function api(method,path,body=null){
  const headers={'Content-Type':'application/json'};
  if(session)headers.Authorization='Bearer '+session;
  if(accountToken)headers['X-Astronyx-Account']=accountToken;
  let response;
  try{response=await fetch(API_BASE+path,{method,headers,body:body===null?undefined:JSON.stringify(body)});}catch{throw new Error('Sem conexão com o servidor. Confira se iniciar.bat está aberto.');}
  let result;try{result=await response.json();}catch{throw new Error('O servidor retornou uma resposta inválida.');}
  if(!response.ok)throw new Error(result.error||'Ocorreu um erro.');
  return result;
}
function setConnection(online){$('#connection-dot').classList.toggle('offline',!online);$('#connection-label').textContent=online?'Sincronizado':'Reconectando';}
function putState(next){
  if(!next)return;
  if(state?.room.id===next.room.id && next.room.revision<state.room.revision)return;
  const freshEvents=next.room.mode==='auto'&&fxRoom===next.room.id?(next.auto.fx||[]).filter(e=>e.seq>fxSeen).slice(-10):[];
  if(next.room.mode==='auto'){fxRoom=next.room.id;fxSeen=next.auto.fxSeq||0;}
  state=next;lastRevision=next.room.revision;
  if(!selected){selected=state.tokens.find(t=>t.ownerId===state.me.id)?.id||null;}
  render();
  if(freshEvents.length){fxQueue.push(...freshEvents);fxQueue=fxQueue.slice(-18);playNextFx();}
}
async function loadState(){if(!roomId||!session)return;const result=await api('GET','/api/state?room='+encodeURIComponent(roomId));putState(result.state);}
function remember(){const s=saved();s[roomId]=session;localStorage.setItem('astronyx_sessions',JSON.stringify(s));}
async function enterRoom(id,token,firstState){
  roomId=id;session=token;remember();
  $('#landing').hidden=true;$('#game').hidden=false;
  history.replaceState(null,'','/?s='+encodeURIComponent(roomId));
  if(firstState)putState(firstState);else await loadState();
  setConnection(true);connectUpdates();
  updateAccountButtons();
}
async function connectUpdates(){
  if(stopStream)stopStream();
  const controller=new AbortController();let running=true;
  stopStream=()=>{running=false;controller.abort();};
  while(running){
    try{
      const res=await fetch(API_BASE+'/api/events?room='+encodeURIComponent(roomId),{headers:{Authorization:'Bearer '+session,...(accountToken?{'X-Astronyx-Account':accountToken}:{})},signal:controller.signal});
      if(!res.ok)throw new Error('Falha na conexão em tempo real.');
      setConnection(true);
      const reader=res.body.getReader();const decoder=new TextDecoder();let buf='';
      while(running){
        const {value,done}=await reader.read();if(done)break;
        buf+=decoder.decode(value,{stream:true});
        const frames=buf.split('\n\n');buf=frames.pop();
        for(const frame of frames){
          const line=frame.split('\n').find(l=>l.startsWith('data: '));
          if(!line)continue;
          try{const data=JSON.parse(line.slice(6));if(data.revision>lastRevision)await loadState();}catch(e){console.warn('SSE:',e.message);}
        }
      }
      if(running)throw new Error('Conexão encerrada.');
    }catch(e){if(!running)break;setConnection(false);await new Promise(r=>setTimeout(r,1900));}
  }
}
function leave(){combatPresenter?.clear();destroyCombatStage();fxRoom=null;fxSeen=0;fxQueue=[];window.AstronyxBuilder?.open(false);if(stopStream)stopStream();stopStream=null;session=null;roomId=null;state=null;selected=null;lastRevision=0;$('#game').hidden=true;$('#landing').hidden=false;history.replaceState(null,'','/');updateAccountButtons();}
function setupEntry(){
  $$('.tab[data-tab]').forEach(btn=>btn.addEventListener('click',()=>{
    entryTab=btn.dataset.tab;
    $$('.tab').forEach(b=>{const active=b===btn;b.classList.toggle('active',active);b.setAttribute('aria-selected',String(active));});
    $('#create-fields').hidden=entryTab!=='create';$('#join-fields').hidden=entryTab!=='join';
    $('#entry-submit').innerHTML=entryTab==='create'?'CRIAR MINHA AVENTURA <span>→</span>':'ENTRAR NA SALA <span>→</span>';
  }));
  $$('.mode-choice').forEach(btn=>btn.addEventListener('click',()=>{
    entryMode=btn.dataset.mode;
    $$('.mode-choice').forEach(b=>{const active=b===btn;b.classList.toggle('selected',active);b.setAttribute('aria-pressed',String(active));});
  }));
  const requested=new URLSearchParams(location.search).get('s');
  if(requested){$('.tab[data-tab="join"]').click();$('#room-code').value=requested.toUpperCase();}
  $('#player-name').value=localStorage.getItem('astronyx_last_name')||'';
  $('#entry-form').addEventListener('submit',async e=>{
    e.preventDefault();if(connecting)return;
    connecting=true;const btn=$('#entry-submit');btn.disabled=true;
    const name=$('#player-name').value.trim(),classId=$('#player-class').value;
    try{
      const payload=entryTab==='create'
        ? {title:$('#campaign-title').value,mode:entryMode,name,classId,characterId:$('#library-character').value||undefined}
        : {roomId:$('#room-code').value.trim().toUpperCase(),name,classId,characterId:$('#library-character').value||undefined};
      const result=await api('POST',entryTab==='create'?'/api/create':'/api/join',payload);
      localStorage.setItem('astronyx_last_name',name);
      await enterRoom(result.roomId,result.session,result.state);
      if(account)refreshAccount().catch(()=>{});
      toast('Campanha conectada. A aventura começa agora!','success');
    }catch(err){toast(err.message);}finally{btn.disabled=false;connecting=false;}
  });
  $('#leave-room').addEventListener('click',leave);
  $('#copy-code').addEventListener('click',async()=>{
    const link=location.origin+'/?s='+roomId;
    try{await navigator.clipboard.writeText(link);toast('Link de convite copiado!','success');}
    catch{window.prompt('Copie seu convite:',link);}
  });
}
async function action(data){if(!roomId)return;try{const result=await api('POST','/api/action?room='+encodeURIComponent(roomId),data);putState(result.state);return result;}catch(e){toast(e.message);return null;}}
function render(){
  const {room,members,me}=state;
  $('#room-mode-name').textContent=room.mode==='auto'?'✦ AVENTURA COOPERATIVA':'✦ MESA COM MESTRE';
  $('#room-title').textContent=room.title;
  $('#room-code-label').textContent=room.id;
  $('#scene-overline').textContent=room.mode==='auto'?'✦ ARENA DE COMBATE':'✦ TERRITÓRIO ATUAL';
  $('#scene-title').textContent=SCENES[room.scene]||room.scene;
  $('#turn-badge').textContent=room.mode==='auto'?`RODADA ${state.auto.round}`:`TURNO ${room.turn}`;
  $('#party-count').textContent=`${members.length}/8`;
  $('#mode-helper').textContent=room.mode==='auto'?'Cada herói age uma vez por rodada. Quando todos agirem, o inimigo ataca.':'Clique na sua peça e depois em uma casa. O mestre controla monstros, cenas e iniciativa.';
  $('#scene-select').hidden=room.mode!=='tabletop'||me.role!=='gm';$('#scene-select').value=room.scene;
  $('#tabletop-panel').hidden=room.mode!=='tabletop';$('#auto-panel').hidden=room.mode!=='auto';
  $('#builder-toggle').hidden=room.mode!=='tabletop';if(room.mode!=='tabletop')window.AstronyxBuilder?.open(false);
  $('#open-arsenal').hidden=room.mode!=='auto';
  renderParty();renderMyCharacter();if(room.mode==='tabletop')renderTabletop();else renderAuto();renderJournal();renderFeed();
}
function renderParty(){
  $('#party-list').innerHTML=state.members.map(m=>`<div class="party-item"><img class="party-avatar" src="${img(CLASSES[m.classId]?.image)}" alt=""/><div class="party-profile"><strong>${enc(m.name)} ${m.id===state.me.id?'✦':''}</strong><small>Nv. ${m.level} ${enc(CLASSES[m.classId]?.label||'Aventureiro')} ${m.role==='gm'?'· Mestre':''}</small><div class="mini-health"><span style="width:${percent(m.hp,m.maxHp)}%"></span></div></div></div>`).join('');
}
function renderMyCharacter(){
  const m=state.members.find(x=>x.id===state.me.id);if(!m)return;
  $('#my-character').innerHTML=`<div class="my-char-title"><img src="${img(CLASSES[m.classId].image)}" alt="Classe do personagem"/><div><strong>${enc(m.name)}</strong><small>NÍVEL ${m.level} • ${enc(CLASSES[m.classId].label)}</small></div></div><div class="char-stats"><div class="char-stat"><strong>${m.attack}</strong><small>ATAQUE</small></div><div class="char-stat"><strong>${m.armor}</strong><small>DEFESA</small></div><div class="char-stat"><strong>${m.hp}/${m.maxHp}</strong><small>HP</small></div></div><div class="char-details"><span>✦ ${m.xp} XP</span><b>◈ ${m.gold} ouro</b></div><div class="char-details"><span>Poções</span><b>${m.potions} disponíveis</b></div><button class=\"button-sheet\" data-view-sheet type=\"button\">Abrir ficha completa →</button>`;
}
function renderTabletop(){
  const board=state.build||{width:14,height:9,cells:{},fog:[]};
  $('#tabletop-map').className='tabletop-map scene-'+state.room.scene;
  $('#tabletop-map').style.aspectRatio=board.width+'/'+board.height;
  $('#map-grid').style.gridTemplateColumns=`repeat(${board.width},1fr)`;
  $('#map-grid').style.gridTemplateRows=`repeat(${board.height},1fr)`;
  if($('#map-grid').children.length!==board.width*board.height){$('#map-grid').replaceChildren();for(let y=0;y<board.height;y++)for(let x=0;x<board.width;x++){const cell=document.createElement('button');cell.type='button';cell.className='grid-cell';cell.dataset.x=x;cell.dataset.y=y;cell.setAttribute('aria-label',`Mover para coluna ${x+1}, linha ${y+1}`);$('#map-grid').append(cell);}}
  $('.map-corner').firstElementChild.textContent=board.width+' × '+board.height;
  $('#tabletop-map').style.backgroundImage='';
  $('#tabletop-controls').style.display=state.me.role==='gm'?'flex':'none';
  const activeToken=state.tokens.find(t=>t.id===selected);
  $('#selection-hint').textContent=activeToken ? `${activeToken.label} selecionado. Clique em uma casa vazia para mover.` : 'Selecione sua peça e depois uma casa para mover.';
  $('#map-tokens').innerHTML=state.tokens.map(t=>`<button type="button" class="token ${t.kind==='enemy'?'enemy':''} ${t.id===selected?'selected':''}" style="left:${(t.x+.5)*100/board.width}%;top:${(t.y+.5)*100/board.height}%;width:${Math.min(6.6,85/board.width)}%;height:${Math.min(9.9,85/board.height)}%" data-token-id="${enc(t.id)}" title="${enc(t.label)} • ${t.hp}/${t.maxHp} HP"><img src="${img(t.avatar)}" alt=""/><span class="token-hp"><i style="width:${percent(t.hp,t.maxHp)}%"></i></span><span class="token-label">${enc(t.label)}${state.room.activeTokenId===t.id?' ✦':''}</span></button>`).join('');
  const bar=$('#token-actions');
  if(activeToken && state.me.role==='gm'){
    bar.hidden=false;bar.innerHTML=`<strong>${enc(activeToken.label)} • ${activeToken.hp}/${activeToken.maxHp} HP</strong><button type="button" data-token-action="hurt">−5 HP</button><button type="button" data-token-action="heal">+5 HP</button>${activeToken.kind==='enemy'?'<button type="button" data-token-action="remove">Remover criatura</button>':''}`;
  }else bar.hidden=true;
  window.AstronyxBuilder?.renderTopdown(state);
  window.AstronyxBuilder?.render();
}
const RPG_RARITIES={common:'Comum',uncommon:'Incomum',rare:'Raro',epic:'Épico',legendary:'Lendário'};
const RPG_SLOTS={weapon:['⚔','Arma'],armor:['♜','Armadura'],charm:['✧','Amuleto']};
const RPG_TALENTS=[
 ['fury','⚔','Instinto de Batalha','+3 de ataque',2],['vitality','♥','Vigor Heroico','+18 de HP máximo',3],
 ['bulwark','⬡','Pele de Ferro','+2 de defesa',4],['specialist','✦','Mestre de Técnicas','+12% dano de habilidades e Supremas',5],
 ['insight','☼','Fluxo Arcano','+5 energia por ação',6],
];
const DUNGEON_LEVELS={normal:{label:'Explorador',hp:'100%',attack:'100%',reward:'100%',level:1},veteran:{label:'Veterano',hp:'145%',attack:'130%',reward:'135%',level:2},nightmare:{label:'Pesadelo',hp:'215%',attack:'165%',reward:'até 180%',level:4}};
const DAILY_MISSIONS=[['actions','⚔','Treinamento do Herói','Realize 5 ações',5,'50 ouro + 3 minérios'],['victories','✧','Caçador de Criaturas','Vença 3 encontros',3,'80 ouro + 3 essências'],['bosses','♜','Quebra-Coroas','Derrote 1 chefe',1,'120 ouro + 1 relíquia']];
const FORGE_RECIPES=[['forge_blade','⚔','Lâmina Rúnica','Arma rara • +11 ATQ',2,120,6,2,0],['forge_armor','♜','Couraça do Protetor','Armadura rara • +8 DEF / +24 HP',2,120,7,1,0],['forge_charm','✦','Pingente das Estrelas','Amuleto épico • +5 ATQ / +4 DEF / +24 HP',3,210,5,6,1],['forge_relic','☼','Coração de Eldrath','Arma lendária • +22 ATQ / +3 DEF / +12 HP',5,500,12,14,3]];
function renderExpeditions(){
  const panel=$('#expedition-panel');if(!panel||!state)return;
  panel.hidden=state.room.mode!=='auto';if(panel.hidden)return;
  const {auto,members,me}=state,m=members.find(p=>p.id===me.id),adventure=m?.adventure||{};
  const mats=adventure.materials||{},missions=adventure.missions||{},claimed=adventure.claimed||{};
  const diff=auto.difficulty||'normal',info=DUNGEON_LEVELS[diff]||DUNGEON_LEVELS.normal;
  const levelSelect=$('#expedition-difficulty');
  if(document.activeElement!==levelSelect)levelSelect.value=diff;
  const inBattle=auto.status==='active',gm=me.role==='gm';
  levelSelect.disabled=!gm||inBattle||auto.chainRemaining>0;
  $('#expedition-apply').disabled=!gm||inBattle||auto.chainRemaining>0;
  $('#expedition-stage').textContent=String(auto.stage).padStart(2,'0');
  const remaining=4-((auto.stage-1)%4);
  $('#expedition-next-boss').textContent=remaining===1?'CHEFE NESTE ANDAR':`CHEFE EM ${remaining} ANDARES`;
  $('#expedition-title').textContent=(SCENES[state.room.scene]||'Os Caminhos de Eldrath')+' • '+info.label;
  $('#expedition-description').textContent=`${info.label} · dificuldade compartilhada · ${auto.status==='active'?'Batalha em andamento':auto.status==='victory'?'Pronto para continuar':'Preparando expedição'}`;
  $('#expedition-difficulty-info').textContent=`Inimigos: ${info.hp} HP / ${info.attack} ataque • Recompensas: ${info.reward} • Nível ${info.level}+`;
  $('#expedition-day').textContent=adventure.day?`UTC ${adventure.day.split('-').reverse().join('/')}`:'Reinício 00:00 UTC';
  $('#expedition-resources').innerHTML=`<span>⛏ MINÉRIO <b>${Number(mats.ore)||0}</b></span><span>✦ ESSÊNCIA <b>${Number(mats.essence)||0}</b></span><span>♜ RELÍQUIA <b>${Number(mats.relic)||0}</b></span>`;
  $('#expedition-missions').innerHTML=DAILY_MISSIONS.map(([id,icon,name,description,total,reward])=>{
    const amount=Math.min(total,Number(missions[id])||0),isClaimed=!!claimed[id],done=amount>=total;
    return `<article class="expedition-card ${isClaimed?'completed':''}"><div class="expedition-card-icon">${icon}</div><div class="expedition-card-body"><strong>${name}</strong><small>${description}</small><div class="expedition-meter"><i style="width:${Math.floor(amount/total*100)}%"></i></div><span class="expedition-detail">${amount}/${total} • ${reward}</span></div><button type="button" class="button-outline" data-expedition-claim="${id}" ${isClaimed||!done?'disabled':''}>${isClaimed?'✓ Resgatado':done?'Resgatar':'Em andamento'}</button></article>`;
  }).join('');
  const count=(m.inventoryGear||[]).length;
  $('#expedition-recipes').innerHTML=FORGE_RECIPES.map(([id,icon,name,stats,minLevel,gold,ore,essence,relic])=>{
    const missing=gold>(m.gold||0)||ore>(mats.ore||0)||essence>(mats.essence||0)||relic>(mats.relic||0);
    const locked=m.level<minLevel,full=count>=30;
    const cost=[`${gold} ouro`,`${ore} minério`,`${essence} essência`,relic?`${relic} relíquia`:''].filter(Boolean).join(' • ');
    return `<article class="expedition-card"><div class="expedition-card-icon">${icon}</div><div class="expedition-card-body"><strong>${name}</strong><small>${stats}</small><span class="expedition-detail">Nv. ${minLevel} • ${cost}</span></div><button type="button" class="button-outline" data-expedition-craft="${id}" ${locked||missing||full||inBattle?'disabled':''}>${full?'Mochila cheia':locked?'Nível insuficiente':missing?'Faltam materiais':inBattle?'Em batalha':'Fabricar'}</button></article>`;
  }).join('');
}
function setupExpeditions(){
  const host=$('#expedition-panel');if(!host)return;
  host.addEventListener('click',async event=>{
    const btn=event.target.closest('button');if(!btn||btn.disabled)return;
    let payload;
    if(btn.id==='expedition-apply')payload={type:'dungeon_difficulty',difficulty:$('#expedition-difficulty').value};
    else if(btn.dataset.expeditionClaim)payload={type:'mission_claim',mission:btn.dataset.expeditionClaim};
    else if(btn.dataset.expeditionCraft)payload={type:'craft_item',recipe:btn.dataset.expeditionCraft};
    if(!payload)return;
    btn.disabled=true;
    const result=await action(payload);
    if(result)toast(payload.type==='craft_item'?'Item fabricado e colocado na mochila!':payload.type==='mission_claim'?'Contrato resgatado!':'Dificuldade atualizada!','success');
    else if(state)renderExpeditions();
  });
}
function renderProgression(){
 const panel=$('#progression-panel');if(!panel||!state)return;
 panel.hidden=state.room.mode!=='auto';if(panel.hidden)return;
 const m=state.members.find(x=>x.id===state.me.id);if(!m)return;
 const items=m.inventoryGear||[],gear=m.equipped||{},isBattle=state.auto.status==='active';
 $('#progression-hero-name').textContent=m.name;
 $('#progression-hero-level').textContent=`Nível ${m.level} • ${m.attack} ATQ • ${m.armor} DEF • ${m.maxHp} HP`;
 $('#progression-gold').textContent=m.gold;
 $('#progression-points').textContent=m.talentPoints||0;
 $('#progression-count').textContent=`${items.length}/30`;
 $('#progression-summary').textContent=`${items.length} itens • ${m.talentPoints||0} pontos de talento`;
 $('#progression-equipped').innerHTML=Object.entries(RPG_SLOTS).map(([slot,[icon,label]])=>{
   const it=items.find(x=>x.id===gear[slot]);
   return `<div class="progression-slot"><span class="progression-slot-icon">${icon}</span><b>${enc(label)}</b><small>${enc(it?.name||'Vazio')}</small>${it?`<button class="button-outline" type="button" data-unequip="${slot}" ${isBattle?'disabled':''}>Remover</button>`:''}</div>`;
 }).join('');
 const slotOrder={weapon:0,armor:1,charm:2};
 $('#progression-backpack').innerHTML=items.length?[...items].sort((a,b)=>slotOrder[a.slot]-slotOrder[b.slot]).map(it=>{
   const equipped=gear[it.slot]===it.id,locked=m.level<(it.requiredLevel||1);
   const stats=[it.attack?`⚔ +${it.attack}`:'',it.armor?`⬡ +${it.armor}`:'',it.hp?`♥ +${it.hp}`:''].filter(Boolean).join(' · ');
   return `<article class="progression-item" data-rarity="${enc(it.rarity)}"><span class="progression-rarity">${enc(RPG_RARITIES[it.rarity]||'Item')}</span><strong>${enc(it.name)}</strong><span class="item-type">${enc(RPG_SLOTS[it.slot]?.[1]||'Item')} • Nv. ${Number(it.requiredLevel)||1}</span><span class="item-stats">${stats}</span><button class="button-outline" type="button" data-equip-slot="${enc(it.slot)}" data-equip-item="${enc(it.id)}" ${equipped||locked||isBattle?'disabled':''}>${equipped?'Equipado':locked?'Nível insuficiente':'Equipar'}</button></article>`;
 }).join(''):'<div class="progression-empty">Você ainda não possui equipamentos.</div>';
 $('#progression-talents').innerHTML=RPG_TALENTS.map(([key,icon,name,description,minLevel])=>{
   const unlocked=!!m.talents?.[key],locked=m.level<minLevel,disabled=unlocked||locked||!m.talentPoints||isBattle;
   return `<div class="progression-talent ${unlocked?'unlocked':''}"><span class="talent-symbol">${icon}</span><span class="progression-talent-text"><strong>${enc(name)}</strong><small>${enc(description)} • Nv. ${minLevel}</small></span><button class="button-outline" type="button" data-talent="${key}" ${disabled?'disabled':''}>${unlocked?'✓ Feito':locked?'Bloqueado':'Aprender'}</button></div>`;
 }).join('');
 $('#progression-drops').innerHTML=(m.lastDrops||[]).slice().reverse().map(x=>`<span class="progression-drop">✦ ${enc(x.name)} · ${enc(RPG_RARITIES[x.rarity]||x.rarity)}</span>`).join('')||'<span>Vitórias podem revelar tesouros raros.</span>';
}
function setupProgression(){
 const host=$('#progression-panel');if(!host)return;
 host.addEventListener('click',async e=>{
  const btn=e.target.closest('button');if(!btn||btn.disabled)return;
  const type=btn.hasAttribute('data-talent')?'talent_unlock':'gear_equip';
  const payload=type==='talent_unlock'?{type,talent:btn.dataset.talent}:{type,slot:btn.dataset.equipSlot||btn.dataset.unequip,itemId:btn.dataset.equipItem||null};
  if(!payload.talent&&!payload.slot)return;
  btn.disabled=true;
  if(await action(payload))toast(type==='talent_unlock'?'Talento desbloqueado!':'Equipamento atualizado!','success');
 });
}
function renderAuto(){
  const {auto,members,me}=state;
  const m=members.find(x=>x.id===me.id);
  const arena=$('#encounter-arena');
  for(const cls of [...arena.classList])if(cls.startsWith('scene-'))arena.classList.remove(cls);
  arena.classList.add('encounter-arena','coop-arena','scene-'+state.room.scene);
  $('#encounter-number').textContent=String(auto.stage).padStart(2,'0');
  $('#round-number').textContent=`RODADA ${String(auto.round).padStart(2,'0')}`;
  $('#coop-combo').textContent=`✦ COMBO ${auto.partyCombo||0}`;
  $('#coop-combo').classList.toggle('charged',(auto.partyCombo||0)>=4);
  const momentum=Math.min(100,Math.round(((auto.partyCombo||0)/8)*100)+(auto.chainRemaining>0?12:0)+(auto.status==='active'?10:0));
  $('#coop-momentum').textContent=`RITMO ${momentum}%`;
  arena.dataset.boss=auto.enemy?.boss?'true':'false';
  arena.dataset.bossPhase=String(auto.enemy?.phase||1);
  const enemy=auto.enemy;
  const hpBar=enemy?percent(enemy.hp,enemy.maxHp):0;
  $('#enemy-center').innerHTML=enemy?`<div class="coop-enemy-portrait ${enemy.boss?'coop-boss':''}"><img class="enemy-image" src="${img(enemy.avatar)}" alt="${enc(enemy.name)}"/><span class="enemy-ground-glow"></span></div><span class="enemy-category">${enemy.boss?'CHEFE • FASE '+(enemy.phase||1)+'/3':'CRIATURA HOSTIL'}</span><h3>${enc(enemy.name)}</h3><div class="enemy-life"><span>HP ${enemy.hp} / ${enemy.maxHp}</span><span>${hpBar}%</span></div><div class="enemy-hp"><i style="width:${hpBar}%"></i></div>`:`<div class="arena-ready-icon">✦</div><h3>Sua jornada aguarda</h3><p>PREPARE SUA COMPANHIA</p>`;
  const latest=(auto.fx||[]).filter(e=>e.actorId).at(-1);
  const performer=members.find(x=>x.id===latest?.actorId)||m;
  $('#hero-stage').innerHTML=performer?`<div class="hero-avatar"><img src="${img(CLASSES[performer.classId]?.image)}" alt="${enc(performer.name)}"/></div><div class="hero-identity"><span>✧ ${enc(CLASSES[performer.classId]?.label||'Aventureiro')}</span><strong>${enc(performer.name)}</strong><small>HP ${performer.hp}/${performer.maxHp} • ${specialReadyLabel(performer)}</small><div class="ultimate-meter"><i style="width:${percent(performer.ultimateEnergy||0,100)}%"></i></div><small>SUPREMA ${performer.ultimateEnergy||0}%</small></div>`:'';
  $('#battle-party-strip').innerHTML=members.map(p=>`<div class="battle-party-pill ${auto.acted.includes(p.id)?'acted':''} ${p.autoEnabled?'bot-active':''}"><img src="${img(CLASSES[p.classId].image)}" alt=""/><span><strong>${enc(p.name)} ${p.hp<=0?'☠':''} ${p.autoEnabled?'⚡':''}</strong><small>${enc(CLASSES[p.classId].label)} • ♥ ${p.hp}/${p.maxHp}${auto.acted.includes(p.id)?' · agiu':''}</small><i class="coop-pill-hp"><i style="width:${percent(p.hp,p.maxHp)}%"></i></i><i class="coop-pill-ultimate"><i style="width:${percent(p.ultimateEnergy||0,100)}%"></i></i></span></div>`).join('');
  const heading={ready:'Prepare sua companhia',active:auto.acted.includes(me.id)?'Aguardando os companheiros':'Sua vez de agir',victory:'Vitória da companhia!',defeat:'Sua equipe foi derrotada'}[auto.status]||'Escolha uma ação';
  $('#auto-status-heading').textContent=heading;
  const texts={ready:'Inicie uma expedição para ganhar experiência e tesouros.',active:`Encontro ${auto.stage} • Rodada ${auto.round}. ${auto.chainRemaining>0?'Sequência automática em andamento.':'Combine habilidades, sustentação e combo.'}`,victory:'Tesouros e experiência distribuídos! Continue para a próxima aventura.',defeat:'O grupo caiu. Tente novamente com outra estratégia.'};
  $('#auto-status-text').textContent=texts[auto.status];
  $('#auto-progress-label').textContent=`ETAPA ${auto.stage} • NÍVEL ${m?.level||1}`;
  $('#auto-progress-bar').style.width=Math.min(100,(auto.stage%10)*10)+'%';
  $('#coop-mode-label').textContent=auto.chainRemaining>0?`SEQUÊNCIA • ${auto.chainRemaining} RESTANTES`:m?.autoEnabled?'AUTO INDIVIDUAL ATIVO':'COMBATE POR TURNOS';
  $('#coop-auto-enabled').checked=!!m?.autoEnabled;
  $('#coop-strategy').value=m?.autoStrategy||'balanced';
  $('#coop-fx-status').textContent=enemy?.boss?`CHEFE • Fase ${enemy.phase||1}/3 · Combo ${auto.partyCombo||0}`:`${auto.chainRemaining||0} batalhas na sequência · Combo ${auto.partyCombo||0}`;
  const intent=enemy?.intent;
  $('#coop-intent-name').textContent=intent?`${intent.icon||'⚔'} ${intent.name}`:'Aguardando encontro';
  $('#coop-intent-hint').textContent=intent?.hint||'A previsão aparecerá ao iniciar.';
  $('#coop-intent').classList.toggle('threat',Boolean(intent&&enemy?.boss));
  $('#coop-enemy-effects').innerHTML=statusMarkup(enemy?.effects);
  $('#coop-player-effects').innerHTML=statusMarkup(m?.effects);

  const summary=battleActionSummary(auto,members);
  $('#battle-action-card').innerHTML=`<span class="label">AÇÃO RECENTE</span><strong>${enc(summary.title)}</strong><small>${enc(summary.detail)}</small><div class="meta"><span>${enc(summary.left)}</span><span>${enc(summary.right)}</span></div>`;
  const eventLabels=(auto.fx||[]).slice(-5);
  $('#coop-event-list').innerHTML=eventLabels.length?eventLabels.map(ev=>`<span class="coop-event-item" title="${enc(ev.name||ev.skill||ev.kind)}">${enc(window.AstronyxPresentation?.eventLabel(ev)||ev.kind)}</span>`).join(''):'<span class="coop-event-item">Aguardando encontro</span>';
  if(combatPresenter?.arena){combatPresenter.arena.dataset.theme=window.AstronyxPresentation.themeForEvent(latestBattleEvent(auto)||{},combatPresenter.prefs.theme);combatPresenter.arena.dataset.presentation=combatPresenter.prefs.mode;}
  $('#coop-boss-banner').innerHTML=enemy?.boss?`<span>☠ CHEFE REGIONAL</span><strong>${enc(enemy.name)}</strong><small>FASE ${enemy.phase||1}/3</small>`:'';
  if(auto.status!=='active'){
    $('#auto-actions').innerHTML=`<button type="button" class="button-primary" data-auto="start_encounter" ${auto.chainRemaining>0?'disabled':''}>${auto.status==='victory'?'PRÓXIMO ENCONTRO':auto.status==='defeat'?'TENTAR NOVAMENTE':'INICIAR ENCONTRO'} →</button>`;
  }else{
    const disabled=auto.acted.includes(me.id)||m.hp<=0||!auto.combatants.includes(me.id);
    const cantSkill=!m.specialReady;
    $('#auto-actions').innerHTML=`<button class="button-primary" type="button" data-auto="attack" ${disabled?'disabled':''}>⚔ Atacar</button><button class="button-outline special" type="button" data-auto="skill" ${disabled||cantSkill?'disabled':''}>✦ ${enc(CLASSES[m.classId]?.label==='Clérigo'?'Curar':'Habilidade')}</button><button class="button-outline" type="button" data-auto="guard" ${disabled?'disabled':''}>♜ Defender</button><button class="button-outline tactical-focus" type="button" data-auto="focus" ${disabled?'disabled':''}>✦ Concentrar</button><button class="button-outline" type="button" data-auto="potion" ${disabled||m.potions<1?'disabled':''}>✚ Poção (${m.potions})</button><button class="button-primary coop-ultimate-button ${m.ultimateEnergy>=100?'is-ready':''}" type="button" data-auto="ultimate" ${disabled||m.ultimateEnergy<100?'disabled':''}>✦ SUPREMA ${Math.round(m.ultimateEnergy||0)}%</button>`;
  }
  $('#coop-chain-controls').innerHTML=me.role==='gm'?`<span class="overline">LÍDER • EXPEDIÇÕES</span><button class="button-outline" data-chain="5" ${auto.chainRemaining>0?'disabled':''}>Auto ×5</button><button class="button-outline" data-chain="10" ${auto.chainRemaining>0?'disabled':''}>Auto ×10</button>${auto.chainRemaining>0?'<button class="button-outline chain-stop" data-chain="stop">Parar sequência</button>':''}`:'<span class="coop-chain-note">O líder da sala pode iniciar sequências Auto ×5 e ×10.</span>';
  renderProgression();
  renderExpeditions();
  renderModelWorkshop();
  syncCombatStage();
}
// Animações são apenas apresentação: valores de dano e cura vêm da API.
const fxDelay=ms=>new Promise(resolve=>setTimeout(resolve,ms));
async function playNextFx(){
  if(fxBusy||!fxQueue.length||!roomId||state?.room.mode!=='auto')return;
  fxBusy=true;
  while(fxQueue.length&&roomId&&state?.room.mode==='auto'){
    const e=fxQueue.shift();
    const arena=$('#encounter-arena'),layer=$('#battle-fx-layer'),caption=$('#battle-fx-caption');
    const flash=$('#battle-screen-flash');
    const cutin=$('#coop-ultimate-cutin');
    if(!arena||!layer)break;
    const motion=$('#coop-motion')?.value||'cinematic';
    const reduced=motion==='off'||matchMedia('(prefers-reduced-motion: reduce)').matches;
    const duration=reduced?170:motion==='fast'?470:(e.kind==='loot_drop'?650:e.kind==='ultimate'?1750:980);
    const fxLabel=e.kind==='loot_drop'?`✦ TESOURO • ${e.itemName||'EQUIPAMENTO'}`:e.kind==='victory'?'✦ VITÓRIA!':e.kind==='phase'?`CHEFE • FASE ${e.phase}`:e.kind==='intro'?(e.boss?'☠ UM CHEFE SE APROXIMA':'⚔ NOVO ENCONTRO'):e.kind==='defeat'?'EXPEDIÇÃO DERROTADA':e.kind==='status_tick'?(e.damage?`EFEITO • −${e.damage} HP`:`RECUPERAÇÃO • +${e.healed||0} HP`):e.kind==='status'?'EFEITO APLICADO':e.kind==='enemy_attack'?`${e.name||'Inimigo'} contra-ataca!`:e.kind==='ultimate'?`✦ ${e.skill||'SUPREMA'}!`: e.kind==='skill'?(e.skill||'Habilidade especial'):e.kind==='attack'?`${e.name||'Herói'} ataca!`:e.kind==='guard'?'DEFESA ATIVADA':e.kind==='heal'?`+${e.healed||0} HP`:'';
    caption.textContent=fxLabel;
    caption.classList.add('visible');
    combatPresenter?.present(e);
    arena.classList.remove('hero-attack','hero-skill','hero-heal','enemy-attack','enemy-hit','hero-hit','enemy-phase','impact-active','ultimate-active','boss-intro');
    flash.className='battle-screen-flash';
    if(e.kind==='ultimate'){
      cutin.className='coop-ultimate-cutin active class-'+(e.classId||'guardian');
      $('#coop-ultimate-name').textContent=e.skill||'Poder Supremo';
      $('#coop-ultimate-caster').textContent=e.name||'Herói';
      arena.classList.add('ultimate-active');
    }else cutin.className='coop-ultimate-cutin';
    if(e.kind==='intro'&&e.boss)arena.classList.add('boss-intro');
    const effect=document.createElement('div');effect.className='combat-vfx '+(e.kind||'attack')+' '+(e.classId||'');
    const emoji=e.kind==='loot_drop'?'✦':e.kind==='ultimate'?({guardian:'⬡',arcanist:'✺',healer:'✧',ranger:'➹'}[e.classId]||'✦'):e.kind==='heal'?'✚':e.kind==='guard'?'⬡':e.classId==='arcanist'?'✦':e.classId==='ranger'?'➶':e.classId==='guardian'?'🛡':e.classId==='healer'?'✚':e.kind==='phase'?'⚡':'⚔';
    effect.textContent=emoji;
    effect.style.setProperty('--fx-speed',duration+'ms');
    layer.append(effect);
    const side=e.target==='hero'?'hero':'enemy';
    createSparkBurst(layer,combatPresenter?.prefs.mode==='performance'?0:e.kind==='ultimate'?20:e.kind==='skill'?11:6,side,duration);
    if(['attack','skill','ultimate'].includes(e.kind))arena.classList.add(e.kind==='attack'?'hero-attack':'hero-skill','enemy-hit','impact-active');
    if(e.kind==='heal'||e.kind==='guard')arena.classList.add('hero-heal');
    if(e.kind==='enemy_attack')arena.classList.add('enemy-attack','hero-hit','impact-active');
    if(e.kind==='phase')arena.classList.add('enemy-phase','impact-active');
    if(['attack','skill','ultimate','phase'].includes(e.kind)){flash.classList.add('active',['skill','ultimate'].includes(e.kind)?'skill':'');}
    if(e.kind==='heal'||e.kind==='guard')flash.classList.add('active','heal');
    if(e.kind==='enemy_attack')flash.classList.add('active','enemy');
    if(e.damage||e.healed){
      const amount=document.createElement('div');amount.className='combat-float '+(e.healed?'healing':'damage')+(e.crit?' critical':'');
      amount.style.setProperty('--fx-speed',duration+'ms');
      amount.textContent=(e.healed?'+'+(e.healed||0):'−'+(e.damage||0))+(e.crit?' CRÍTICO':'');
      layer.append(amount);
      setTimeout(()=>amount.remove(),duration+150);
    }
    if(combatStage?.active)combatStage.play(e,duration);
    await fxDelay(duration);
    effect.remove();caption.classList.remove('visible');cutin.className='coop-ultimate-cutin';combatPresenter?.clear();
    arena.classList.remove('hero-attack','hero-skill','hero-heal','enemy-attack','enemy-hit','hero-hit','enemy-phase','impact-active','ultimate-active','boss-intro');
    flash.className='battle-screen-flash';
  }
  fxBusy=false;
}

function renderFeed(){
  if(feedTab!=='log')return;
  const feed=$('#activity-feed');
  const atBottom=feed.scrollHeight-feed.scrollTop-feed.clientHeight<75;
  const entries=[...state.logs].reverse();
  feed.innerHTML=entries.length?entries.map(l=>`<article class="feed-entry ${enc(l.kind)}"><time>${new Date(l.at).toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'})}</time><p>${enc(l.text)}</p></article>`).join(''):'<p class="feed-empty">O diário desta aventura ainda está em branco.</p>';
  if(atBottom)feed.scrollTop=0;
}
function renderJournal(){
  $('#journal-readable').textContent=state.room.journal||'O mestre ainda não escreveu a crônica desta aventura.';
  const gm=state.me.role==='gm';
  $('#journal-editor').hidden=!gm;
  if(gm && document.activeElement!==$('#journal-text'))$('#journal-text').value=state.room.journal||'';
  if(gm && document.activeElement!==$('#gm-notes-text'))$('#gm-notes-text').value=state.room.gmNotes||'';
}
function sheetTarget(){return state?.members.find(m=>m.id===sheetTargetId)||state?.members.find(m=>m.id===state.me.id);}
function renderSheet(){
  const m=sheetTarget();if(!m)return;
  const canEdit=m.id===state.me.id||state.me.role==='gm';
  const selector=$('#sheet-member');
  selector.innerHTML=state.members.map(p=>`<option value="${enc(p.id)}" ${p.id===m.id?'selected':''}>${enc(p.name)} · ${enc(CLASSES[p.classId]?.label||'Aventureiro')}</option>`).join('');
  $('#sheet-permission').textContent=canEdit?'Você pode editar esta ficha':'Somente leitura';
  const f=$('#sheet-form'),sheet=m.sheet||{};
  for(const key of ['ancestry','background','alignment'])f.elements.namedItem(key).value=sheet[key]||'';
  const abilities=sheet.abilities||{};
  $('#sheet-abilities').innerHTML=Object.entries(ABILITIES).map(([key,label])=>{
    const v=Number(abilities[key]||10),modifier=Math.floor((v-10)/2),prof=(sheet.proficiencies||[]).includes(key);
    return `<div class="sheet-ability"><label for="ability-${key}">${label.toUpperCase()}</label><div class="sheet-ability-row"><input type="number" id="ability-${key}" name="ability-${key}" min="3" max="20" value="${v}" ${canEdit?'':'disabled'} required/><span class="modifier" id="mod-${key}">${modifier>=0?'+':''}${modifier}</span></div><label class="proficient"><input type="checkbox" name="prof-${key}" ${prof?'checked':''} ${canEdit?'':'disabled'}/> Proficiência</label></div>`;
  }).join('');
  $('#sheet-inventory').value=(sheet.inventory||[]).join('\n');
  $('#sheet-biography').value=sheet.biography||'';
  $('#sheet-details').textContent=`Nível ${m.level} • HP ${m.hp}/${m.maxHp} • ${m.xp} XP • ${m.gold} ouro`;
  for(const el of f.querySelectorAll('input,textarea'))el.disabled=!canEdit;
  $('#sheet-save').hidden=!canEdit;
  $('#ability-check-btn').disabled=m.id!==state.me.id;
  $('#saving-throw-btn').disabled=m.id!==state.me.id;
}
function openSheet(targetId){sheetTargetId=targetId||state.me.id;renderSheet();$('#sheet-dialog').showModal();}
function setupSheets(){
  $('#open-sheet').addEventListener('click',()=>openSheet());
  $('#my-character').addEventListener('click',e=>{if(e.target.closest('[data-view-sheet]'))openSheet();});
  $('#sheet-close').addEventListener('click',()=>$('#sheet-dialog').close());
  $('#sheet-member').addEventListener('change',e=>{sheetTargetId=e.target.value;renderSheet();});
  $('#sheet-abilities').addEventListener('input',e=>{
    const input=e.target.closest('input[type=number]');if(!input)return;
    const key=input.id.replace('ability-',''),score=Number(input.value);
    const label=$('#mod-'+key);if(label&&Number.isFinite(score)){const mod=Math.floor((score-10)/2);label.textContent=(mod>=0?'+':'')+mod;}
  });
  $('#sheet-form').addEventListener('submit',async e=>{
    e.preventDefault();const target=sheetTarget();if(!target)return;
    const f=$('#sheet-form');const abilities={},proficiencies=[];
    for(const key of Object.keys(ABILITIES)){
      abilities[key]=Number(f.elements.namedItem('ability-'+key).value);
      if(f.elements.namedItem('prof-'+key).checked)proficiencies.push(key);
    }
    const sheet={abilities,proficiencies,ancestry:f.elements.namedItem('ancestry').value,background:f.elements.namedItem('background').value,alignment:f.elements.namedItem('alignment').value,biography:$('#sheet-biography').value,inventory:$('#sheet-inventory').value.split(/\r?\n/).map(s=>s.trim()).filter(Boolean)};
    if(await action({type:'sheet_update',targetId:target.id,sheet})){toast('Ficha atualizada e sincronizada!','success');$('#sheet-dialog').close();}
  });
  for(const [selector,savingThrow] of [['#ability-check-btn',false],['#saving-throw-btn',true]]){
    $(selector).addEventListener('click',async()=>{
      if(sheetTarget()?.id!==state.me.id)return toast('Você só pode rolar testes da própria ficha.');
      if(await action({type:'ability_check',ability:$('#check-ability').value,savingThrow})){
        toast('Dado lançado! O grupo verá o resultado no diário.','success');$('#sheet-dialog').close();
      }
    });
  }
  $('#journal-save').addEventListener('click',async()=>{if(await action({type:'journal_update',text:$('#journal-text').value}))toast('Crônica salva!','success');});
  $('#gm-notes-save').addEventListener('click',async()=>{if(await action({type:'gm_notes_update',text:$('#gm-notes-text').value}))toast('Anotações privadas salvas!','success');});
}

function updateAccountButtons(){
  const logged=Boolean(account);
  $('#account-heading').textContent=logged?account.name:'Conta Astronyx';
  $('#account-subtitle').textContent=logged?'Discord conectado · Suas campanhas e fichas estão no servidor':
    authConfig?.enabled?'Entre com Discord para retomar sua aventura em qualquer dispositivo.':'Login Discord opcional ainda não configurado no backend.';
  $('#account-avatar').textContent=logged?(account.name||'?').slice(0,1).toUpperCase():'✦';
  $('#discord-login').hidden=logged||authConfig?.enabled===false;
  $('#discord-logout').hidden=!logged;
  $('#save-my-character').hidden=!logged||!roomId;
  $('#link-current-room').hidden=!logged||!roomId;
  $('#entry-submit').disabled=Boolean(authConfig?.enabled&&!logged);
  const savedChar=$('#library-character');savedChar.parentElement.hidden=!logged;
}
function renderAccountRooms(){
  const host=$('#account-rooms');host.hidden=!account;
  if(!account)return;
  const rooms=accountRooms;
  host.innerHTML=`<div class="account-section-title">✦ SUAS CAMPANHAS <small>${rooms.length} salas</small></div>`+
    (rooms.length?rooms.map(r=>`<div class="account-room"><div><strong>${enc(r.title)}</strong><small>${enc(r.name)} · Nível ${r.level} · ${r.mode==='auto'?'Aventura automática':'Mesa D&D'} ${r.role==='gm'?'· Mestre':''}</small></div><button class="button-outline" type="button" data-resume-room="${enc(r.roomId)}">Retomar →</button></div>`).join(''):'<p class="account-empty">Suas campanhas vinculadas aparecerão aqui.</p>');
}
function renderCharacterLibrary(characters){
  const select=$('#library-character'),value=select.value;
  select.innerHTML='<option value="">Criar personagem novo</option>'+characters.map(c=>`<option value="${enc(c.id)}">${enc(c.name)} · ${enc(CLASSES[c.classId]?.label||'Aventureiro')}</option>`).join('');
  if(characters.some(c=>c.id===value))select.value=value;
}
async function refreshAccount(){
  if(!accountToken)return;
  const [profile,rooms,characters]=await Promise.all([
    api('GET','/api/account/me'),api('GET','/api/account/rooms'),api('GET','/api/account/characters')
  ]);
  account=profile.account;accountRooms=rooms.rooms;
  updateAccountButtons();renderAccountRooms();renderCharacterLibrary(characters.characters);
}
async function logoutAccount(){
  if(accountToken)try{await api('POST','/api/auth/logout',{});}catch{}
  accountToken='';account=null;accountRooms=[];
  localStorage.removeItem('astronyx_account_session');
  // Never silently connect a subsequent person on a shared browser to old room tokens.
  localStorage.removeItem('astronyx_sessions');
  leave();updateAccountButtons();renderAccountRooms();renderCharacterLibrary([]);
  toast('Você saiu da conta Discord.','success');
}
async function setupAccount(){
  $('#discord-login').addEventListener('click',()=>{
    sessionStorage.setItem('astronyx_pending_invite',new URLSearchParams(location.search).get('s')||'');
    location.assign(API_BASE+'/api/auth/discord');
  });
  $('#discord-logout').addEventListener('click',logoutAccount);
  $('#account-rooms').addEventListener('click',async event=>{
    const button=event.target.closest('[data-resume-room]');if(!button)return;
    try{
      const result=await api('GET','/api/account/room-session?room='+encodeURIComponent(button.dataset.resumeRoom));
      await enterRoom(result.roomId,result.session,result.state);
      toast('Campanha restaurada pelo Discord!','success');
    }catch(e){toast(e.message);}
  });
  $('#save-my-character').addEventListener('click',async()=>{
    if(!account||!roomId)return;
    try{
      await api('POST','/api/account/characters',{roomId,roomSession:session});
      await refreshAccount();toast('Ficha salva na biblioteca!','success');
    }catch(e){toast(e.message);}
  });
  $('#link-current-room').addEventListener('click',async()=>{
    if(!account||!roomId)return;
    if(!confirm('Vincular este personagem à sua conta Discord? Isso permite recuperar esta campanha em outros dispositivos.'))return;
    try{
      await api('POST','/api/account/link-room',{roomId,roomSession:session});
      await refreshAccount();toast('Campanha vinculada à sua conta!','success');
    }catch(e){toast(e.message);}
  });
  try{authConfig=await api('GET','/api/auth/config');}
  catch{authConfig={enabled:false};toast('Não foi possível verificar o login Discord. Confira o backend.');}
  const url=new URL(location.href),ticket=url.searchParams.get('auth_ticket')||new URLSearchParams(url.hash.slice(1)).get('auth_ticket');
  if(ticket){
    url.searchParams.delete('auth_ticket');
    if(url.hash.startsWith('#auth_ticket='))url.hash='';
    const invite=sessionStorage.getItem('astronyx_pending_invite');
    if(invite){url.searchParams.set('s',invite);$('#room-code').value=invite.toUpperCase();$('.tab[data-tab="join"]').click();}
    sessionStorage.removeItem('astronyx_pending_invite');
    history.replaceState(null,'',url.pathname+url.search+url.hash);
    try{
      const result=await api('POST','/api/auth/exchange',{ticket});
      accountToken=result.token;localStorage.setItem('astronyx_account_session',accountToken);
      account=result.account;toast('Discord conectado com sucesso!','success');
      // Clear obsolete room auth when switching to a new account; current party progress remains on server.
      if(roomId)leave();
    }catch(e){toast('Falha no login: '+e.message);}
  }
  if(accountToken){
    try{await refreshAccount();}
    catch{accountToken='';account=null;localStorage.removeItem('astronyx_account_session');toast('Sua sessão Discord expirou. Entre novamente.');}
  }
  updateAccountButtons();renderAccountRooms();
}

function setupGameControls(){
  $('#scene-select').addEventListener('change',e=>action({type:'scene',scene:e.target.value}));
  $('#add-monster').addEventListener('click',()=>{const name=prompt('Nome da criatura:','Lobo Selvagem');if(name)action({type:'spawn',name});});
  $('#roll-initiative').addEventListener('click',()=>action({type:'initiative'}));
  $('#next-turn').addEventListener('click',()=>action({type:'next_turn'}));
  const grid=$('#map-grid');
  for(let y=0;y<9;y++)for(let x=0;x<14;x++){
    const cell=document.createElement('button');cell.className='grid-cell';cell.type='button';cell.dataset.x=x;cell.dataset.y=y;cell.setAttribute('aria-label',`Mover para coluna ${x+1}, linha ${y+1}`);grid.append(cell);
  }
  grid.addEventListener('click',e=>{
    const cell=e.target.closest('.grid-cell');if(!cell||!selected)return;
    action({type:'move',tokenId:selected,x:Number(cell.dataset.x),y:Number(cell.dataset.y)});
  });
  $('#map-tokens').addEventListener('click',e=>{
    const btn=e.target.closest('[data-token-id]');if(!btn)return;
    const token=state.tokens.find(t=>t.id===btn.dataset.tokenId);
    if(token && (state.me.role==='gm'||token.ownerId===state.me.id)){selected=token.id;renderTabletop();}
    else toast('Você só pode movimentar seu personagem.');
  });
  $('#token-actions').addEventListener('click',e=>{
    const btn=e.target.closest('[data-token-action]');if(!btn||!selected)return;
    if(btn.dataset.tokenAction==='remove')action({type:'remove',tokenId:selected}).then(()=>{selected=null;renderTabletop();});
    else action({type:'modify_hp',tokenId:selected,amount:btn.dataset.tokenAction==='heal'?5:-5});
  });
  $('#open-arsenal').addEventListener('click',()=>{const target=$('#progression-panel');if(target){target.open=true;target.scrollIntoView({behavior:'smooth',block:'start'});}});
  setupProgression();
  setupExpeditions();
  $('#auto-actions').addEventListener('click',e=>{const btn=e.target.closest('[data-auto]');if(btn&&!btn.disabled)action({type:btn.dataset.auto});});
  $('#coop-auto-enabled').addEventListener('change',e=>action({type:'auto_toggle',enabled:e.target.checked}));
  $('#coop-strategy').addEventListener('change',e=>action({type:'auto_strategy',strategy:e.target.value}));
  $('#coop-chain-controls').addEventListener('click',e=>{const btn=e.target.closest('[data-chain]');if(!btn||btn.disabled)return;action(btn.dataset.chain==='stop'?{type:'auto_stop'}:{type:'auto_chain',count:Number(btn.dataset.chain)});});
  $('#coop-motion').value=localStorage.getItem('astronyx_coop_motion')||'cinematic';
  $('#coop-motion').addEventListener('change',e=>localStorage.setItem('astronyx_coop_motion',e.target.value));
  // V1.3: sons WebAudio ficam desligados até o jogador optar por ativá-los.
  combatPresenter=new window.AstronyxPresentation.CombatPresentation({arena:$('#encounter-arena'),overlay:$('#coop-cinematic-banner')});
  const quality=$('#coop-presentation'),theme=$('#coop-theme'),sound=$('#coop-sound'),volume=$('#coop-volume'),volumeLabel=$('#coop-volume-label');
  const prefs=window.AstronyxPresentation.preferences({
    enabled:localStorage.getItem('astronyx_audio_enabled')==='yes',
    volume:localStorage.getItem('astronyx_audio_volume')??55,
    mode:localStorage.getItem('astronyx_visual_mode')||'cinematic',
    theme:localStorage.getItem('astronyx_visual_theme')||'adaptive'
  });
  quality.value=prefs.mode;theme.value=prefs.theme;sound.checked=prefs.enabled;volume.value=prefs.volume;volumeLabel.textContent=prefs.volume+'%';
  combatPresenter.setPrefs(prefs);
  const syncPresentation=()=>{
    const newPrefs=combatPresenter.setPrefs({mode:quality.value,theme:theme.value,enabled:sound.checked,volume:Number(volume.value)});
    localStorage.setItem('astronyx_audio_enabled',newPrefs.enabled?'yes':'no');
    localStorage.setItem('astronyx_audio_volume',String(newPrefs.volume));
    localStorage.setItem('astronyx_visual_mode',newPrefs.mode);
    localStorage.setItem('astronyx_visual_theme',newPrefs.theme);
    volumeLabel.textContent=newPrefs.volume+'%';
    return newPrefs;
  };
  quality.addEventListener('change',syncPresentation);theme.addEventListener('change',syncPresentation);
  volume.addEventListener('input',syncPresentation);
  sound.addEventListener('change',async()=>{
    syncPresentation();
    if(sound.checked){const ok=await combatPresenter.unlock();if(!ok){sound.checked=false;syncPresentation();toast('O navegador não conseguiu ativar o áudio.');}}
  });
  // O navegador pode restaurar a preferência; desbloqueamos somente em interação explícita.
  const unlockAudio=()=>{if(sound.checked)combatPresenter.unlock();};
  $('#auto-actions').addEventListener('click',unlockAudio);
  $('#coop-controls').addEventListener('click',unlockAudio);

  combat3dPreference=localStorage.getItem('astronyx_coop_view')||'3d';
  if(!['2d','3d'].includes(combat3dPreference))combat3dPreference='3d';
  $('#coop-view').value=combat3dPreference;
  $('#coop-view').addEventListener('change',e=>{
    combat3dPreference=e.target.value==='2d'?'2d':'3d';
    localStorage.setItem('astronyx_coop_view',combat3dPreference);
    syncCombatStage();
  });
  $('#coop-camera').addEventListener('change',e=>combatStage?.setCamera(e.target.value));
  $('#coop-camera-focus').addEventListener('click',()=>combatStage?.focus());
  for(const [selector,key,field] of [['#coop-smooth','astronyx_smooth_3d','smoothTransitions'],['#coop-weapon-fx','astronyx_weapon_fx','weaponFxEnabled']]){
    const input=$(selector);input.checked=localStorage.getItem(key)!=='off';
    input.addEventListener('change',()=>{localStorage.setItem(key,input.checked?'on':'off');if(combatStage)combatStage[field]=input.checked;});
  }

  $('#chat-form').addEventListener('submit',async e=>{
    e.preventDefault();const input=$('#chat-input'),message=input.value.trim();if(!message)return;
    if(await action({type:'chat',message}))input.value='';
  });
  $('#tab-log').addEventListener('click',()=>{
    feedTab='log';$('#tab-log').classList.add('active');$('#tab-dice').classList.remove('active');$('#activity-feed').hidden=false;$('#dice-panel').hidden=true;renderFeed();
  });
  $('#tab-dice').addEventListener('click',()=>{
    feedTab='dice';$('#tab-dice').classList.add('active');$('#tab-log').classList.remove('active');$('#activity-feed').hidden=true;$('#dice-panel').hidden=false;
  });
  $('#dice-grid').addEventListener('click',e=>{const btn=e.target.closest('[data-sides]');if(btn){action({type:'roll',sides:Number(btn.dataset.sides),modifier:Number($('#dice-mod').value)||0});toast(`d${btn.dataset.sides} rolado! Confira o histórico.`, 'success');}});
}
setupEntry();setupGameControls();setupSheets();setupModelWorkshop();
window.AstronyxBuilder?.setup({getState:()=>state,action,toast});
setupAccount().then(async()=>{
  const requestedRoom=new URLSearchParams(location.search).get('s')?.trim().toUpperCase();
  const storedToken=requestedRoom&&saved()[requestedRoom];
  if(storedToken){
    try{await enterRoom(requestedRoom,storedToken);}catch(err){
      const sessions=saved();delete sessions[requestedRoom];localStorage.setItem('astronyx_sessions',JSON.stringify(sessions));
      leave();toast('Não foi possível restaurar sua sessão: '+err.message);
    }
  }
}).catch(e=>toast(e.message));
})();
