/* Astronyx Realms V0.5 • Motor WebGL 3D local, sem dependências de CDN.
   Câmera orbital, renderização de blocos volumétricos, múltiplos andares,
   iluminação direcional, seleção por raycasting e personagens em 3D.
   Sem recursos proprietários de outros jogos. */
(function (root) {
'use strict';
const RAD=Math.PI/180;
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const matColor={
 grass:'#508765',stone:'#9299ac',wood:'#a17950',sand:'#c8b37d',water:'#3a97b2',lava:'#e77744',snow:'#d5e2ea',dirt:'#8a6d56',marble:'#c1bbd4',cobble:'#81899e'
};
const wallColor={stone:'#9ba3b7',wood:'#916a4e',brick:'#b87a67',iron:'#8896ae',door:'#98704b',window:'#a5b7cc',fence:'#94735b'};
function hexColor(hex){const c=String(hex||'#cccccc').replace('#','');return [parseInt(c.slice(0,2),16)/255,parseInt(c.slice(2,4),16)/255,parseInt(c.slice(4,6),16)/255];}
function shade(c,k){return c.map(v=>clamp(v*k,0,1));}
function dot(a,b){return a[0]*b[0]+a[1]*b[1]+a[2]*b[2];}
function cross(a,b){return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];}
function sub(a,b){return [a[0]-b[0],a[1]-b[1],a[2]-b[2]];}
function norm(a){const l=Math.hypot(...a)||1;return a.map(v=>v/l);}
function perspective(fov,aspect,near,far){const f=1/Math.tan(fov/2),nf=1/(near-far);return [f/aspect,0,0,0,0,f,0,0,0,0,(far+near)*nf,-1,0,0,2*far*near*nf,0];}
function orthographic(l,r,b,t,n,f){return [2/(r-l),0,0,0,0,2/(t-b),0,0,0,0,-2/(f-n),0,-(r+l)/(r-l),-(t+b)/(t-b),-(f+n)/(f-n),1];}
function lookAt(eye,target,up=[0,1,0]){const z=norm(sub(eye,target)),x=norm(cross(up,z)),y=cross(z,x);return [x[0],y[0],z[0],0,x[1],y[1],z[1],0,x[2],y[2],z[2],0,-dot(x,eye),-dot(y,eye),-dot(z,eye),1];}
function multiply(a,b){const out=new Array(16);for(let col=0;col<4;col++)for(let row=0;row<4;row++)out[col*4+row]=a[row]*b[col*4]+a[4+row]*b[col*4+1]+a[8+row]*b[col*4+2]+a[12+row]*b[col*4+3];return out;}
function makeMesh(){const p=[],n=[],c=[];function tri(a,b,d,color,normal){for(const v of [a,b,d]){p.push(...v);n.push(...normal);c.push(...color);}}
function quad(a,b,d,e,color,normal){tri(a,b,d,color,normal);tri(a,d,e,color,normal);}
function box(x,y,z,w,h,l,color){if(w<=0||h<=0||l<=0)return;const X=x-w/2,A=x+w/2,Y=y-h/2,B=y+h/2,Z=z-l/2,C=z+l/2;
 quad([X,B,Z],[A,B,Z],[A,B,C],[X,B,C],shade(color,1.14),[0,1,0]);
 quad([X,Y,C],[A,Y,C],[A,Y,Z],[X,Y,Z],shade(color,.5),[0,-1,0]);
 quad([A,Y,C],[X,Y,C],[X,B,C],[A,B,C],shade(color,.82),[0,0,1]);
 quad([X,Y,Z],[A,Y,Z],[A,B,Z],[X,B,Z],shade(color,.7),[0,0,-1]);
 quad([A,Y,Z],[A,Y,C],[A,B,C],[A,B,Z],shade(color,.95),[1,0,0]);
 quad([X,Y,C],[X,Y,Z],[X,B,Z],[X,B,C],shade(color,.74),[-1,0,0]);}
function cylinder(x,y,z,r,h,color,sides=9,r2=r){for(let i=0;i<sides;i++){const a=i*Math.PI*2/sides,b=(i+1)*Math.PI*2/sides;const va=[x+Math.cos(a)*r,y-h/2,z+Math.sin(a)*r],vb=[x+Math.cos(b)*r,y-h/2,z+Math.sin(b)*r],vc=[x+Math.cos(b)*r2,y+h/2,z+Math.sin(b)*r2],vd=[x+Math.cos(a)*r2,y+h/2,z+Math.sin(a)*r2];const nn=norm([Math.cos((a+b)/2),.18,Math.sin((a+b)/2)]);quad(va,vb,vc,vd,color,nn);tri([x,y+h/2,z],vd,vc,shade(color,1.1),[0,1,0]);}}
function sphere(x,y,z,r,color){const bands=5,sides=10;for(let j=0;j<bands;j++){const t0=j*Math.PI/bands,t1=(j+1)*Math.PI/bands;for(let i=0;i<sides;i++){const a=i*2*Math.PI/sides,b=(i+1)*2*Math.PI/sides;const point=(t,phi)=>[x+r*Math.sin(t)*Math.cos(phi),y+r*Math.cos(t),z+r*Math.sin(t)*Math.sin(phi)];const A=point(t0,a),B=point(t1,a),C=point(t1,b),D=point(t0,b);quad(A,B,C,D,color,norm(sub(A,[x,y,z])));}}}
return {p,n,c,tri,quad,box,cylinder,sphere};}
function prop3d(m,id,x,y,z){const bark=hexColor('#7e5740'),wood=hexColor('#a77849'),stone=hexColor('#adb3c4'),gold=hexColor('#e1b96c'),green=hexColor('#43896b'),metal=hexColor('#9aa9b9');const B=(a,b,c,d,e,f,g)=>m.box(x+a,y+b,z+c,d,e,f,g),Cy=(a,b,c,r,h,color,sides=9,r2=r)=>m.cylinder(x+a,y+b,z+c,r,h,color,sides,r2),S=(a,b,c,r,color)=>m.sphere(x+a,y+b,z+c,r,color);
 if(id==='tree'||id==='bush'){if(id==='tree')Cy(0,.52,0,.12,1.05,bark);for(const [dx,dz,r] of [[0,0,.45],[-.25,.06,.3],[.23,-.11,.34]])S(dx,id==='tree'?1.3:.3,dz,r,shade(green,dx===0?1:1.13));}
 else if(id==='rock'){S(0,.25,0,.37,stone);S(.26,.12,.12,.2,shade(stone,.75));}
 else if(id==='torch'||id==='brazier'||id==='campfire'){if(id==='torch')Cy(0,.52,0,.06,1,bark);if(id==='brazier')Cy(0,.4,0,.26,.75,metal,8);if(id==='campfire')for(let i=-1;i<=1;i++)B(i*.13,.08,0,.4,.13,.12,bark);S(0,id==='torch'?1.12:id==='brazier'?.88:.27,0,.2,hexColor('#ffb45e'));S(0,id==='torch'?1.16:id==='brazier'?.9:.32,0,.08,hexColor('#ffeabc'));}
 else if(id==='pillar'||id==='statue'||id==='spire'){Cy(0,.57,0,.27,1.13,stone,9);Cy(0,1.15,0,.36,.12,shade(stone,1.2),9);if(id==='statue')S(0,1.45,0,.22,gold);if(id==='spire')Cy(0,1.53,0,.37,.72,shade(stone,1.05),9,0);}
 else if(id==='barrel'){Cy(0,.35,0,.27,.7,wood,10);Cy(0,.16,0,.28,.07,metal,10);Cy(0,.55,0,.28,.07,metal,10);}
 else if(id==='chest'){B(0,.22,0,.66,.4,.45,bark);B(0,.46,0,.7,.17,.48,gold);B(0,.25,.235,.1,.25,.03,gold);}
 else if(id==='crate'){B(0,.35,0,.66,.7,.66,wood);B(0,.69,0,.69,.065,.69,shade(wood,1.2));}
 else if(id==='altar'||id==='table'){B(0,.58,0,.83,.1,.6,id==='altar'?stone:wood);for(const [xx,zz] of [[-.32,-.22],[-.32,.22],[.32,-.22],[.32,.22]])B(xx,.3,zz,.1,.55,.1,wood);if(id==='altar')S(0,.83,0,.18,hexColor('#bb8efa'));}
 else if(id==='chair'){B(0,.32,0,.48,.13,.5,wood);B(0,.63,-.21,.48,.7,.12,wood);}
 else if(id==='bed'){B(0,.2,0,.78,.35,.94,wood);B(0,.39,0,.7,.09,.82,hexColor('#b07994'));B(0,.47,-.3,.5,.13,.18,hexColor('#e3dad6'));}
 else if(id==='bush'){S(0,.3,0,.38,green);}
 else if(id==='roof'){B(0,.63,0,.91,.1,.91,hexColor('#8f5257'));Cy(0,1.05,0,.65,.8,hexColor('#b15b55'),4,0);}
 else if(id==='arch'){B(-.37,.66,0,.17,1.32,.24,stone);B(.37,.66,0,.17,1.32,.24,stone);B(0,1.29,0,.9,.19,.24,stone);}
 else if(id==='banner'){Cy(0,.8,0,.04,1.6,metal,7);B(.26,1.2,0,.55,.55,.05,hexColor('#8d54c2'));}
 else if(id==='fountain'||id==='well'){Cy(0,.22,0,.43,.45,stone,12);Cy(0,.46,0,.37,.08,hexColor('#5cbad0'),12);if(id==='fountain')Cy(0,.79,0,.1,.67,stone);}
 else if(id==='portal'){Cy(-.28,.64,0,.13,1.26,stone,7);Cy(.28,.64,0,.13,1.26,stone,7);B(0,1.27,0,.72,.15,.27,hexColor('#ae88e1'));B(0,.62,0,.45,1.12,.08,hexColor('#6e5ac1'));}
 else if(id==='bookshelf'){B(0,.66,0,.76,1.32,.27,bark);for(let row=0;row<3;row++){B(0,.29+row*.42,.04,.66,.055,.32,gold);for(let i=-3;i<=3;i++)B(i*.085,.42+row*.42,.17,.065,.23,.07,i%2?hexColor('#526893'):hexColor('#95657e'));}}
 else if(id==='rug'){B(0,.045,0,.84,.08,.65,hexColor('#a45f83'));B(0,.089,0,.53,.014,.39,gold);}
 else if(id==='stairs'||id==='ladder'){for(let i=0;i<5;i++)B(0,.08+i*.13,-.34+i*.17,.84,.15,.18,stone);}
 else if(id==='bridge'){B(0,.14,0,.95,.24,.85,wood);for(let i=-2;i<=2;i++)B(i*.2,.29,0,.05,.08,.83,bark);}
 else{B(0,.28,0,.5,.55,.5,shade(stone,.9));}
}
// Miniaturas de combate (V0.9). São formas 3D estilizadas; o editor 3D normal
// continua usando seus marcadores originais, sem mudar o formato dos mapas.
function combatMiniature(mesh,token,x,base,z){
 const palette={guardian:'#739bce',arcanist:'#a477e5',healer:'#ecd58b',ranger:'#57aa87'};
 const color=hexColor(token.kind==='enemy'?(token.boss?'#cb4b7b':'#78b887'):(palette[token.classId]||'#a791f1'));
 const dark=shade(color,.65),bright=shade(color,1.3),metal=hexColor('#d3d7e7'),gold=hexColor('#e7bc74');
 const size=token.kind==='enemy'?(token.boss?1.5:1.22):1;
 const y=base+Math.max(0,Number(token.lift)||0), spin=Number(token.aura)||0;
 mesh.cylinder(x,y+.05,z,.37*size,.13,shade(color,.38),12);
 mesh.cylinder(x,y+.19,z,.32*size,.06,gold,12);
 if(token.kind==='enemy'){
   // Criaturas com pernas/patas e chifres em vez de simples pinos 3D.
   mesh.sphere(x,y+.73*size,z,.49*size,color);
   mesh.sphere(x-.17*size,y+.84*size,z+.34*size,.085*size,hexColor('#111624'));
   mesh.sphere(x+.17*size,y+.84*size,z+.34*size,.085*size,hexColor('#111624'));
   mesh.cylinder(x-.34*size,y+.32*size,z+.19*size,.14*size,.52*size,dark,7);
   mesh.cylinder(x+.34*size,y+.32*size,z+.19*size,.14*size,.52*size,dark,7);
   for(const d of [-1,1])mesh.cylinder(x+d*.31*size,y+1.29*size,z-.08*size,.13*size,.55*size,bright,7,0);
   if(token.boss){mesh.sphere(x,y+1.52*size,z,.22*size,hexColor('#f7b0cb'));mesh.cylinder(x,y+.21,z,.57*size,.08,gold,14);}
 }else{
   mesh.cylinder(x-.17,y+.32,z,.115,.43,dark,8);
   mesh.cylinder(x+.17,y+.32,z,.115,.43,dark,8);
   mesh.cylinder(x,y+.83,z,.36,.74,color,8,.24);
   mesh.sphere(x,y+1.37,z,.24,hexColor('#dfb79b'));
   mesh.cylinder(x,y+1.55,z,.26,.19,bright,8,.13);
   mesh.cylinder(x-.44,y+.86,z,.105,.64,color,8);
   mesh.cylinder(x+.44,y+.86,z,.105,.64,color,8);
   // Armas por classe: espada + escudo, cajado, símbolo de cura ou arco.
   if(token.classId==='guardian'){
     mesh.box(x+.55,y+.9,z+.1,.12,.79,.12,metal);
     mesh.box(x+.55,y+.95,z+.1,.4,.11,.14,gold);
     mesh.box(x-.53,y+.85,z+.2,.2,.62,.42,dark);
   }else if(token.classId==='arcanist'){
     mesh.cylinder(x+.57,y+1.06,z,.055,1.8,gold,8);
     mesh.sphere(x+.57,y+2.03,z,.20,hexColor('#b19cff'));
   }else if(token.classId==='healer'){
     mesh.cylinder(x+.57,y+1.03,z,.07,1.65,metal,8);
     mesh.sphere(x+.57,y+1.94,z,.19,hexColor('#f4efb5'));
     mesh.box(x-.52,y+.89,z+.17,.16,.47,.31,gold);
   }else if(token.classId==='ranger'){
     mesh.cylinder(x+.52,y+1.04,z,.07,1.27,hexColor('#8c613c'),7);
     mesh.box(x+.52,y+1.03,z+.08,.035,1.2,.04,gold);
     mesh.box(x-.1,y+.74,z-.29,.59,.07,.13,hexColor('#42684c'));
   }
   if(spin>0)mesh.sphere(x,y+1.82,z,.18+spin*.13,bright);
 }
}
// Trilhas volumétricas acopladas ao ponto da arma/cajado em miniaturas padrão e GLB.
// Apenas representação: não interferem em colisão, dano, XP ou rolagens.
function combatBattleFx(mesh,token,x,base,z){
 const intensity=clamp(token.vfxPower||0,0,1);
 if(intensity<=.005)return;
 const palettes={guardian:'#ffd48b',arcanist:'#b99eff',healer:'#8ef9c1',ranger:'#98e5a4',enemy:'#ff8196'};
 const color=hexColor(palettes[token.kind==='enemy'?'enemy':token.classId]||'#e7c6ff');
 const progress=clamp(token.vfxProgress||0,0,1),height=base+(token.lift||0)+1.04;
 const dir=token.kind==='enemy'?-1:1;
 const bx=x+dir*.46,rad=.06+.13*intensity;
 mesh.sphere(bx,height+.15,z,rad,color);
 const count=intensity>.65?5:3;
 for(let i=0;i<count;i++){
  const t=(i+1)/(count+1),angle=(progress+t*1.6)*Math.PI*1.5;
  const trailX=bx+dir*(.15+t*.85)*intensity;
  const trailY=height+.25+Math.sin(angle)*.23*intensity;
  const trailZ=z+Math.cos(angle)*.23*intensity;
  mesh.sphere(trailX,trailY,trailZ,(.05+.09*(1-t))*intensity,color);
 }
 if(token.vfxBurst){
  mesh.sphere(x,height+.38,z,.22+.26*intensity,color);
  for(let i=0;i<6;i++){
   const angle=i*Math.PI/3+progress;
   mesh.sphere(x+Math.cos(angle)*(.35+progress*.5),height+.3+Math.sin(angle)*(.35+progress*.5),z,.042*intensity,color);
  }
 }
}
function generate(board,tokens=[],options={}){
 const mesh=makeMesh(),width=board.width,height=board.height,fog=new Set(board.fog||[]);const hideAbove=clamp(Number(options.hideAbove??4),0,4);
 for(let row=0;row<height;row++)for(let col=0;col<width;col++){
  const key=col+','+row,cell=board.cells[key]||{},terrain=clamp(Number(cell.height)||0,0,6),x=col+.5-width/2,z=row+.5-height/2,base=.13+terrain*.65;
  const hidden=fog.has(key),levels=[[0,{floor:cell.floor||'grass',walls:cell.walls||{},prop:cell.prop,light:cell.light||0}]];
  for(const [lv,rec] of Object.entries(cell.stories||{})){const n=Number(lv);if(n>=1&&n<=hideAbove&&rec&&typeof rec==='object')levels.push([n,rec]);}
  if(hidden){mesh.box(x,base,z,.985,.26,.985,hexColor('#252945'));continue;}
  for(const [lv,tile] of levels){const top=base+lv*2.08,tc=hexColor(matColor[tile.floor]||matColor.grass),th=lv===0?.24+terrain*.65:.22;
   mesh.box(x,top-th/2,z,.985,th,.985,tc);
   if(tile.floor==='water'||tile.floor==='lava')mesh.box(x,top+.018,z,.79,.025,.79,hexColor(tile.floor==='water'?'#79d5e4':'#ffac6b'));
   const wc=tile.walls||{};for(const [side,material] of Object.entries(wc)){if(!['n','s','e','w'].includes(side))continue;const zdir=side==='n'?-1:side==='s'?1:0,xdir=side==='w'?-1:side==='e'?1:0;
    const cx=x+xdir*.45,cz=z+zdir*.45,edgeZ=zdir!==0,ww=edgeZ?.94:.13,dd=edgeZ?.13:.94,color=hexColor(wallColor[material]||wallColor.stone);
    if(material==='fence'){for(let i=-1;i<=1;i++)mesh.box(cx+(edgeZ?i*.39:0),top+.45,cz+(edgeZ?0:i*.39),edgeZ?.09:.09,.9,.09,color);mesh.box(cx,top+.4,cz,ww,.1,dd,color);mesh.box(cx,top+.72,cz,ww,.08,dd,color);}
    else if(material==='door'||material==='window'){
     for(const dir of [-1,1])mesh.box(cx+(edgeZ?dir*.38:0),top+.8,cz+(edgeZ?0:dir*.38),edgeZ?.15:.15,1.6,.15,color);
     mesh.box(cx,top+1.5,cz,ww,.23,dd,color);
     if(material==='door')mesh.box(cx,top+.57,cz,edgeZ?.6:.07,1.14,edgeZ?.07:.6,hexColor('#815a42'));
     else{mesh.box(cx,top+.18,cz,ww,.33,dd,color);mesh.box(cx,top+.9,cz,edgeZ?.65:.065,.85,edgeZ?.065:.65,hexColor('#76b7cc'));}
    }else mesh.box(cx,top+.79,cz,ww,1.58,dd,color);
   }
   if(tile.prop)prop3d(mesh,tile.prop,x,top,z);
   if((tile.light||0)>0&&!['torch','campfire','brazier'].includes(tile.prop))mesh.sphere(x,top+.25,z,.15,hexColor('#ffda8d'));
  }
 }
 // Marcadores 3D — tokens da sala, sem revelar criaturas ocultas.
 for(const token of tokens){if(!Number.isFinite(token.x)||!Number.isFinite(token.y)||token.x<0||token.y<0||token.x>=width||token.y>=height||fog.has(token.x+','+token.y))continue;
  const cell=board.cells[token.x+','+token.y]||{},x=token.x+.5-width/2,z=token.y+.5-height/2,base=.13+clamp(Number(cell.height)||0,0,6)*.65;
  if(token.combat3d){if(!token.customModel)combatMiniature(mesh,token,x,base,z);combatBattleFx(mesh,token,x,base,z);continue;}
  const color=hexColor(token.kind==='hero'?'#a791f1':'#d86b86');mesh.cylinder(x,base+.09,z,.27,.18,shade(color,.7),10);mesh.cylinder(x,base+.41,z,.16,.54,color,9,.12);mesh.sphere(x,base+.83,z,.19,shade(color,1.12));
 }
 if(options.selected){const {x,y}=options.selected;if(x>=0&&y>=0&&x<width&&y<height){const cell=board.cells[x+','+y]||{},top=.13+clamp(cell.height||0,0,6)*.65+clamp(options.story||0,0,4)*2.08;
  // Contorno dourado separado e elevado para não esconder o piso
  const px=x+.5-width/2,pz=y+.5-height/2,co=hexColor('#fbd18a');
  mesh.box(px-.43,top+.038,pz,.055,.045,.91,co);mesh.box(px+.43,top+.038,pz,.055,.045,.91,co);mesh.box(px,top+.038,pz-.43,.91,.045,.055,co);mesh.box(px,top+.038,pz+.43,.91,.045,.055,co);
 }}
 return mesh;
}
function rayAabb(origin,direction,min,max){let a=0,b=Infinity;for(let i=0;i<3;i++){if(Math.abs(direction[i])<1e-8){if(origin[i]<min[i]||origin[i]>max[i])return null;continue;}let t0=(min[i]-origin[i])/direction[i],t1=(max[i]-origin[i])/direction[i];if(t0>t1)[t0,t1]=[t1,t0];a=Math.max(a,t0);b=Math.min(b,t1);if(a>b)return null;}return a;}
function cameraFor(board,cam){const target=cam.target||[0,0,0],pitch=cam.pitch*RAD,yaw=cam.yaw*RAD,d=cam.distance;const eye=[target[0]+Math.sin(yaw)*Math.cos(pitch)*d,target[1]+Math.sin(pitch)*d,target[2]+Math.cos(yaw)*Math.cos(pitch)*d];return {eye,target,forward:norm(sub(target,eye))};}
class Viewer{
 constructor(canvas){this.canvas=canvas;this.gl=canvas.getContext('webgl',{antialias:true,alpha:false,preserveDrawingBuffer:false})||canvas.getContext('experimental-webgl',{antialias:true,alpha:false});if(!this.gl)throw Error('WebGL indisponível neste navegador.');this.board=null;this.tokens=[];this.selected=null;this.story=0;this.hideAbove=4;this.mesh=null;this.cached='';this.yaw=42;this.pitch=54;this.distance=24;this.target=[0,1,0];this.projection='perspective';this._initGL();}
 _shader(type,source){const gl=this.gl,s=gl.createShader(type);gl.shaderSource(s,source);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw Error('Erro no shader: '+gl.getShaderInfoLog(s));return s;}
 _initGL(){const gl=this.gl,v=this._shader(gl.VERTEX_SHADER,`attribute vec3 aPos;attribute vec3 aNormal;attribute vec3 aColor;attribute vec2 aUv;uniform mat4 uMatrix;uniform float uAmbient;varying vec3 vColor;varying vec2 vUv;void main(){float lam=max(dot(normalize(aNormal),normalize(vec3(.38,.82,.42))),0.0);float lit=clamp(uAmbient+lam*.34,.0,1.25);vColor=aColor*lit;vUv=aUv;gl_Position=uMatrix*vec4(aPos,1.);}`),f=this._shader(gl.FRAGMENT_SHADER,`precision mediump float;varying vec3 vColor;varying vec2 vUv;uniform sampler2D uTex;uniform float uTextured;void main(){vec4 base=uTextured>.5?texture2D(uTex,vUv):vec4(1.0);if(base.a<.15)discard;gl_FragColor=vec4(vColor*base.rgb,base.a);}`);const prog=gl.createProgram();gl.attachShader(prog,v);gl.attachShader(prog,f);gl.linkProgram(prog);if(!gl.getProgramParameter(prog,gl.LINK_STATUS))throw Error('Falha no programa WebGL: '+gl.getProgramInfoLog(prog));this.program=prog;this.pos=gl.getAttribLocation(prog,'aPos');this.nor=gl.getAttribLocation(prog,'aNormal');this.color=gl.getAttribLocation(prog,'aColor');this.uv=gl.getAttribLocation(prog,'aUv');this.mat=gl.getUniformLocation(prog,'uMatrix');this.ambient=gl.getUniformLocation(prog,'uAmbient');this.textured=gl.getUniformLocation(prog,'uTextured');this.texUniform=gl.getUniformLocation(prog,'uTex');this.buff=[gl.createBuffer(),gl.createBuffer(),gl.createBuffer(),gl.createBuffer()];this.models=new Map();gl.enable(gl.DEPTH_TEST);gl.depthFunc(gl.LEQUAL);gl.disable(gl.CULL_FACE);}
 // Modelos externos não alteram o mapa. Cada mesh possui seus próprios buffers GPU.
 loadModel(id,parsed,images=[]){if(this.models.has(id))return;const gl=this.gl,b=parsed.bounds,min=b.min,max=b.max,centerX=(min[0]+max[0])/2,centerZ=(min[2]+max[2])/2,scale=1.85/Math.max(.01,max[1]-min[1]);
  const textures=images.map(image=>{if(!image)return null;const t=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,t);gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,false);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,image);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);image.close?.();return t;});
  const animator=root.AstronyxRig?.build?.(parsed)||null;
  const primitives=parsed.primitives.map(pr=>{const arrays=[[...pr.p],[...pr.n],[...pr.c],[...pr.uv]];for(let k=0;k<arrays[0].length;k+=3){arrays[0][k]=(arrays[0][k]-centerX)*scale;arrays[0][k+1]=(arrays[0][k+1]-min[1])*scale;arrays[0][k+2]=(arrays[0][k+2]-centerZ)*scale;}
   const buffers=arrays.map(arr=>{const buffer=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,buffer);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(arr),gl.STATIC_DRAW);return buffer;});
   return {buffers,count:pr.p.length/3,rig:pr.rig?pr:null,texture:textures[parsed.json.textures?.[pr.textureIndex]?.source===undefined?-1:pr.textureIndex]||null};
  });this.models.set(id,{primitives,textures,animator,centerX,centerZ,minY:min[1],scale});
 }
 _bindBuffers(buffers){const gl=this.gl;for(const [idx,attr,size] of [[0,this.pos,3],[1,this.nor,3],[2,this.color,3],[3,this.uv,2]]){gl.bindBuffer(gl.ARRAY_BUFFER,buffers[idx]);gl.enableVertexAttribArray(attr);gl.vertexAttribPointer(attr,size,gl.FLOAT,false,0,0);}}
 _drawModels(vp){const gl=this.gl;
  for(const token of this.tokens){if(!token.combat3d||!token.customModel||!token.modelId)continue;const model=this.models.get(token.modelId);if(!model)continue;
   const cell=this.board.cells[`${Math.floor(token.x)},${Math.floor(token.y)}`]||{},terrain=clamp(Number(cell.height)||0,0,6),x=token.x+.5-this.board.width/2,z=token.y+.5-this.board.height/2,y=.13+terrain*.65+(Number(token.lift)||0);
   const a=token.kind==='enemy'?-Math.PI/2:Math.PI/2,c=Math.cos(a),s=Math.sin(a),factor=token.boss?1.42:token.kind==='enemy'?1.12:1;
   const world=[c*factor,0,-s*factor,0,0,factor,0,0,s*factor,0,c*factor,0,x,y,z,1];gl.uniformMatrix4fv(this.mat,false,new Float32Array(multiply(vp,world)));
   for(const part of model.primitives){
    if(part.rig&&model.animator?.animated&&token.clipAction){
     const requested=token.manualClip||model.animator.actions[token.clipAction]||(token.clipAction==='idle'?null:model.animator.actions.attack)||model.animator.actions.idle||model.animator.clips[0]?.name;
     const clip=model.animator.clips.find(c=>c.name===requested);
     if(clip){const seconds=token.clipAction==='idle'&&!model.animator.actions.idle&&!token.manualClip?0:token.clipLoop===false?Math.min(clip.duration,Math.max(0,token.clipTime||0)*clip.duration):((token.clipTime||0)%clip.duration);
      const transition=token.clipTransition;
      const fromName=transition?.fromManual||model.animator.actions[transition?.fromAction]||model.animator.actions.idle||model.animator.clips[0]?.name;
      const fromClip=model.animator.clips.find(c=>c.name===fromName);
      const fromSeconds=fromClip?(transition?.fromAction==='idle'?(Number(transition?.fromTime)||0)%fromClip.duration:Math.min(fromClip.duration,(Number(transition?.fromTime)||0)*fromClip.duration)):0;
      const pose=transition&&fromClip&&fromName!==requested&&typeof model.animator.deformBlend==='function'
       ?model.animator.deformBlend(part.rig,fromName,fromSeconds,requested,seconds,transition.alpha)
       :model.animator.deform(part.rig,requested,seconds);
      if(pose){const pts=pose.positions;for(let k=0;k<pts.length;k+=3){pts[k]=(pts[k]-model.centerX)*model.scale;pts[k+1]=(pts[k+1]-model.minY)*model.scale;pts[k+2]=(pts[k+2]-model.centerZ)*model.scale;}
       gl.bindBuffer(gl.ARRAY_BUFFER,part.buffers[0]);gl.bufferData(gl.ARRAY_BUFFER,pts,gl.DYNAMIC_DRAW);
       gl.bindBuffer(gl.ARRAY_BUFFER,part.buffers[1]);gl.bufferData(gl.ARRAY_BUFFER,pose.normals,gl.DYNAMIC_DRAW);
      }
     }
    }
    this._bindBuffers(part.buffers);gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,part.texture);gl.uniform1f(this.textured,part.texture?1:0);gl.drawArrays(gl.TRIANGLES,0,part.count);
   }
  }
 }
 update(board,tokens=[],selected=null,story=0,hideAbove=4){if(!board)return;this.board=board;this.tokens=tokens;this.selected=selected;this.story=story;this.hideAbove=hideAbove;const signature=JSON.stringify([board,tokens,selected,story,hideAbove]);if(signature!==this.cached){this.cached=signature;this.mesh=generate(board,tokens,{selected,story,hideAbove});const gl=this.gl;for(const [i,arr] of [this.mesh.p,this.mesh.n,this.mesh.c,new Array(this.mesh.p.length/3*2).fill(0)].entries()){gl.bindBuffer(gl.ARRAY_BUFFER,this.buff[i]);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(arr),gl.DYNAMIC_DRAW);}}this.render();}
 getCamera(){return {yaw:this.yaw,pitch:this.pitch,distance:this.distance,target:[...this.target],projection:this.projection};}
 _rays(clientX,clientY){if(!this.board)return null;const rect=this.canvas.getBoundingClientRect();if(rect.width<=0||rect.height<=0)return null;const nx=((clientX-rect.left)/rect.width)*2-1,ny=1-((clientY-rect.top)/rect.height)*2,asp=rect.width/rect.height,p=cameraFor(this.board,this),f=p.forward,right=norm(cross(f,[0,1,0])),up=norm(cross(right,f));let origin=p.eye,dir=f;
  if(this.projection==='orthographic'){const extent=this.distance*.37;origin=p.eye.map((v,i)=>v+right[i]*nx*extent*asp+up[i]*ny*extent);}
  else{const t=Math.tan(48*RAD/2);dir=norm(f.map((v,i)=>v+right[i]*nx*t*asp+up[i]*ny*t));}
  return {origin,dir};}
 pick(clientX,clientY){const ray=this._rays(clientX,clientY);if(!ray)return null;const b=this.board,fog=new Set(b.fog||[]);let hit=null,best=Infinity;for(let y=0;y<b.height;y++)for(let x=0;x<b.width;x++){if(fog.has(x+','+y))continue;const cell=b.cells[x+','+y]||{},top=.13+clamp(cell.height||0,0,6)*.65;const levels=[0,...Object.keys(cell.stories||{}).map(Number).filter(v=>v>=1&&v<=this.hideAbove)];for(const story of levels){const t=top+story*2.08;const d=rayAabb(ray.origin,ray.dir,[x-b.width/2+.01,t-.23,y-b.height/2+.01],[x+1-b.width/2-.01,t+.07,y+1-b.height/2-.01]);if(d!==null&&d<best){best=d;hit={x,y,story};}}}return hit;}
 orbit(dx,dy){this.yaw=(this.yaw+dx*.42+360)%360;this.pitch=clamp(this.pitch+dy*.32,12,83);this.render();}
 pan(dx,dy){const p=cameraFor(this.board||{},this),right=norm(cross(p.forward,[0,1,0])),up=norm(cross(right,p.forward)),scale=this.distance*.0017;this.target=this.target.map((v,i)=>v-right[i]*dx*scale+up[i]*dy*scale);this.render();}
 zoom(delta){this.distance=clamp(this.distance*Math.exp(delta*.001),4.5,95);this.render();}
 focus(x,y){if(!this.board)return;const c=this.board.cells[x+','+y]||{};this.target=[x+.5-this.board.width/2,Math.max(.4,(Number(c.height)||0)*.65),y+.5-this.board.height/2];this.render();}
 reset(){if(!this.board)return;this.target=[0,1,0];this.yaw=42;this.pitch=54;this.distance=clamp(Math.max(this.board.width,this.board.height)*1.55,15,58);this.projection='perspective';this.render();}
 setProjection(v){this.projection=v==='orthographic'?'orthographic':'perspective';this.render();}
 render(){if(!this.gl||!this.board||!this.mesh)return;const gl=this.gl,rect=this.canvas.getBoundingClientRect();if(!rect.width||!rect.height)return;const dpr=clamp(root.devicePixelRatio||1,1,1.7),w=Math.round(rect.width*dpr),h=Math.round(rect.height*dpr);if(this.canvas.width!==w||this.canvas.height!==h){this.canvas.width=w;this.canvas.height=h;}gl.viewport(0,0,w,h);
  const lighting=this.board.lighting||'day',mode={day:{bg:[.075,.103,.16,1],amb:.80},dusk:{bg:[.13,.087,.155,1],amb:.63},night:{bg:[.036,.043,.095,1],amb:.47},cavern:{bg:[.048,.036,.083,1],amb:.49}}[lighting]||{bg:[.08,.1,.16,1],amb:.8};gl.clearColor(...mode.bg);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);const cam=cameraFor(this.board,this),aspect=w/h;const projection=this.projection==='orthographic'?orthographic(-this.distance*.37*aspect,this.distance*.37*aspect,-this.distance*.37,this.distance*.37,.1,230):perspective(48*RAD,aspect,.1,230);const vp=multiply(projection,lookAt(cam.eye,cam.target));gl.useProgram(this.program);gl.uniformMatrix4fv(this.mat,false,new Float32Array(vp));gl.uniform1f(this.ambient,mode.amb);gl.activeTexture?.(gl.TEXTURE0);gl.uniform1i?.(this.texUniform,0);gl.uniform1f(this.textured,0);this._bindBuffers(this.buff);gl.drawArrays(gl.TRIANGLES,0,this.mesh.p.length/3);this._drawModels(vp);
 }
 destroy(){const gl=this.gl;if(!gl)return;for(const b of this.buff)gl.deleteBuffer(b);for(const model of this.models.values()){for(const mesh of model.primitives)for(const b of mesh.buffers)gl.deleteBuffer(b);for(const t of model.textures)if(t)gl.deleteTexture(t);}this.models.clear();gl.deleteProgram(this.program);this.gl=null;}
}
root.Astronyx3D={Viewer,matColor,generate,cameraFor,rayAabb};
if(typeof module!=='undefined'&&module.exports)module.exports={Viewer,matColor,generate,cameraFor,rayAabb,perspective,lookAt,multiply};
})(typeof window!=='undefined'?window:globalThis);
