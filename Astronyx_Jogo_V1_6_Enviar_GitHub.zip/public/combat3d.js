/* Astronyx V0.9 — Arena WebGL multiplayer.
   Todo dano/HP/XP vem do servidor. Este módulo somente apresenta os eventos.
   Não usa CDN nem distribui modelos 3D proprietários. */
(function(root){
'use strict';
const clamp=(n,a,b)=>Math.max(a,Math.min(b,Number(n)||0));
const scenes={
 forest:{floor:'grass',second:'dirt',props:['tree','bush','rock','torch']},
 crystal:{floor:'marble',second:'stone',props:['pillar','rock','altar','torch']},
 ember:{floor:'cobble',second:'stone',props:['brazier','pillar','rock','banner']}
};
function makeArena(scene='forest',boss=false){
 const cfg=scenes[scene]||scenes.forest;
 const width=12,height=8,cells={};
 for(let y=0;y<height;y++)for(let x=0;x<width;x++){
  const border=y===0||y===height-1||x===0||x===width-1;
  const checker=(x*7+y*11)%8;
  const cell={floor:checker===0?cfg.second:cfg.floor,walls:{}};
  if(border&&(x+y)%2===0){
    cell.prop=cfg.props[(x*3+y)%cfg.props.length];
    if(cell.prop==='torch'||cell.prop==='brazier')cell.light=2;
  }
  if(y===0&&x>2&&x<9&&x%2===0)cell.walls.n=scene==='forest'?'wood': 'stone';
  if(boss&&y===1&&x===6){cell.prop=scene==='ember'?'brazier':'altar';cell.light=2;}
  cells[`${x},${y}`]=cell;
 }
 return {width,height,cells,fog:[],lighting:scene==='ember'?'dusk':scene==='crystal'?'cavern':'day'};
}
function characters(state,{showDefeated=false}={}){
 if(!state)return [];
 const party=(state.members||[]).filter(x=>showDefeated||x.hp>0);
 const ready=party.slice(0,8).map((m,i)=>({id:m.id,kind:'hero',classId:m.classId||'guardian',x:2+(i%2)*.85,y:2+Math.floor(i/2)*1.2,combat3d:true,alive:m.hp>0}));
 const e=state.auto?.enemy;
 if(e&&(e.hp>0||showDefeated))ready.push({id:'enemy',kind:'enemy',boss:!!e.boss,phase:e.phase||1,x:8,y:3.5,combat3d:true,alive:e.hp>0});
 return ready;
}
function ease(t){t=clamp(t,0,1);return Math.sin(t*Math.PI);}
function offsets(event,progress,actorId){
 const wave=ease(progress),kind=event?.kind;
 const actor=event?.actorId===actorId;
 const enemy=actorId==='enemy';
 if(enemy&&['enemy_attack'].includes(kind))return {x:-2.15*wave,lift:.25*wave};
 if(enemy&&['attack','skill','ultimate'].includes(kind))return {x:.15*wave,lift:.06*wave};
 if(actor&&['attack','skill','ultimate'].includes(kind))return {x:(kind==='ultimate'?3.0:2.1)*wave,lift:(kind==='attack'?.18:.55)*wave,aura:kind==='ultimate'?1:kind==='skill'?.5:0};
 if(actor&&['heal','guard','potion'].includes(kind))return {x:0,lift:.28*wave,aura:.8};
 if(actorId===event?.targetId&&kind==='enemy_attack')return {x:-.28*wave,lift:.15*wave};
 return {x:0,lift:0,aura:0};
}
function cameraShot(kind){
 if(kind==='ultimate')return {yaw:14,pitch:26,distance:11};
 if(kind==='phase'||kind==='intro')return {yaw:4,pitch:31,distance:13};
 if(kind==='enemy_attack')return {yaw:24,pitch:30,distance:13};
 return {yaw:25,pitch:39,distance:15};
}
class CombatStage{
 constructor(canvas,{onFailure=()=>{},fetchModel=null}={}){
  if(!root.Astronyx3D?.Viewer)throw Error('Motor WebGL 3D não encontrado.');
  this.canvas=canvas;this.viewer=new root.Astronyx3D.Viewer(canvas);this.onFailure=onFailure;this.fetchModel=fetchModel;this.loading=new Set();this.badModels=new Set();
  this.board=makeArena();this.state=null;this.sceneKey='';this.motion=null;this.last=0;this.frame=0;
  this.active=true;this.userYaw=28;this.userPitch=39;this.userDistance=15;this.cameraMode='cinematic';
  this.viewer.yaw=this.userYaw;this.viewer.pitch=this.userPitch;this.viewer.distance=this.userDistance;
  this.viewer.target=[0,.55,0];this.viewer.projection='perspective';
  this.events=[];this.drag=null;this.clipTransitions=new Map();this.smoothTransitions=true;this.weaponFxEnabled=true;
  this._down=e=>{if(e.button>1)return;e.preventDefault();this.drag={x:e.clientX,y:e.clientY};canvas.setPointerCapture?.(e.pointerId);};
  this._move=e=>{if(!this.drag)return;const dx=e.clientX-this.drag.x,dy=e.clientY-this.drag.y;this.drag={x:e.clientX,y:e.clientY};this.userYaw=(this.userYaw+dx*.45+360)%360;this.userPitch=clamp(this.userPitch+dy*.35,15,76);};
  this._up=()=>{this.drag=null;};
  this._wheel=e=>{e.preventDefault();this.userDistance=clamp(this.userDistance*Math.exp(e.deltaY*.001),7,31);};
  this._lost=e=>{e.preventDefault();this.fail('O navegador perdeu o contexto WebGL.');};
  canvas.addEventListener('pointerdown',this._down);canvas.addEventListener('pointermove',this._move);
  canvas.addEventListener('pointerup',this._up);canvas.addEventListener('pointercancel',this._up);
  canvas.addEventListener('wheel',this._wheel,{passive:false});canvas.addEventListener('webglcontextlost',this._lost);
  this.frame=root.requestAnimationFrame(t=>this.tick(t));
 }
 sync(state){
  if(!this.active||!state?.auto)return;
  this.state=state;
  this.loadAssignedModels(state.modelLibrary).catch(err=>root.console?.warn?.('Modelos 3D:',err.message));
  const key=`${state.room.scene}:${state.auto.stage}:${Boolean(state.auto.enemy?.boss)}`;
  if(key!==this.sceneKey){this.sceneKey=key;this.board=makeArena(state.room.scene,Boolean(state.auto.enemy?.boss));this.motion=null;this.clipTransitions.clear();}
  this.paint(root.performance?.now?.()||0);
 }
 async loadAssignedModels(library){
  if(!this.active||!this.fetchModel||!root.AstronyxGLB)return;
  const assigned=Object.values(library?.slots||{});
  for(const id of new Set(assigned)){
   if(!/^[a-f0-9]{24}$/.test(id)||this.viewer.models.has(id)||this.loading.has(id)||this.badModels.has(id))continue;
   this.loading.add(id);
   try{const buffer=await this.fetchModel(id);if(!this.active)return;const parsed=root.AstronyxGLB.parseGLB(buffer);const images=await root.AstronyxGLB.embeddedImages(parsed);if(!this.active){images.forEach(x=>x?.close?.());return;}this.viewer.loadModel(id,parsed,images);this.paint(root.performance?.now?.()||0);}
   catch(err){this.badModels.add(id);root.console?.warn?.('GLB não carregado; usando miniatura padrão:',err.message);}
   finally{this.loading.delete(id);}
  }
 }
 play(event,duration){
  if(!this.active)return;
  const start=root.performance?.now?.()||0;
  this.motion={event,start,duration:Math.max(100,duration||950)};
 }
 setCamera(name){
  this.cameraMode=['cinematic','side','overhead'].includes(name)?name:'cinematic';
  const presets={cinematic:{yaw:28,pitch:39,distance:15},side:{yaw:2,pitch:22,distance:17},overhead:{yaw:45,pitch:74,distance:20}};
  const c=presets[this.cameraMode];this.userYaw=c.yaw;this.userPitch=c.pitch;this.userDistance=c.distance;
 }
 focus(){this.viewer.target=[0,.55,0];this.setCamera('cinematic');}
 tick(t){
  if(!this.active)return;
  if(t-this.last>45){this.last=t;try{this.paint(t);}catch(err){this.fail(err.message);return;}}
  this.frame=root.requestAnimationFrame(time=>this.tick(time));
 }
 paint(t){
  if(!this.state||!this.active||!this.canvas.isConnected||root.document?.hidden)return;
  const m=this.motion,tokens=characters(this.state,{showDefeated:m?.event?.kind==='victory'||m?.event?.kind==='defeat'});
  const library=this.state.modelLibrary||{slots:{}};for(const token of tokens){const slot=token.kind==='enemy'?(token.boss?'boss':'enemy'):token.classId;const id=library.slots?.[slot];if(id&&this.viewer.models.has(id)){token.modelId=id;token.customModel=true;}}
  let progress=1,impact=0;
  if(m){progress=clamp((t-m.start)/m.duration,0,1);impact=ease(progress);if(progress>=1)this.motion=null;}
  for(const token of tokens){
   const actor=m?.event?.actorId===token.id||(token.id==='enemy'&&m?.event?.kind==='enemy_attack');
   const target=m?.event?.targetId===token.id||(token.id==='enemy'&&m&&['attack','skill','ultimate'].includes(m.event.kind));
   token.clipAction=!token.alive?'death':actor?(m.event.kind==='ultimate'?'ultimate':m.event.kind==='skill'?'skill':m.event.kind==='enemy_attack'?'attack':m.event.kind==='heal'?'skill':m.event.kind==='guard'?'guard':'attack'):target?'hit':'idle';
   token.clipTime=token.clipAction==='idle'?t/1000:progress;
   token.clipLoop=token.clipAction==='idle';
   if(this.previewClip&&token.kind==='hero'){token.manualClip=this.previewClip;token.clipLoop=true;token.clipTime=t/1000;}
   // Crossfade só da apresentação: clipes antigos misturam com os atuais por 220 ms.
   const nextKey=token.manualClip?'manual:'+token.manualClip:token.clipAction;
   let transition=this.clipTransitions.get(token.id);
   if(!transition){transition={key:nextKey,action:token.clipAction,manual:token.manualClip,time:token.clipTime,start:t};this.clipTransitions.set(token.id,transition);}
   else if(transition.key!==nextKey){transition={key:nextKey,action:token.clipAction,manual:token.manualClip,time:token.clipTime,start:t,fromAction:transition.action,fromManual:transition.manual,fromTime:transition.time};this.clipTransitions.set(token.id,transition);}
   if(this.smoothTransitions&&transition.fromAction&&t-transition.start<220){
     const ratio=clamp((t-transition.start)/220,0,1);
     token.clipTransition={fromAction:transition.fromAction,fromManual:transition.fromManual,fromTime:transition.fromTime,alpha:ratio*ratio*(3-2*ratio)};
   }
   // Mantemos o tempo original da pose anterior enquanto ocorre a troca de clipe.
   transition.time=token.clipTime;
   if(m){const offset=offsets(m.event,progress,token.id);token.x+=offset.x||0;token.lift=offset.lift||0;token.aura=offset.aura||0;
     const attacker=actor&&['attack','skill','ultimate','enemy_attack'].includes(m.event.kind);
     if(this.weaponFxEnabled&&attacker){token.vfxPower=m.event.kind==='ultimate'?1:m.event.kind==='skill'?.78:.54;token.vfxProgress=progress;token.vfxBurst=m.event.kind!=='attack'&&m.event.kind!=='enemy_attack';}
   }
  }
  // O enfoque cinematográfico é temporário; a rotação do usuário continua independente.
  const shot=m?cameraShot(m.event.kind):null;
  this.viewer.yaw=shot?this.userYaw+(shot.yaw-this.userYaw)*impact*.7:this.userYaw;
  this.viewer.pitch=shot?this.userPitch+(shot.pitch-this.userPitch)*impact*.55:this.userPitch;
  this.viewer.distance=shot?this.userDistance+(shot.distance-this.userDistance)*impact*.7:this.userDistance;
  // Durante o golpe, acompanhe o meio da arena sem modificar alvo do jogador.
  this.viewer.target=[m?impact*.2:0,.55,0];
  this.viewer.update(this.board,tokens,null,0,0);
 }
 fail(message){if(!this.active)return;this.destroy();this.onFailure(message);}
 destroy(){
  if(!this.active)return;
  this.active=false;root.cancelAnimationFrame?.(this.frame);
  this.canvas.removeEventListener('pointerdown',this._down);this.canvas.removeEventListener('pointermove',this._move);
  this.canvas.removeEventListener('pointerup',this._up);this.canvas.removeEventListener('pointercancel',this._up);
  this.canvas.removeEventListener('wheel',this._wheel);this.canvas.removeEventListener('webglcontextlost',this._lost);
  this.clipTransitions.clear();this.viewer.destroy();
 }
}
root.AstronyxCombat3D={CombatStage,makeArena,characters,offsets,cameraShot};
if(typeof module!=='undefined'&&module.exports)module.exports={CombatStage,makeArena,characters,offsets,cameraShot};
})(typeof window!=='undefined'?window:globalThis);
