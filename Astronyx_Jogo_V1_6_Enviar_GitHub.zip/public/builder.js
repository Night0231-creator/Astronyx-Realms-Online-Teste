/* Astronyx Atelier V0.5 — editor WebGL 3D + fallback isométrico, sem CDN. */
(() => {
'use strict';
const $=q=>document.querySelector(q);
const TOOLS=[['inspect','⌖','Selecionar'],['floor','▦','Pisos'],['wall','▥','Paredes'],['prop','♜','Objetos'],['height','⇧','Elevação'],['light','✧','Luzes'],['fog','☁','Neblina'],['erase','⌫','Apagar']];
const LIB={floor:[['grass','Grama','🌿'],['stone','Pedra','▧'],['wood','Madeira','🪵'],['sand','Areia','▤'],['water','Água','≈'],['lava','Lava','♨'],['snow','Neve','❄'],['dirt','Terra','◈'],['marble','Mármore','◇'],['cobble','Calçada','▦']],wall:[['stone','Muralha','▥'],['wood','Parede de madeira','▣'],['brick','Tijolos','▤'],['iron','Ferro','⋈'],['door','Porta','🚪'],['window','Janela','⊞'],['fence','Cerca','║']],prop:[['tree','Árvore','♣'],['rock','Rocha','⬟'],['crate','Caixote','▣'],['barrel','Barril','▤'],['table','Mesa','▭'],['chair','Cadeira','▯'],['torch','Tocha','✧'],['altar','Altar','✦'],['chest','Baú','♜'],['pillar','Coluna','▥'],['bed','Cama','▬'],['bush','Arbusto','♧'],['statue','Estátua','♙'],['stairs','Escada','▱'],['ladder','Escada vertical','☷'],['well','Poço','◉'],['campfire','Fogueira','♨'],['bridge','Ponte','╬'],['roof','Telhado','⌂'],['arch','Arco','∩'],['spire','Torre','♜'],['brazier','Braseiro','♨'],['banner','Estandarte','⚑'],['fountain','Fonte','◉'],['portal','Portal','✧'],['bookshelf','Estante','▥'],['rug','Tapete','▤']]};
const COLORS={grass:['#4b8965','#2e6652'],stone:['#909ab3','#4d5d7e'],wood:['#986442','#68422c'],sand:['#d3b77e','#9c8056'],water:['#2e8da3','#215273'],lava:['#f17d3c','#aa322e'],snow:['#cbd9e5','#92aec9'],dirt:['#886b58','#604839'],marble:['#c6c0d9','#8585a9'],cobble:['#7786a5','#4d5d78']};
const LIGHT={day:['#151d32','#1a2845'],dusk:['#30203d','#704859'],night:['#090e23','#263456'],cavern:['#101023','#392642']};
let getState=()=>null,send=()=>Promise.resolve(false),notify=()=>{},opened=false,tool='floor',material='grass',side='n',selected=null;
let zoom=1,panX=0,panY=0,drawTiles=[],painting=false,panning=false,start=null,dragged=new Set(),strokeTool='floor',busy=false,view={ox:600,oy:74,tw:42,th:23,rise:17};
let three=null,viewMode='3d',activeStory=0,hideAbove=4,orbiting=false,orbitMode='',lastPoint=null,touchPointers=new Map(),touchDistance=0;
const cv3d=()=>$('#builder-3d-canvas');
const cv=()=>$('#builder-canvas');const ctx=()=>cv().getContext('2d');
const tileKey=(x,y)=>x+','+y;
const materialList=()=>LIB[tool]||[];
const state=()=>getState();const b=()=>state()?.build;
const canEdit=()=>state()?.me?.role==='gm';
const bound=(v,min,max)=>Math.max(min,Math.min(max,v));
function iso(x,y,height=0){return{x:view.ox+(x-y)*view.tw/2,y:view.oy+(x+y)*view.th/2-height*view.rise};}
function poly(c,points,fill,stroke='rgba(255,255,255,.1)',width=1){c.beginPath();c.moveTo(points[0].x,points[0].y);for(let i=1;i<points.length;i++)c.lineTo(points[i].x,points[i].y);c.closePath();c.fillStyle=fill;c.fill();if(stroke){c.strokeStyle=stroke;c.lineWidth=width;c.stroke();}}
function ellipse(c,x,y,rx,ry,fill){c.beginPath();c.ellipse(x,y,rx,ry,0,0,2*Math.PI);c.fillStyle=fill;c.fill();}
function bar(c,x,y,w,h,color){c.fillStyle=color;c.fillRect(x,y,w,h);}
function text(c,msg,x,y,size=15,color='#fff',align='center',weight=600){c.font=`${weight} ${size}px system-ui,Arial`;c.fillStyle=color;c.textAlign=align;c.textBaseline='middle';c.fillText(msg,x,y);}
function topQuad(x,y,h=0){return[iso(x,y,h),iso(x+1,y,h),iso(x+1,y+1,h),iso(x,y+1,h)];}
function face(c,pts,offset,color){poly(c,[pts[1],pts[2],{x:pts[2].x,y:pts[2].y+offset},{x:pts[1].x,y:pts[1].y+offset}],color);poly(c,[pts[2],pts[3],{x:pts[3].x,y:pts[3].y+offset},{x:pts[2].x,y:pts[2].y+offset}],color);}
function prop(c,cell,x,y){if(!cell.prop)return;const point=iso(x+.5,y+.5,cell.height||0),p=cell.prop;
 const unit=view.tw/42;
 ellipse(c,point.x,point.y+2,14*unit,5*unit,'rgba(0,0,0,.30)');
 c.save();c.translate(point.x,point.y);c.scale(unit,unit);
 if(p==='tree'||p==='bush'){
  if(p==='tree'){bar(c,-3,-36,6,35,'#845735');for(const [px,py,r] of [[0,-42,17],[-11,-33,13],[13,-34,13],[0,-55,12]])ellipse(c,px,py,r,r*.8,'#3eaa80');}
  else for(const [px,py] of [[-7,-10],[7,-11],[0,-20]])ellipse(c,px,py,12,10,'#4ba675');
 }else if(p==='rock'){poly(c,[{x:-15,y:-8},{x:-11,y:-22},{x:5,y:-27},{x:17,y:-13},{x:9,y:-3},{x:-13,y:-2}],'#8090a5','#afb9c7');}
 else if(p==='torch'||p==='campfire'){
  if(p==='torch')bar(c,-2,-27,4,28,'#9c6547');else for(let i=-1;i<=1;i++)bar(c,i*8-2,-4,12,4,'#986344');
  ellipse(c,0,p==='torch'?-34:-13,7,p==='torch'?13:17,'#ffb754');ellipse(c,0,p==='torch'?-34:-13,3,7,'#fff4b6');
 }else if(p==='chest'){bar(c,-13,-16,26,17,'#815536');bar(c,-13,-18,26,6,'#d0a95c');bar(c,-2,-16,5,17,'#eccd87');}
 else if(p==='pillar'||p==='statue'){bar(c,-10,-48,20,47,'#a4a7b9');bar(c,-13,-51,26,7,'#dbd5d5');bar(c,-14,-5,28,6,'#706b8d');if(p==='statue')text(c,'♟',0,-61,22,'#e6dfd9');}
 else if(p==='stairs'||p==='ladder'){for(let i=0;i<5;i++){bar(c,-17+i*2,-5-i*4,34-i*4,4,'#b6a7a0');}}
 else if(p==='bridge'){bar(c,-23,-8,46,10,'#b48750');for(let i=-15;i<25;i+=11)bar(c,i,-9,3,11,'#60402d');}
 else if(p==='well'){ellipse(c,0,-5,17,10,'#7d869d');ellipse(c,0,-7,10,5,'#1b4d6c');}
 else if(p==='barrel'){ellipse(c,0,-14,11,6,'#ad7947');bar(c,-11,-14,22,15,'#81522c');ellipse(c,0,1,11,5,'#7c4c29');}
 else if(p==='table'||p==='altar'){bar(c,-17,-14,34,5,p==='altar'?'#9a91c5':'#b48750');bar(c,-13,-10,5,13,'#70503c');bar(c,8,-10,5,13,'#70503c');if(p==='altar')text(c,'✧',0,-28,20,'#d9b8ff');}
 else if(p==='crate'){bar(c,-13,-22,26,25,'#90613b');bar(c,-13,-22,26,5,'#be9366');text(c,'×',0,-11,16,'#d1a66e');}
 else if(p==='chair'||p==='bed'){bar(c,-12,-12,24,9,'#896447');if(p==='bed')bar(c,-14,-5,28,7,'#d6b1a2');else bar(c,-12,-31,5,24,'#896447');}
 else {text(c,'✦',0,-14,23,'#eac5ff');}
 c.restore();
}
function drawWall(c,cell,x,y){const walls=cell.walls||{};for(const [side,mat] of Object.entries(walls)){
 const h=cell.height||0,top=topQuad(x,y,h),edges={n:[0,1],e:[1,2],s:[2,3],w:[3,0]};const pair=edges[side];if(!pair)continue;
 const a=top[pair[0]],d=top[pair[1]],wallHeight=view.rise*2.3,offset=mat==='fence'?wallHeight*.55:wallHeight;
 const tone=mat==='wood'?'#86654b':mat==='door'?'#a77147':mat==='window'?'#84b5bf':mat==='fence'?'#967a66':'#8390a9';
 poly(c,[{x:a.x,y:a.y-offset},{x:d.x,y:d.y-offset},d,a],tone,'rgba(2,5,16,.46)',1.1);
 c.beginPath();c.moveTo(a.x,a.y-offset);c.lineTo(d.x,d.y-offset);c.strokeStyle='#d5cad5';c.lineWidth=2;c.stroke();
 if(mat==='door'||mat==='window'){const mx=(a.x+d.x)/2,my=(a.y+d.y)/2-offset*.5;text(c,mat==='door'?'⌗':'◈',mx,my,Math.max(12,view.tw*.4),mat==='door'?'#f4d49e':'#b4eeff');}
}}
function tile(c,x,y,t,hidden){const h=t.height||0,pts=topQuad(x,y,h),colors=COLORS[t.floor]||COLORS.grass;
 const thickness=Math.max(4,6+h*view.rise);
 face(c,pts,thickness,colors[1]);
 const grad=c.createLinearGradient(pts[0].x,pts[0].y,pts[2].x,pts[2].y);grad.addColorStop(0,colors[0]);grad.addColorStop(1,colors[1]);poly(c,pts,grad,'rgba(0,0,0,.28)',.7);
 if(t.floor==='water'||t.floor==='lava'){c.save();c.strokeStyle=t.floor==='water'?'rgba(134,231,255,.60)':'rgba(255,232,128,.57)';c.lineWidth=1.3;c.beginPath();c.moveTo(pts[3].x+10,pts[3].y-3);c.lineTo(pts[2].x-8,pts[2].y-3);c.stroke();c.restore();}
 if(t.light){const p=iso(x+.5,y+.5,h);const r=view.tw*(1.2+t.light*.5);const g=c.createRadialGradient(p.x,p.y,0,p.x,p.y,r);g.addColorStop(0,'rgba(255,201,108,.22)');g.addColorStop(1,'rgba(255,201,108,0)');ellipse(c,p.x,p.y,r,r*.64,g);}
 if(hidden){poly(c,pts,'rgba(9,12,30,.91)','#4f547b',1);const p=iso(x+.5,y+.5,h);text(c,'?',p.x,p.y,15,'#858cb1');return;}
 drawWall(c,t,x,y);prop(c,t,x,y);
}
function pointIn(p,poly){let inside=false;for(let i=0,j=poly.length-1;i<poly.length;j=i++)if((poly[i].y>p.y)!==(poly[j].y>p.y)&&p.x<(poly[j].x-poly[i].x)*(p.y-poly[i].y)/(poly[j].y-poly[i].y)+poly[i].x)inside=!inside;return inside;}
function pick(clientX,clientY){const rect=cv().getBoundingClientRect();const mouse={x:(clientX-rect.left)*cv().width/rect.width,y:(clientY-rect.top)*cv().height/rect.height};for(let i=drawTiles.length-1;i>=0;i--)if(pointIn(mouse,drawTiles[i].quad))return drawTiles[i];return null;}
function render2d(){const board=b();if(!board||!opened)return;const c=ctx(),w=cv().width,h=cv().height;
 const palette=LIGHT[board.lighting]||LIGHT.day;
 const bg=c.createLinearGradient(0,0,w,h);bg.addColorStop(0,palette[0]);bg.addColorStop(1,palette[1]);c.fillStyle=bg;c.fillRect(0,0,w,h);
 c.save();c.globalAlpha=.24;for(let i=0;i<70;i++){const x=(i*157)%w,y=(i*269)%h;ellipse(c,x,y,(i%3)+.6,(i%3)+.6,'#e4d2e9');}c.restore();
 const area=Math.max(board.width+board.height,20);view.tw=bound(2100/area,32,80)*zoom;view.th=view.tw*.50;view.rise=view.tw*.45;
 view.ox=w/2+panX;view.oy=170+panY;
 drawTiles=[];
 for(let y=0;y<board.height;y++)for(let x=0;x<board.width;x++){const k=tileKey(x,y),t=board.cells[k]||{floor:'grass',height:0,walls:{},prop:null,light:0};drawTiles.push({x,y,t,quad:topQuad(x,y,t.height||0),hidden:board.fog.includes(k)});}
 drawTiles.sort((a,d)=>(a.x+a.y)-(d.x+d.y)||(a.t.height||0)-(d.t.height||0));
 for(const tileInfo of drawTiles)tile(c,tileInfo.x,tileInfo.y,tileInfo.t,tileInfo.hidden);
 for(const token of (state()?.tokens||[])){
  if(token.x>=board.width||token.y>=board.height)continue;
  const t=board.cells[tileKey(token.x,token.y)]||{height:0};
  const p=iso(token.x+.5,token.y+.5,(t.height||0));
  ellipse(c,p.x,p.y-6,view.tw*.22,view.th*.42,'rgba(0,0,0,.5)');
  ellipse(c,p.x,p.y-24,view.tw*.22,view.th*.45,token.kind==='hero'?'#9681e5':'#d5617c');
  text(c,token.kind==='hero'?'♟':'☠',p.x,p.y-25,Math.max(14,view.tw*.45),'#fff4dd');
  text(c,token.label.slice(0,13),p.x,p.y-49,Math.max(11,view.tw*.26),'#ffffff');
 }
 if(selected){const info=drawTiles.find(t=>t.x===selected.x&&t.y===selected.y);if(info){poly(c,info.quad,'rgba(237,192,111,.11)','#ffe0a0',3);}}
 if(board.lighting==='night'||board.lighting==='cavern'){c.fillStyle='rgba(6,8,20,.19)';c.fillRect(0,0,w,h);}
 const total=Object.keys(board.cells).length;$('#builder-scene-label').textContent=`${board.width}×${board.height} · ${total} modificações · ${board.lighting.toUpperCase()}`;
 $('#builder-sync').textContent=busy?'◌ Sincronizando...':'● Salvo no servidor';
 $('#build-width').value=board.width;$('#build-height').value=board.height;$('#build-lighting').value=board.lighting;
 if(selected){const cell=board.cells[tileKey(selected.x,selected.y)]||{floor:'grass',height:0,walls:{},light:0};$('#build-selection').textContent=`Coluna ${selected.x+1} · Linha ${selected.y+1} | Piso: ${cell.floor} · Altura: ${cell.height||0} · Luz: ${cell.light||0} · Objeto: ${cell.prop||'nenhum'}`;}
}
function renderTopdown(current){
 const board=current?.build,canvas=$('#tabletop-build-layer');if(!board||!canvas)return;
 const c=canvas.getContext('2d'),w=canvas.width,h=canvas.height;
 const dx=w/board.width,dy=h/board.height;c.clearRect(0,0,w,h);
 for(let y=0;y<board.height;y++)for(let x=0;x<board.width;x++){
  const k=tileKey(x,y),t=board.cells[k]||{floor:'grass',height:0,walls:{},prop:null,light:0};
  const X=x*dx,Y=y*dy,cols=COLORS[t.floor]||COLORS.grass;
  c.fillStyle=cols[0]+'dc';c.fillRect(X+.3,Y+.3,dx-.6,dy-.6);
  if((t.height||0)>0){c.lineWidth=2+(t.height||0)*1.5;c.strokeStyle='#ffdc9d';c.strokeRect(X+2,Y+2,dx-4,dy-4);}
  for(const [side,mat] of Object.entries(t.walls||{})){
   c.beginPath();if(side==='n'){c.moveTo(X,Y);c.lineTo(X+dx,Y);}else if(side==='s'){c.moveTo(X,Y+dy);c.lineTo(X+dx,Y+dy);}else if(side==='w'){c.moveTo(X,Y);c.lineTo(X,Y+dy);}else if(side==='e'){c.moveTo(X+dx,Y);c.lineTo(X+dx,Y+dy);}else continue;
   c.lineWidth=mat==='door'?6:mat==='fence'?4:9;c.strokeStyle=mat==='door'?'#e7bf81':mat==='window'?'#8fd4ff':'#cfdae6';c.stroke();
  }
  if(t.prop){text(c,({tree:'♣',rock:'⬟',crate:'▣',barrel:'▤',table:'▭',chair:'♙',torch:'✧',altar:'✦',chest:'♜',pillar:'▥',bed:'▬',bush:'♣',statue:'♟',stairs:'▱',ladder:'☷',well:'◉',campfire:'♨',bridge:'╬'})[t.prop]||'♦',X+dx/2,Y+dy/2,Math.max(16,Math.min(dx,dy)*.52),['tree','bush'].includes(t.prop)?'#164c32':'#fff1c5');}
  if(t.light){ellipse(c,X+dx/2,Y+dy/2,dx*.28,dy*.26,'#ffd58588');}
  if(board.fog.includes(k)){c.fillStyle='#060817eb';c.fillRect(X,Y,dx,dy);text(c,'?',X+dx/2,Y+dy/2,Math.max(14,dx*.22),'#8288ae');}
 }
}
function render(){
 if(!opened||!b())return;
 render2d(); // mantém o tabuleiro tradicional sempre sincronizado
 if(viewMode==='3d'&&three){
  three.update(b(),state()?.tokens||[],selected,activeStory,hideAbove);
  $('#builder-scene-label').textContent=`VISÃO 3D · ${b().width}×${b().height} · PAVIMENTO ${activeStory}`;
  updateCameraUi();
 }
}
function updateCameraUi(){if(!three)return;const c=three.getCamera();$('#build-yaw').value=Math.round(c.yaw);$('#build-pitch').value=Math.round(c.pitch);$('#build-yaw-label').textContent=Math.round(c.yaw)+'°';$('#build-pitch-label').textContent=Math.round(c.pitch)+'°';$('#build-projection').value=c.projection;}
function setViewMode(next){viewMode=next==='3d'&&three?'3d':'2d';
 cv3d().hidden=viewMode!=='3d';cv().hidden=viewMode==='3d';
 $('#build-view-3d').classList.toggle('active',viewMode==='3d');$('#build-view-2d').classList.toggle('active',viewMode==='2d');
 $('#build-camera-options').hidden=viewMode!=='3d';$('.builder-3d-chip').hidden=viewMode!=='3d';
 const footer=$('#build-camera-help');if(footer)footer.textContent=viewMode==='3d'?'BOTÃO DIREITO: GIRAR · SHIFT + DIREITO: MOVER · SCROLL: ZOOM · ALT + ESQUERDO: GIRAR':'ARRASTE: PINTAR · SCROLL: ZOOM · DIREITO: MOVER';
 render();}
function updatePalette(){
 $('#builder-tools').innerHTML=TOOLS.map(([id,icon,label])=>`<button type="button" data-build-tool="${id}" class="${tool===id?'active':''}"><span>${icon}</span>${label}</button>`).join('');
 const mats=materialList();if(mats.length && !mats.some(m=>m[0]===material))material=mats[0][0];
 $('#builder-materials').innerHTML=mats.length?mats.map(([id,label,icon])=>`<button type="button" data-build-material="${id}" class="${material===id?'active':''}"><span>${icon}</span><small>${label}</small></button>`).join(''):
 ['height','light'].includes(tool)?'<button type="button" data-build-delta="1">+ Aumentar</button><button type="button" data-build-delta="-1">− Reduzir</button>':tool==='fog'?'<button type="button" data-build-cover="true">☁ Encobrir</button><button type="button" data-build-cover="false">☀ Revelar</button>':'<p class="builder-help">Clique em uma casa para selecionar ou apagar.</p>';
 if(!canEdit())$('#builder-materials').querySelectorAll('button').forEach(btn=>btn.disabled=true);
 if(activeStory>0)$('#builder-tools').querySelectorAll('[data-build-tool=height],[data-build-tool=fog]').forEach(btn=>{btn.disabled=true;btn.title='Disponível somente no térreo';});
}
let delta=1,covered=true;
function open(value){const s=state();opened=Boolean(value)&&s?.room.mode==='tabletop';$('#game').classList.toggle('builder-mode',opened);$('#builder-workspace').hidden=!opened;$('.map-shell').hidden=opened;$('.play-controls').hidden=opened;$('#token-actions').hidden=opened;
 $('#builder-toggle').textContent=opened?'↩ Voltar ao tabuleiro':'◈ Mesa 3D e estúdio';if(opened){updatePalette();if(viewMode==='3d'&&three&&!three.board){three.board=b();three.reset();}setViewMode(viewMode);render();}}
function setStatus(msg){$('#build-hover').textContent=msg;}
async function command(data){if(!canEdit())return;busy=true;render();try{const ok=await send(data);if(!ok)throw Error('Falha ao salvar cenário');}catch(e){notify(e.message||'Falha na edição.');}finally{busy=false;render();}}
function strokeFrom(a,d){const points=[];const dx=d.x-a.x,dy=d.y-a.y,steps=Math.max(Math.abs(dx),Math.abs(dy));for(let i=0;i<=steps;i++){points.push({x:Math.round(a.x+dx*(steps?i/steps:0)),y:Math.round(a.y+dy*(steps?i/steps:0))});}return points;}
function track(t){if(!t)return;selected={x:t.x,y:t.y};if(!canEdit()||strokeTool==='inspect'){render();setStatus(`Casa ${t.x+1} × ${t.y+1}`);return;}const points=start?strokeFrom(start,t):[{x:t.x,y:t.y}];for(const p of points)dragged.add(tileKey(p.x,p.y));start=t;render();setStatus(`Casa ${t.x+1}×${t.y+1} · ${dragged.size} selecionada(s)`);}
async function finishStroke(){if(!dragged.size||!canEdit()||strokeTool==='inspect')return;const points=[...dragged].map(k=>{const [x,y]=k.split(',').map(Number);return {x,y};});dragged.clear();for(let i=0;i<points.length;i+=80)await command({type:'build_paint',tool:strokeTool,points:points.slice(i,i+80),material,side,delta,covered,story:activeStory});}
function downloadBlueprint(){const board=b();if(!board)return;const blob=new Blob([JSON.stringify({...board,exportedBy:'Astronyx Realms Online',format:'astronyx-builder-v1'},null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=`astronyx-mapa-${Date.now()}.json`;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
function setup(opts){getState=opts.getState;send=opts.action;notify=opts.toast;
 try{if(window.Astronyx3D){three=new window.Astronyx3D.Viewer(cv3d());viewMode='3d';}}catch(error){console.warn('[ASTRONYX 3D] WebGL indisponível, usando visualização 2,5D:',error.message);viewMode='2d';$('#build-view-3d').disabled=true;$('#build-view-3d').title='WebGL indisponível no navegador';}
 setViewMode(viewMode);
 $('#builder-toggle').addEventListener('click',()=>open(!opened));$('#build-finish').addEventListener('click',()=>open(false));
 $('#builder-tools').addEventListener('click',e=>{const btn=e.target.closest('[data-build-tool]');if(!btn)return;tool=btn.dataset.buildTool;material=(LIB[tool]||[])[0]?.[0]||material;updatePalette();});
 $('#builder-materials').addEventListener('click',e=>{const btn=e.target.closest('button');if(!btn)return;if(btn.dataset.buildMaterial){material=btn.dataset.buildMaterial;}if(btn.dataset.buildDelta)delta=Number(btn.dataset.buildDelta);if(btn.dataset.buildCover)covered=btn.dataset.buildCover==='true';updatePalette();});
 $('#build-side').addEventListener('change',e=>side=e.target.value);
 for(const [id,type] of [['#build-undo','build_undo'],['#build-redo','build_redo']])$(id).addEventListener('click',()=>command({type}));
 $('#build-lighting').addEventListener('change',e=>command({type:'build_lighting',lighting:e.target.value}));
 $('#build-resize').addEventListener('click',()=>command({type:'build_resize',width:Number($('#build-width').value),height:Number($('#build-height').value)}));
 $('#build-presets').addEventListener('click',e=>{const btn=e.target.closest('[data-preset]');if(btn&&confirm('Aplicar cenário pronto? Sua construção atual pode ser recuperada com Desfazer.'))command({type:'build_preset',preset:btn.dataset.preset});});
 $('#build-export').addEventListener('click',downloadBlueprint);
 $('#build-import').addEventListener('click',()=>{if(canEdit())$('#build-import-file').click();});
 $('#build-import-file').addEventListener('change',async e=>{const file=e.target.files[0];if(!file)return;if(file.size>650000)return notify('Projeto grande demais (máximo 650 KB).');try{const blueprint=JSON.parse(await file.text());if(confirm('Importar o mapa? A alteração poderá ser desfeita.'))await command({type:'build_import',blueprint});}catch(err){notify(err.message);}finally{e.target.value='';}});
 $('#build-zoom-in').addEventListener('click',()=>{if(viewMode==='3d'&&three)three.zoom(-135);else zoom=bound(zoom+.12,.5,2);render();});
 $('#build-zoom-out').addEventListener('click',()=>{if(viewMode==='3d'&&three)three.zoom(135);else zoom=bound(zoom-.12,.5,2);render();});
 $('#build-reset-camera').addEventListener('click',()=>{if(viewMode==='3d'&&three)three.reset();else{zoom=1;panX=0;panY=0;}render();});
 $('#build-view-3d').addEventListener('click',()=>setViewMode('3d'));$('#build-view-2d').addEventListener('click',()=>setViewMode('2d'));
 $('#build-yaw').addEventListener('input',e=>{if(three){three.yaw=Number(e.target.value);three.render();updateCameraUi();}});
 $('#build-pitch').addEventListener('input',e=>{if(three){three.pitch=Number(e.target.value);three.render();updateCameraUi();}});
 $('#build-projection').addEventListener('change',e=>{if(three)three.setProjection(e.target.value);});
 $('#build-story').addEventListener('change',e=>{activeStory=Number(e.target.value);if(activeStory>0&&['height','fog'].includes(tool)){tool='floor';material='grass';updatePalette();}if(activeStory>hideAbove){hideAbove=activeStory;$('#build-visible-story').value=String(hideAbove);}render();});
 $('#build-visible-story').addEventListener('change',e=>{hideAbove=Number(e.target.value);if(activeStory>hideAbove){activeStory=hideAbove;$('#build-story').value=String(activeStory);}render();});
 $('#build-focus-token').addEventListener('click',()=>{if(!three)return;const tokens=state()?.tokens||[];const token=tokens.find(t=>t.kind==='hero')||tokens[0];if(token)three.focus(token.x,token.y);else three.reset();updateCameraUi();});
 $('#build-floor-level').addEventListener('click',()=>{$('#build-story').value=String(activeStory=0);render();});
 const canvas=cv();canvas.addEventListener('contextmenu',e=>e.preventDefault());
 canvas.addEventListener('wheel',e=>{e.preventDefault();zoom=bound(zoom+(e.deltaY<0?.10:-.10),.5,2);render();},{passive:false});
 canvas.addEventListener('pointerdown',e=>{if(e.button===2||e.button===1){panning=true;start={sx:e.clientX,sy:e.clientY};canvas.setPointerCapture(e.pointerId);return;}const t=pick(e.clientX,e.clientY);if(!t)return;painting=true;start=null;dragged.clear();strokeTool=e.shiftKey?'erase':tool;track(t);canvas.setPointerCapture(e.pointerId);});
 canvas.addEventListener('pointermove',e=>{if(panning){panX+=e.clientX-start.sx;panY+=e.clientY-start.sy;start={sx:e.clientX,sy:e.clientY};render();return;}const t=pick(e.clientX,e.clientY);if(painting&&t)track(t);else if(t)setStatus(`Coluna ${t.x+1} · Linha ${t.y+1}`);});
 canvas.addEventListener('pointerup',async()=>{if(panning){panning=false;start=null;return;}if(painting){painting=false;start=null;await finishStroke();}});
 canvas.addEventListener('pointercancel',()=>{painting=false;panning=false;start=null;dragged.clear();});

 // Controles do visualizador WebGL 3D: câmera desacoplada das ferramentas de construção.
 const surface=cv3d();surface.addEventListener('webglcontextlost',e=>{e.preventDefault();three=null;setViewMode('2d');$('#build-view-3d').disabled=true;notify('O WebGL perdeu o contexto gráfico. Usando a visão isométrica.');});surface.addEventListener('contextmenu',e=>e.preventDefault());
 surface.addEventListener('wheel',e=>{e.preventDefault();if(three){three.zoom(e.deltaY);updateCameraUi();}},{passive:false});
 surface.addEventListener('pointerdown',e=>{
  if(!three)return;surface.setPointerCapture(e.pointerId);touchPointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
  if(touchPointers.size>=2){painting=false;dragged.clear();orbiting=true;orbitMode='touch';lastPoint={x:e.clientX,y:e.clientY};const pts=[...touchPointers.values()];touchDistance=Math.hypot(pts[0].x-pts[1].x,pts[0].y-pts[1].y);return;}
  if(e.button===2||e.button===1||e.altKey){orbiting=true;orbitMode=e.button===1||e.shiftKey?'pan':'rotate';lastPoint={x:e.clientX,y:e.clientY};return;}
  const t=three.pick(e.clientX,e.clientY);if(!t)return;painting=true;start=null;dragged.clear();strokeTool=e.shiftKey?'erase':tool;track(t);
 });
 surface.addEventListener('pointermove',e=>{
  const prior=touchPointers.get(e.pointerId);touchPointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
  if(touchPointers.size>=2&&three){const pts=[...touchPointers.values()];const dist=Math.hypot(pts[0].x-pts[1].x,pts[0].y-pts[1].y);if(touchDistance&&Math.abs(dist-touchDistance)>2)three.zoom((touchDistance-dist)*2);touchDistance=dist;if(prior){three.orbit((e.clientX-prior.x)*.45,(e.clientY-prior.y)*.45);}updateCameraUi();return;}
  if(orbiting&&lastPoint&&three){const dx=e.clientX-lastPoint.x,dy=e.clientY-lastPoint.y;if(orbitMode==='pan')three.pan(dx,dy);else three.orbit(dx,dy);lastPoint={x:e.clientX,y:e.clientY};updateCameraUi();return;}
  const t=three?.pick(e.clientX,e.clientY);if(painting&&t)track(t);else if(t)setStatus(`Casa ${t.x+1} · ${t.y+1} · Pavimento ${t.story}`);
 });
 surface.addEventListener('pointerup',async e=>{touchPointers.delete(e.pointerId);if(orbiting){orbiting=false;orbitMode='';lastPoint=null;touchDistance=0;return;}if(painting){painting=false;start=null;await finishStroke();}});
 surface.addEventListener('pointercancel',e=>{touchPointers.delete(e.pointerId);painting=false;orbiting=false;dragged.clear();start=null;touchDistance=0;});
 window.addEventListener('resize',()=>{if(opened&&viewMode==='3d'&&three)three.render();});
 window.addEventListener('keydown',e=>{if(!opened||viewMode!=='3d'||!three||/INPUT|TEXTAREA|SELECT/.test(document.activeElement?.tagName||'')||e.ctrlKey||e.metaKey)return;
  const k=e.key.toLowerCase();if(k==='q'||k==='e'){three.orbit(k==='q'?-30:30,0);e.preventDefault();}
  if(k==='r'||k==='f'){three.orbit(0,k==='r'?-25:25);e.preventDefault();}
  if(k==='c'){const t=(state()?.tokens||[])[0];if(t)three.focus(t.x,t.y);else three.reset();e.preventDefault();}
  if(k==='+'||k==='='){three.zoom(-130);e.preventDefault();}if(k==='-'){three.zoom(130);e.preventDefault();}
  updateCameraUi();
 });
 updatePalette();
}
window.AstronyxBuilder={setup,render,renderTopdown,open,isOpen:()=>opened};
})();
