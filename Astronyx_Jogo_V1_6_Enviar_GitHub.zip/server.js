'use strict';
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { URL } = require('node:url');
const {accountStore,oauthTickets}=require('./lib/accounts');
const MODELS=require('./lib/models');
const { createRoom, joinRoom, memberFor, applyAction, publicState, ensureRoom, autoTick } = require('./lib/game');
const ROOT = __dirname;
const envPath = path.join(ROOT, '.env');
if (fs.existsSync(envPath)) {
  for (const line of fs.readFileSync(envPath, 'utf8').split(/\r?\n/)) {
    const match = line.match(/^\s*(PORT|HOST|ASTRONYX_DATA_FILE|ASTRONYX_ACCOUNTS_FILE|ALLOWED_ORIGINS|FRONTEND_URL|DISCORD_CLIENT_ID|DISCORD_CLIENT_SECRET|DISCORD_REDIRECT_URI)\s*=\s*(.*?)\s*$/);
    if (match && process.env[match[1]] === undefined) process.env[match[1]] = match[2].replace(/^['\"]|['\"]$/g,'');
  }
}
const PUBLIC = path.join(ROOT,'public');
const DATA = process.env.ASTRONYX_DATA_FILE ? path.resolve(process.env.ASTRONYX_DATA_FILE) : path.join(ROOT,'data','rooms.json');
const MAX_BODY = 750_000;
const MODEL_DIR=MODELS.dirFor(DATA);
const ACCOUNT_FILE=process.env.ASTRONYX_ACCOUNTS_FILE?path.resolve(process.env.ASTRONYX_ACCOUNTS_FILE):path.join(ROOT,'data','accounts.json');
const accounts=accountStore(ACCOUNT_FILE),oauth=oauthTickets();
const DISCORD_CLIENT_ID=process.env.DISCORD_CLIENT_ID||'';
const DISCORD_CLIENT_SECRET=process.env.DISCORD_CLIENT_SECRET||'';
const DISCORD_REDIRECT_URI=process.env.DISCORD_REDIRECT_URI||'';
const AUTH_ENABLED=Boolean(DISCORD_CLIENT_ID&&DISCORD_CLIENT_SECRET&&DISCORD_REDIRECT_URI);
const FRONTEND_URL=(process.env.FRONTEND_URL||'http://localhost:3000').replace(/\/$/,'');
if(AUTH_ENABLED && !/^https:\/\//.test(FRONTEND_URL) && !/^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(FRONTEND_URL))throw new Error('FRONTEND_URL deve usar HTTPS em produção.');
if(AUTH_ENABLED && !/^https:\/\//.test(DISCORD_REDIRECT_URI) && !/^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?\//.test(DISCORD_REDIRECT_URI))throw new Error('DISCORD_REDIRECT_URI deve usar HTTPS em produção.');
function authHeader(req){return String(req.headers['x-astronyx-account']||'').trim();}
function maybeAccount(req){return accounts.verify(authHeader(req));}
function requireAccount(req){const account=maybeAccount(req);if(!account)throw new Error('Faça login com Discord para acessar sua conta.');return account;}
function requireLoginForNewRoom(req){if(AUTH_ENABLED)return requireAccount(req);return maybeAccount(req);}
function redirect(res,url){res.writeHead(302,{'Location':url,'Cache-Control':'no-store','Referrer-Policy':'no-referrer','X-Content-Type-Options':'nosniff'});res.end();}
function loginCookie(req,value,clear=false){
  const secure=DISCORD_REDIRECT_URI.startsWith('https://')?'; Secure':'';
  const cookie=`astronyx_oauth_state=${clear?'':encodeURIComponent(value)}; HttpOnly; SameSite=Lax; Path=/api/auth/discord; Max-Age=${clear?0:600}${secure}`;
  return cookie;
}
function cookieState(req){const part=String(req.headers.cookie||'').split(';').map(x=>x.trim()).find(x=>x.startsWith('astronyx_oauth_state='));return part?decodeURIComponent(part.split('=').slice(1).join('=')):'';}
function nextURL(ticket){const url=new URL(FRONTEND_URL+'/');url.hash='auth_ticket='+encodeURIComponent(ticket);return url.toString();}

const ALLOWED_ORIGINS = new Set((process.env.ALLOWED_ORIGINS||'').split(',').map(x=>x.trim().replace(/\/$/,'')).filter(Boolean));
if(AUTH_ENABLED)ALLOWED_ORIGINS.add(new URL(FRONTEND_URL).origin);
const rooms = new Map();
const subscribers = new Map();
const buckets = new Map();

function load() {
  if (!fs.existsSync(DATA)) return;
  try { const saved=JSON.parse(fs.readFileSync(DATA,'utf8')); for (const room of saved.rooms||[]) rooms.set(room.id,ensureRoom(room)); }
  catch (e) { console.error('ERRO: banco de salas ilegível. Confira data/rooms.json antes de continuar.',e.message); process.exitCode=1; throw e; }
}
function save() {
  fs.mkdirSync(path.dirname(DATA),{recursive:true});
  const tmp = DATA + '.tmp';
  fs.writeFileSync(tmp,JSON.stringify({version:1,rooms:[...rooms.values()]},null,2),{mode:0o600});
  fs.renameSync(tmp,DATA);
}
load();
function send(res,code,obj){
  res.writeHead(code,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});
  res.end(JSON.stringify(obj));
}
function readJSON(req) {
  return new Promise((resolve,reject)=>{
    let body='';
    req.on('data',chunk=>{ body+=chunk; if(body.length>MAX_BODY){reject(new Error('Dados enviados excedem o limite.'));req.destroy();} });
    req.on('end',()=>{try{resolve(JSON.parse(body||'{}'));}catch{reject(new Error('JSON inválido.'));}});
    req.on('error',reject);
  });
}
function getRoom(req,url) {
  const id=String(url.searchParams.get('room')||'').toUpperCase();
  const room=rooms.get(id);
  if (!room) throw new Error('Sala não encontrada. Confira o código.');
  const token=String(req.headers.authorization||'').replace(/^Bearer\s+/i,'').trim();
  const member=memberFor(room,token);
  if(AUTH_ENABLED&&member.accountId&&maybeAccount(req)?.id!==member.accountId)throw new Error('Faça login na conta Discord vinculada a este personagem.');
  return {room,member};
}
function rateLimit(id) {
  const now=Date.now();
  const v=buckets.get(id)||[];
  const keep=v.filter(t=>t>now-3000);
  if (keep.length>=18) throw new Error('Muitas ações seguidas. Aguarde um instante.');
  keep.push(now);buckets.set(id,keep);
  if (buckets.size>4000) for (const [k,ts] of buckets) if(ts.at(-1)<now-120000) buckets.delete(k);
}
function broadcast(id,rev) {
  const set=subscribers.get(id);if(!set)return;
  for(const res of set) {try{res.write(`event: update\ndata: ${JSON.stringify({revision:rev})}\n\n`);}catch{set.delete(res);} }
}
const types={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.jpg':'image/jpeg','.jpeg':'image/jpeg','.png':'image/png','.svg':'image/svg+xml','.ico':'image/x-icon','.webp':'image/webp'};
function staticFile(url,res){
  const relative=decodeURIComponent(url.pathname==='/'?'/index.html':url.pathname);
  if(relative.includes('\0')||relative.includes('\\')||relative.split('/').includes('..'))return send(res,400,{error:'Caminho inválido.'});
  const name=path.resolve(PUBLIC,'.'+relative);
  if(!name.startsWith(PUBLIC+path.sep))return send(res,403,{error:'Acesso negado.'});
  if(!fs.existsSync(name)||!fs.statSync(name).isFile())return send(res,404,{error:'Arquivo não encontrado.'});
  res.writeHead(200,{'Content-Type':types[path.extname(name)]||'application/octet-stream','Cache-Control':'public, max-age=300','X-Content-Type-Options':'nosniff','X-Frame-Options':'DENY','Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self' https: http://localhost:* http://127.0.0.1:*; object-src 'none'; frame-ancestors 'none'; base-uri 'none'"});
  fs.createReadStream(name).pipe(res);
}
const server = http.createServer(async (req,res)=>{
  const url=new URL(req.url,'http://localhost');
  const origin=req.headers.origin;
  if(origin){
    res.setHeader('Vary','Origin');
    let sameOrigin=false;try{sameOrigin=new URL(origin).host===req.headers.host;}catch{}
    if(ALLOWED_ORIGINS.has(origin)||sameOrigin){
      res.setHeader('Access-Control-Allow-Origin',origin);
      res.setHeader('Access-Control-Allow-Methods','GET, POST, OPTIONS');
      res.setHeader('Access-Control-Allow-Headers','Authorization, Content-Type, X-Astronyx-Account, X-Model-Name');
      res.setHeader('Access-Control-Max-Age','600');
    }else if(req.method==='OPTIONS'||url.pathname.startsWith('/api/')){
      return send(res,403,{error:'Origem não autorizada. Configure ALLOWED_ORIGINS no backend.'});
    }
  }
  if(req.method==='OPTIONS'){
    if(!origin)return send(res,405,{error:'Origem ausente.'});
    res.writeHead(204);return res.end();
  }
  try {
    if(req.method==='GET'&&url.pathname==='/api/auth/config')return send(res,200,{enabled:AUTH_ENABLED,frontend:FRONTEND_URL,version:'1.6.0'});
    if(req.method==='GET'&&url.pathname==='/api/auth/discord'){
      if(!AUTH_ENABLED)return send(res,503,{error:'Login Discord ainda não configurado. Confira o .env do servidor.'});
      const state=oauth.start();res.setHeader('Set-Cookie',loginCookie(req,state));
      const discord=new URL('https://discord.com/oauth2/authorize');
      discord.searchParams.set('client_id',DISCORD_CLIENT_ID);discord.searchParams.set('response_type','code');
      discord.searchParams.set('redirect_uri',DISCORD_REDIRECT_URI);discord.searchParams.set('scope','identify');
      discord.searchParams.set('state',state);discord.searchParams.set('prompt','consent');
      return redirect(res,discord.toString());
    }
    if(req.method==='GET'&&url.pathname==='/api/auth/discord/callback'){
      if(!AUTH_ENABLED)return send(res,503,{error:'Login desabilitado.'});
      const expected=cookieState(req),actual=String(url.searchParams.get('state')||'');
      res.setHeader('Set-Cookie',loginCookie(req,'',true));
      if(!expected||expected!==actual||!oauth.useState(actual))return send(res,400,{error:'Autorização expirada ou inválida. Reinicie o login.'});
      const code=url.searchParams.get('code');if(!code||code.length>1024)return send(res,400,{error:'Código de autorização ausente.'});
      const credentials=new URLSearchParams({client_id:DISCORD_CLIENT_ID,client_secret:DISCORD_CLIENT_SECRET,grant_type:'authorization_code',code,redirect_uri:DISCORD_REDIRECT_URI});
      const exchange=await fetch('https://discord.com/api/v10/oauth2/token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:credentials,signal:AbortSignal.timeout(12000)});
      if(!exchange.ok)return send(res,400,{error:'Discord não confirmou o login. Tente novamente.'});
      const tokens=await exchange.json();
      if(typeof tokens.access_token!=='string')return send(res,400,{error:'Discord retornou uma autorização inválida.'});
      const response=await fetch('https://discord.com/api/v10/users/@me',{headers:{Authorization:'Bearer '+tokens.access_token},signal:AbortSignal.timeout(12000)});
      if(!response.ok)return send(res,400,{error:'Não foi possível confirmar seu perfil Discord.'});
      const account=accounts.upsertDiscord(await response.json());
      const ticket=oauth.ticket(account.id);
      return redirect(res,nextURL(ticket));
    }
    if(req.method==='POST'&&url.pathname==='/api/auth/exchange'){
      const body=await readJSON(req);
      const accountId=oauth.redeem(body.ticket);
      if(!accountId)return send(res,401,{error:'Login expirado ou já utilizado. Entre pelo Discord novamente.'});
      const account=accounts.accounts.get(accountId),session=accounts.newSession(account);
      return send(res,200,{token:session.token,expiresAt:session.expiry,account:accounts.present(account)});
    }
    if(req.method==='POST'&&url.pathname==='/api/auth/logout'){
      accounts.logout(authHeader(req));return send(res,200,{ok:true});
    }
    if(req.method==='GET'&&url.pathname==='/api/account/me')return send(res,200,{account:accounts.present(requireAccount(req))});
    if(req.method==='GET'&&url.pathname==='/api/account/characters')return send(res,200,{characters:accounts.characters(requireAccount(req))});
    if(req.method==='GET'&&url.pathname==='/api/account/rooms'){
      const account=requireAccount(req);
      const result=[...rooms.values()].flatMap(room=>room.members.filter(m=>m.accountId===account.id).map(m=>({roomId:room.id,title:room.title,mode:room.mode,memberId:m.id,name:m.name,classId:m.classId,level:m.level,xp:m.xp,gold:m.gold,role:m.role,revision:room.revision})));
      return send(res,200,{rooms:result.sort((a,b)=>b.revision-a.revision)});
    }
    if(req.method==='GET'&&url.pathname==='/api/account/room-session'){
      const account=requireAccount(req);const room=rooms.get(String(url.searchParams.get('room')||'').toUpperCase());
      const member=room?.members.find(m=>m.accountId===account.id);
      if(!member)return send(res,403,{error:'Esta campanha não está vinculada à sua conta.'});
      return send(res,200,{roomId:room.id,session:member.secret,state:publicState(room,member)});
    }
    if(req.method==='POST'&&url.pathname==='/api/account/link-room'){
      const account=requireAccount(req),body=await readJSON(req);
      const room=rooms.get(String(body.roomId||'').trim().toUpperCase());if(!room)throw new Error('Sala não encontrada.');
      const member=memberFor(room,String(body.roomSession||''));
      if(member.accountId&&member.accountId!==account.id)throw new Error('Esse personagem já está vinculado a outra conta.');
      if(room.members.some(m=>m.accountId===account.id&&m.id!==member.id))throw new Error('Sua conta já tem um personagem nesta sala.');
      member.accountId=account.id;room.revision++;save();broadcast(room.id,room.revision);
      return send(res,200,{ok:true});
    }
    if(req.method==='POST'&&url.pathname==='/api/account/characters'){
      const account=requireAccount(req),body=await readJSON(req);
      const room=rooms.get(String(body.roomId||'').trim().toUpperCase());if(!room)throw new Error('Sala não encontrada.');
      const member=memberFor(room,String(body.roomSession||''));
      if(member.accountId!==account.id)throw new Error('Vincule este personagem à sua conta antes de salvar.');
      const character=accounts.saveCharacter(account,{...member,roomId:room.id});
      return send(res,201,{character});
    }
    if(req.method==='POST'&&url.pathname==='/api/account/characters/delete'){
      const account=requireAccount(req),body=await readJSON(req);
      accounts.removeCharacter(account,String(body.characterId||''));return send(res,200,{ok:true});
    }
    if(req.method==='POST'&&url.pathname==='/api/create'){
      if(rooms.size>=500)throw new Error('Limite de salas atingido.');
      const body=await readJSON(req);
      const account=requireLoginForNewRoom(req);
      if(account&&body.characterId){const template=account.characters.find(c=>c.id===body.characterId);if(!template)throw new Error('Ficha não encontrada.');body.name=template.name;body.classId=template.classId;}
      const {room,member}=createRoom({...body,accountId:account?.id});
      if(account&&body.characterId){accounts.useCharacter(account,body.characterId,member);const token=room.tokens.find(t=>t.ownerId===member.id);token.label=member.name;token.avatar=require('./lib/game').CLASSES[member.classId].avatar;token.hp=member.hp;token.maxHp=member.maxHp;}
      while(rooms.has(room.id))room.id=require('node:crypto').randomBytes(4).toString('hex').toUpperCase();
      rooms.set(room.id,room);save();return send(res,201,{roomId:room.id,session:member.secret,state:publicState(room,member)});
    }
    if(req.method==='POST'&&url.pathname==='/api/join'){
      const body=await readJSON(req);
      const id=String(body.roomId||'').trim().toUpperCase();
      const room=rooms.get(id);if(!room)throw new Error('Sala não encontrada.');
      const account=requireLoginForNewRoom(req);
      const existing=account&&room.members.find(m=>m.accountId===account.id);
      if(existing)return send(res,200,{roomId:id,session:existing.secret,state:publicState(room,existing)});
      if(account&&body.characterId){const template=account.characters.find(c=>c.id===body.characterId);if(!template)throw new Error('Ficha não encontrada.');body.name=template.name;body.classId=template.classId;}
      const member=joinRoom(room,{...body,accountId:account?.id});
      if(account&&body.characterId){accounts.useCharacter(account,body.characterId,member);const token=room.tokens.find(t=>t.ownerId===member.id);token.label=member.name;token.avatar=require('./lib/game').CLASSES[member.classId].avatar;token.hp=member.hp;token.maxHp=member.maxHp;}
      room.revision++;save();broadcast(room.id,room.revision);
      return send(res,201,{roomId:id,session:member.secret,state:publicState(room,member)});
    }
    if(req.method==='GET'&&url.pathname==='/api/state'){
      const {room,member}=getRoom(req,url);
      return send(res,200,{state:publicState(room,member)});
    }
    if(req.method==='POST'&&url.pathname==='/api/action'){
      const {room,member}=getRoom(req,url);rateLimit(member.id);
      const body=await readJSON(req);
      applyAction(room,member,body);save();broadcast(room.id,room.revision);
      return send(res,200,{state:publicState(room,member)});
    }
    if(req.method==='GET'&&url.pathname==='/api/events'){
      const {room}=getRoom(req,url);
      res.writeHead(200,{'Content-Type':'text/event-stream; charset=utf-8','Cache-Control':'no-cache, no-transform','Connection':'keep-alive','X-Accel-Buffering':'no','X-Content-Type-Options':'nosniff'});
      res.write(`retry: 1800\nevent: update\ndata: ${JSON.stringify({revision:room.revision})}\n\n`);
      let set=subscribers.get(room.id);if(!set){set=new Set();subscribers.set(room.id,set);}set.add(res);
      const heartbeat=setInterval(()=>{try{res.write(': ping\n\n');}catch{}},18000);
      req.on('close',()=>{clearInterval(heartbeat);set.delete(res);if(!set.size)subscribers.delete(room.id);});
      return;
    }
    // Modelos GLB são arquivos binários; não entram no JSON de salas nem no pacote Netlify.
    if(req.method==='GET'&&url.pathname==='/api/models'){
      const {room}=getRoom(req,url);return send(res,200,MODELS.publicModels(room));
    }
    if(req.method==='GET'&&url.pathname.startsWith('/api/models/file/')){
      const {room}=getRoom(req,url),id=url.pathname.slice('/api/models/file/'.length);
      if(!/^[a-f0-9]{24}$/.test(id)||!room.models?.some(x=>x.id===id))return send(res,404,{error:'Modelo não encontrado.'});
      const file=path.join(MODEL_DIR,id+'.glb');if(!fs.existsSync(file))return send(res,404,{error:'Arquivo do modelo ausente.'});
      res.writeHead(200,{'Content-Type':'model/gltf-binary','Content-Length':fs.statSync(file).size,'Cache-Control':'private, max-age=180','X-Content-Type-Options':'nosniff'});
      return fs.createReadStream(file).pipe(res);
    }
    if(req.method==='POST'&&url.pathname==='/api/models/upload'){
      const {room,member}=getRoom(req,url);if(room.mode!=='auto'||member.role!=='gm')throw Error('Somente o líder do modo cooperativo pode enviar modelos.');
      rateLimit(member.id);
      if(Number(req.headers['content-length']||0)>MODELS.LIMIT)throw Error('Arquivo maior que 8 MB.');
      const slot=String(url.searchParams.get('slot')||'');
      const name=String(req.headers['x-model-name']||'Modelo GLB');
      const data=await MODELS.readBinary(req);
      const model=MODELS.upload(room,slot,name,data,MODEL_DIR);
      room.revision++;save();broadcast(room.id,room.revision);
      return send(res,201,{model,library:MODELS.publicModels(room)});
    }
    if(req.method==='POST'&&url.pathname==='/api/models/select'){
      const {room,member}=getRoom(req,url);if(room.mode!=='auto'||member.role!=='gm')throw Error('Somente o líder pode trocar modelos.');
      rateLimit(member.id);const body=await readJSON(req);
      MODELS.choose(room,body.slot,body.id||null);room.revision++;save();broadcast(room.id,room.revision);
      return send(res,200,{library:MODELS.publicModels(room)});
    }
    if(req.method==='POST'&&url.pathname==='/api/models/remove'){
      const {room,member}=getRoom(req,url);if(room.mode!=='auto'||member.role!=='gm')throw Error('Somente o líder pode remover modelos.');
      rateLimit(member.id);const body=await readJSON(req);
      // Salva o novo manifesto antes de excluir os bytes antigos do disco.
      const file=path.join(MODEL_DIR,String(body.id||'')+'.glb');
      if(!/^[a-f0-9]{24}$/.test(String(body.id||''))||!room.models?.some(x=>x.id===body.id))throw Error('Modelo não encontrado.');
      const prior=room.models.slice(),priorSlots={...room.modelSlots};
      room.models=room.models.filter(m=>m.id!==body.id);
      for(const [slot,id] of Object.entries(room.modelSlots||{}))if(id===body.id)delete room.modelSlots[slot];
      try{room.revision++;save();}catch(e){room.models=prior;room.modelSlots=priorSlots;room.revision--;throw e;}
      try{fs.unlinkSync(file);}catch(e){if(e.code!=='ENOENT')console.warn('Não foi possível remover modelo antigo:',e.message);}
      broadcast(room.id,room.revision);
      return send(res,200,{library:MODELS.publicModels(room)});
    }
    if(req.method==='GET'&&url.pathname==='/api/health')return send(res,200,{ok:true,rooms:rooms.size,version:'1.6.0'});
    if(req.method!=='GET')return send(res,405,{error:'Método não permitido.'});
    return staticFile(url,res);
  }catch(error){
    const message=error instanceof Error?error.message:'Erro inesperado.';
    if(message.includes('EACCES')||message.includes('ENOSPC'))console.error('Erro ao salvar dados:',message);
    if(!res.headersSent)send(res,400,{error:message});
    else res.end();
  }
});
// One server-controlled scheduler for all opted-in cooperative players.
// Never trusts combat numbers coming from clients; one persisted revision/tick.
const coopScheduler=setInterval(()=>{
  for(const room of rooms.values()){
    if(room.mode!=='auto')continue;
    try{if(autoTick(room)){save();broadcast(room.id,room.revision);}}
    catch(e){console.error('[COOP AUTO]',room.id,e.message);}
  }
},650);
coopScheduler.unref?.();
server.on('close',()=>clearInterval(coopScheduler));
if(require.main===module){
  const port=Number(process.env.PORT)||3000;
  const host=process.env.HOST||'127.0.0.1';
  server.listen(port,host,()=>console.log(`\nASTRONYX REALMS ONLINE V1.6\nSite: http://localhost:${port}\nSalas: ${rooms.size}\nCtrl+C para encerrar\n`));
}
module.exports={server,rooms,accounts,oauth,AUTH_ENABLED};
